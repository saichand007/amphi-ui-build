"use strict";
(self["webpackChunk_amphi_pipeline_components_core"] = self["webpackChunk_amphi_pipeline_components_core"] || []).push([["lib_index_js"],{

/***/ "./lib/components/BaseCoreComponent.js":
/*!*********************************************!*\
  !*** ./lib/components/BaseCoreComponent.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BaseCoreComponent: () => (/* binding */ BaseCoreComponent)
/* harmony export */ });
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @amphi/pipeline-components-manager */ "webpack/sharing/consume/default/@amphi/pipeline-components-manager");
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactflow */ "webpack/sharing/consume/default/reactflow/reactflow");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(reactflow__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../icons */ "./lib/icons.js");




class BaseCoreComponent extends (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.PipelineComponent)() {
    constructor(name, id, description, type, fileDrop, category, icon, defaultConfig, form) {
        super();
        this.UIComponent = ({ id, data, context, componentService, manager, commands, rendermimeRegistry, settings }) => {
            const { setNodes, deleteElements, setViewport } = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useReactFlow)();
            const store = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useStoreApi)();
            const deleteNode = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
                deleteElements({ nodes: [{ id }] });
            }, [id, deleteElements]);
            const zoomSelector = (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.createZoomSelector)();
            const showContent = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useStore)(zoomSelector);
            const selector = (s) => ({
                nodeInternals: s.nodeInternals,
                edges: s.edges,
            });
            const { nodeInternals, edges } = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useStore)(selector);
            const nodeId = id;
            const internals = { nodeInternals, edges, nodeId, componentService };
            const handleElement = react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.renderHandle, {
                type: this._type,
                Handle: reactflow__WEBPACK_IMPORTED_MODULE_2__.Handle,
                Position: reactflow__WEBPACK_IMPORTED_MODULE_2__.Position,
                internals: internals
            });
            const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((evtTargetValue, field) => {
                (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.onChange)({ evtTargetValue, field, nodeId, store, setNodes });
            }, [nodeId, store, setNodes]);
            // Selector to determine if the node is selected
            const isSelected = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useStore)((state) => { var _a; return !!((_a = state.nodeInternals.get(id)) === null || _a === void 0 ? void 0 : _a.selected); });
            const executeUntilComponent = () => {
                const timestamp = Date.now();
                const flow = _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.PipelineService.filterPipeline(context.model.toString());
                console.log("flow=", flow);
                console.log("componentService=", componentService);
                // Get nodes to traverse and related data
                const { nodesToTraverse, nodesMap } = _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.CodeGenerator.computeNodesToTraverse(flow, nodeId, componentService);
                console.log("nodesToTraverse=", nodesToTraverse);
                console.log("nodesMap=", nodesMap);
                console.log("this._name = ", this._name);
                console.log("this._id =", this._id);
                console.log("this._description = ", this._description);
                console.log("this._type =", this._type);
                console.log("this._fileDrop =", this._fileDrop);
                console.log("this._category =", this._category);
                console.log("this._default =", this._default);
                //  console.log("this._form =", this._form);
                console.log("nodeId=", nodeId);
                console.log("context=====>", context);
                commands.execute('pipeline-editor:run-pipeline-until', { nodeId: nodeId, context: context }).then(result => {
                    console.log("result===>", result);
                    // setNodes(prevNodes =>
                    //   prevNodes.map(node =>
                    //     nodesToTraverse.includes(node.id)
                    //       ? { ...node, data: { ...node.data, lastExecuted: timestamp, successfulExecution: true } }
                    //       : node
                    //   )
                    // );
                })
                    .catch(reason => {
                    setNodes(prevNodes => prevNodes.map(node => nodesToTraverse.includes(node.id)
                        ? { ...node, data: { ...node.data, successfulExecution: null } }
                        : node));
                    console.error(`Error with pipeline, nodes not updated.'.\n${reason}`);
                });
            };
            const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
            let enableExecution = settings.get('enableExecution').composite;
            return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.renderComponentUI)({
                    id: id,
                    data: data,
                    context: context,
                    manager: manager,
                    commands: commands,
                    name: this._name,
                    ConfigForm: BaseCoreComponent.ConfigForm,
                    configFormProps: {
                        nodeId: id,
                        data,
                        context,
                        componentService,
                        manager,
                        commands,
                        store,
                        setNodes,
                        type: this._type,
                        name: this._name,
                        defaultConfig: this._default,
                        form: this._form,
                        handleChange,
                        modalOpen,
                        setModalOpen
                    },
                    Icon: this._icon,
                    showContent: showContent,
                    handle: handleElement,
                    deleteNode: deleteNode,
                    setViewport: setViewport,
                    handleChange,
                    isSelected
                }),
                (showContent || isSelected) && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(reactflow__WEBPACK_IMPORTED_MODULE_2__.NodeToolbar, { isVisible: true, position: reactflow__WEBPACK_IMPORTED_MODULE_2__.Position.Bottom },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { onClick: () => setModalOpen(true) },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_3__.settingsIcon.react, null)),
                    (this._type.includes('input') || this._type.includes('processor') || this._type.includes('output')) && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { onClick: () => executeUntilComponent(), disabled: !enableExecution, style: { opacity: enableExecution ? 1 : 0.5, cursor: enableExecution ? 'pointer' : 'not-allowed' } },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_3__.playCircleIcon.react, null)))))));
        };
        this._name = name;
        this._id = id;
        this._description = description;
        this._type = type;
        this._fileDrop = fileDrop;
        this._category = category;
        this._icon = icon;
        this._default = defaultConfig;
        this._form = form;
    }
}
BaseCoreComponent.ConfigForm = ({ nodeId, data, context, componentService, manager, commands, store, setNodes, type, name, defaultConfig, form, handleChange, modalOpen, setModalOpen }) => {
    const handleSetDefaultConfig = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
        (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.setDefaultConfig)({ nodeId, store, setNodes, defaultConfig });
    }, [nodeId, store, setNodes, defaultConfig]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        handleSetDefaultConfig();
    }, [handleSetDefaultConfig]);
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.GenerateUIFormComponent, { nodeId: nodeId, type: type, name: name, form: form, data: data, context: context, componentService: componentService, manager: manager, commands: commands, handleChange: handleChange, modalOpen: modalOpen, setModalOpen: setModalOpen })));
};



/***/ }),

/***/ "./lib/components/annotations/Annotation.js":
/*!**************************************************!*\
  !*** ./lib/components/annotations/Annotation.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Annotation: () => (/* binding */ Annotation)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactflow */ "webpack/sharing/consume/default/reactflow/reactflow");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(reactflow__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_remark__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-remark */ "webpack/sharing/consume/default/react-remark/react-remark");
/* harmony import */ var react_remark__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_remark__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @amphi/pipeline-components-manager */ "webpack/sharing/consume/default/@amphi/pipeline-components-manager");
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/QuestionCircleOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
var _a;









class Annotation extends (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_3__.PipelineComponent)() {
    constructor() {
        super(...arguments);
        this._name = "Annotation";
        this._id = "annotation";
        this._type = "annotation";
        this._icon = _icons__WEBPACK_IMPORTED_MODULE_5__.annotationIcon;
        this._category = "documentation";
        this._description = "Annotation";
        this._default = { content: "# Annotation", isLocked: false };
    }
    UIComponent({ id, data, context, componentService, manager, commands, rendermimeRegistry, settings }) {
        const { setNodes, deleteElements, setViewport } = (0,reactflow__WEBPACK_IMPORTED_MODULE_1__.useReactFlow)();
        const store = (0,reactflow__WEBPACK_IMPORTED_MODULE_1__.useStoreApi)();
        const deleteNode = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
            deleteElements({ nodes: [{ id }] });
        }, [id, deleteElements]);
        const isSelected = (0,reactflow__WEBPACK_IMPORTED_MODULE_1__.useStore)((state) => { var _b; return !!((_b = state.nodeInternals.get(id)) === null || _b === void 0 ? void 0 : _b.selected); });
        const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((evtTargetValue, field) => {
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_3__.onChange)({ evtTargetValue, field, nodeId: id, store, setNodes });
        }, [id, store, setNodes]);
        const toggleLock = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
            setNodes((nds) => nds.map((node) => {
                if (node.id === id) {
                    const newIsLocked = !node.data.isLocked;
                    node.data = {
                        ...node.data,
                        isLocked: newIsLocked,
                    };
                    node.draggable = !newIsLocked;
                }
                return node;
            }));
        }, [id, setNodes]);
        (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
            setNodes((nds) => nds.map((node) => {
                if (node.id === id) {
                    node.draggable = !data.isLocked;
                }
                return node;
            }));
        }, [data.isLocked, id, setNodes]);
        const shiftKeyPressed = (0,reactflow__WEBPACK_IMPORTED_MODULE_1__.useKeyPress)('Shift');
        const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
        const backgroundColorStyle = data.backgroundColor || 'transparent';
        const borderColorStyle = data.borderColor || '#42766D';
        const borderWidthStyle = data.borderWidth || 2;
        const textColorStyle = data.textColor || 'rgba(0, 0, 0, 1)';
        const borderRadiusStyle = data.borderRadius || 0;
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            isSelected && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Popconfirm, { title: "Sure to delete?", placement: "right", onConfirm: deleteNode, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_6__["default"], { style: { color: 'red' } }) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "deletebutton", style: {
                        position: 'absolute',
                        top: '-20px',
                        right: '-20px',
                        cursor: 'pointer',
                        zIndex: 10
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_5__.xIcon.react, { className: "group-hover:text-primary" })))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "annotation", style: {
                    height: '100%',
                    backgroundColor: backgroundColorStyle,
                    paddingLeft: '40px',
                    paddingRight: '40px',
                    paddingTop: '20px',
                    paddingBottom: '20px',
                    position: 'relative',
                    zIndex: 0,
                    borderRadius: `${borderRadiusStyle}px`,
                    border: `${borderWidthStyle}px solid ${borderColorStyle}`,
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(reactflow__WEBPACK_IMPORTED_MODULE_1__.NodeResizer, { keepAspectRatio: shiftKeyPressed, isVisible: isSelected, color: "#000000", minWidth: 50, minHeight: 50 }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { color: textColorStyle } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_remark__WEBPACK_IMPORTED_MODULE_2__.Remark, null, data.content)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(reactflow__WEBPACK_IMPORTED_MODULE_1__.NodeToolbar, { isVisible: isSelected, position: reactflow__WEBPACK_IMPORTED_MODULE_1__.Position.Bottom },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: () => setModalOpen(true) },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_5__.settingsIcon.react, null)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: toggleLock }, data.isLocked ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_5__.lockIcon.react, null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_5__.unlockIcon.react, null)))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Annotation.ConfigForm, { nodeId: id, data: data, context: context, componentService: manager.componentService, manager: manager, commands: commands, store: store, setNodes: setNodes, handleChange: handleChange, modalOpen: modalOpen, setModalOpen: setModalOpen })));
    }
}
_a = Annotation;
Annotation.ConfigForm = ({ nodeId, data, context, componentService, manager, commands, store, setNodes, handleChange, modalOpen, setModalOpen }) => {
    const handleColorChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((colorObj, setColor, field) => {
        const colorValue = colorObj.toRgbString();
        setColor(colorValue);
        handleChange(colorValue, field);
    }, [handleChange]);
    const handleBorderRadiusChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((newValue) => {
        setBorderRadius(newValue);
        handleChange(newValue, 'borderRadius');
    }, [handleChange]);
    const handleBorderWidthChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((newValue) => {
        setBorderWidth(newValue);
        handleChange(newValue, 'borderWidth');
    }, [handleChange]);
    const [content, setContent] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.content || '# Annotation');
    const [backgroundColor, setBackgroundColor] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.backgroundColor || '#fff');
    const [borderColor, setBorderColor] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.borderColor || '#42766D');
    const [borderWidth, setBorderWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.borderWidth || 5);
    const [textColor, setTextColor] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.textColor || '#000');
    const [borderRadius, setBorderRadius] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.borderRadius || 0);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setContent(data.content || '# Annotation');
    }, [data.content]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        handleChange(content, 'content');
    }, [content]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.ConfigProvider, { theme: {
                token: {
                    colorPrimary: '#5F9B97',
                },
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Modal, { title: _a.Name, centered: true, open: modalOpen, onOk: () => setModalOpen(false), onCancel: () => setModalOpen(false), width: 800, footer: (_, { OkBtn }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(OkBtn, null))) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Form, { layout: "vertical" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Form.Item, { label: "Background Color" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.ColorPicker, { allowClear: true, placement: "topRight", defaultFormat: "hex", format: "hex", showText: true, value: backgroundColor, onChange: (color) => handleColorChange(color, setBackgroundColor, 'backgroundColor') })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Form.Item, { label: "Border Color" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.ColorPicker, { placement: "topRight", defaultFormat: "hex", format: "hex", showText: true, value: borderColor, onChange: (color) => handleColorChange(color, setBorderColor, 'borderColor') })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Form.Item, { label: "Border Width" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Row, null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Col, { span: 12 },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Slider, { min: 0, max: 20, onChange: handleBorderWidthChange, value: typeof borderWidth === 'number' ? borderWidth : 5 })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Col, { span: 4 },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.InputNumber, { min: 0, max: 20, style: { margin: '0 16px' }, value: borderWidth, onChange: handleBorderWidthChange })))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Form.Item, { label: "Text Color" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.ColorPicker, { placement: "topRight", defaultFormat: "hex", format: "hex", showText: true, value: textColor, onChange: (color) => handleColorChange(color, setTextColor, 'textColor') })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Form.Item, { label: "Border Radius" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Row, null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Col, { span: 12 },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Slider, { min: 0, max: 50, onChange: handleBorderRadiusChange, value: typeof borderRadius === 'number' ? borderRadius : 0 })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Col, { span: 4 },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.InputNumber, { min: 0, max: 50, style: { margin: '0 16px' }, value: borderRadius, onChange: handleBorderRadiusChange })))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__.Form.Item, { label: "Markdown Content" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_3__.CodeTextarea, { field: {
                                type: "code", label: "Markdown Content", id: "content", placeholder: "Markdown",
                            }, handleChange: (value) => {
                                handleChange(value, 'content');
                                setContent(value);
                            }, advanced: false, value: content })))))));
};



/***/ }),

/***/ "./lib/components/common/AzureOptionsHandler.js":
/*!******************************************************!*\
  !*** ./lib/components/common/AzureOptionsHandler.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AzureOptionsHandler: () => (/* binding */ AzureOptionsHandler)
/* harmony export */ });
// AzureOptionsHandler.ts
class AzureOptionsHandler {
    static handleAZBptions(config, storageOptions) {
        if (config.fileLocation === 'azb' && config.connectionMethod === 'storage_options') {
            return {
                ...storageOptions,
                account_name: config.awsAccessKey,
                sas_token: config.awsSecretKey
            };
        }
        return storageOptions;
    }
    static getAZBFields() {
        return [
            {
                type: "select",
                label: "Connection Method",
                id: "connectionMethod",
                options: [
                    { value: "env", label: "Environment Variables (Recommended)", tooltip: "Use AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY variables, using an Env. Variable File is recommended." },
                    { value: "storage_options", label: "Pass directly (storage_options)", tooltip: "You can pass credentials using the storage_options parameter. Using Environment Variables for this method is also recommended." }
                ],
                condition: { fileLocation: "azb" },
                connection: "Azure-----",
                ignoreConnection: true,
                advanced: true
            },
            {
                type: "input",
                label: "Storage -- Account",
                id: "awsAccessKey",
                placeholder: "Enter Access Key",
                inputType: "password",
                connection: "AZB",
                connectionVariableName: "AWS_ACCESS_KEY_ID",
                condition: { fileLocation: "azb", connectionMethod: "storage_options" },
                advanced: true
            },
            {
                type: "input",
                label: "SAS Token",
                id: "awsSecretKey",
                placeholder: "Enter Secret Key",
                inputType: "password",
                connection: "AZB",
                connectionVariableName: "AWS_SECRET_ACCESS_KEY",
                condition: { fileLocation: "azb", connectionMethod: "storage_options" },
                advanced: true
            },
        ];
    }
}


/***/ }),

/***/ "./lib/components/common/FileUtils.js":
/*!********************************************!*\
  !*** ./lib/components/common/FileUtils.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileUtils: () => (/* binding */ FileUtils)
/* harmony export */ });
class FileUtils {
    // Static method to generate file paths using glob for local files
    static getLocalFilePaths(filePath, outputName) {
        return `
${outputName}_file_paths = glob.glob("${filePath}")
if not ${outputName}_file_paths:
    raise FileNotFoundError("No files found matching the pattern.")
`;
    }
    // Static method to generate file paths using s3fs for S3 files
    static getS3FilePaths(filePath, storageOptionsString, outputName) {
        return `
${outputName}_fs = s3fs.S3FileSystem(**${storageOptionsString})
${outputName}_file_paths = ${outputName}_fs.glob("${filePath}")
if not ${outputName}_file_paths:
    raise FileNotFoundError("No files found matching the pattern.")
`;
    }
    static getADLSFilePaths(filePath, storageOptionsString, outputName) {
        return `
from adlfs import AzureBlobFileSystem
${outputName}_fs = AzureBlobFileSystem(**${storageOptionsString})
${outputName}_file_paths = ${outputName}_fs.glob("${filePath}")
if not ${outputName}_file_paths:
    raise FileNotFoundError("No files found matching the pattern.")
`;
    }
    // Static method to generate the concatenation code
    static generateConcatCode(outputName, readMethod, optionsString, isS3) {
        const readFunction = isS3
            ? `pd.${readMethod}(${outputName}_fs.open(file, 'rb')${optionsString})`
            : `pd.${readMethod}(file${optionsString})`;
        return `
${outputName} = pd.concat([${readFunction} for file in ${outputName}_file_paths], ignore_index=True).convert_dtypes()
`;
    }
    static isWildcardInput(filePath) {
        return filePath.includes('*');
    }
}


/***/ }),

/***/ "./lib/components/common/S3OptionsHandler.js":
/*!***************************************************!*\
  !*** ./lib/components/common/S3OptionsHandler.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   S3OptionsHandler: () => (/* binding */ S3OptionsHandler)
/* harmony export */ });
// S3OptionsHandler.ts
class S3OptionsHandler {
    // Static method to handle S3-specific options
    static handleS3SpecificOptions(config, storageOptions) {
        if (config.fileLocation === 's3' && config.connectionMethod === 'storage_options') {
            const updatedStorageOptions = {
                ...storageOptions,
                key: config.awsAccessKey,
                secret: config.awsSecretKey
            };
            if (config.useCustomEndpoint && config.customEndpoint == true) {
                updatedStorageOptions.client_kwargs = {
                    ...updatedStorageOptions.client_kwargs,
                    endpoint_url: config.customEndpoint
                };
            }
            return updatedStorageOptions;
        }
        return storageOptions;
    }
    static getAWSFields() {
        return [
            {
                type: "select",
                label: "Connection Method",
                id: "connectionMethod",
                options: [
                    { value: "env", label: "Environment Variables (Recommended)", tooltip: "Use AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY variables, using an Env. Variable File is recommended." },
                    { value: "storage_options", label: "Pass directly (storage_options)", tooltip: "You can pass credentials using the storage_options parameter. Using Environment Variables for this method is also recommended." }
                ],
                condition: { fileLocation: "s3" },
                connection: "AWS",
                ignoreConnection: true,
                advanced: true
            },
            {
                type: "input",
                label: "Access Key",
                id: "awsAccessKey",
                placeholder: "Enter Access Key",
                inputType: "password",
                connection: "AWS",
                connectionVariableName: "AWS_ACCESS_KEY_ID",
                condition: { fileLocation: "s3", connectionMethod: "storage_options" },
                advanced: true
            },
            {
                type: "input",
                label: "Secret Key",
                id: "awsSecretKey",
                placeholder: "Enter Secret Key",
                inputType: "password",
                connection: "AWS",
                connectionVariableName: "AWS_SECRET_ACCESS_KEY",
                condition: { fileLocation: "s3", connectionMethod: "storage_options" },
                advanced: true
            },
            {
                type: "boolean",
                label: "Use Custom Endpoint",
                id: "useCustomEndpoint",
                placeholder: "Use custom endpoint to connecto Minio for example",
                connection: "AWS",
                condition: { fileLocation: "s3", connectionMethod: "storage_options" },
                advanced: true
            },
            {
                type: "input",
                label: "Custom Endpoint",
                id: "customEndpoint",
                tooltip: "Connect to a Different SE-Compatible File System (e.g., Minio) Using a Custom Endpoint",
                placeholder: "http://localhost:9000",
                connection: "AWS",
                condition: { fileLocation: "s3", connectionMethod: "storage_options", useCustomEndpoint: true },
                advanced: true
            },
        ];
    }
}


/***/ }),

/***/ "./lib/components/custom/CustomInput.js":
/*!**********************************************!*\
  !*** ./lib/components/custom/CustomInput.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CustomInput: () => (/* binding */ CustomInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class CustomInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { imports: "import pandas as pd", code: "output = pd.DataFrame({'A': [1, 2, 3]})" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "info",
                    label: "Instructions",
                    id: "instructions",
                    text: "Write Python code with 'output', the output pandas dataframe of this component.",
                },
                {
                    type: "codeTextarea",
                    label: "Imports",
                    id: "imports",
                    placeholder: "import pandas as pd",
                    height: '50px',
                    advanced: true
                },
                {
                    type: "codeTextarea",
                    label: "Code",
                    tooltip: "Use the dataframe 'output' as output. For example, output = read_csv('myfile.csv').",
                    id: "code",
                    mode: "python",
                    height: '300px',
                    placeholder: "output = pd.DataFrame({'A': [1, 2, 3]})",
                    advanced: true
                }
            ],
        };
        const description = "Use custom Python code to apply Pandas operations on the input DataFrame, transforming it to produce the desired output DataFrame. You can also use this component as either an input or an output.";
        super("Python Input", "customInput", description, "pandas_df_input", [], "inputs", _icons__WEBPACK_IMPORTED_MODULE_1__.codeIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        let imports = [];
        // Check if config.imports exists and is a string
        if (config.imports && typeof config.imports === 'string') {
            // Split config.imports by lines, filter lines starting with 'import '
            const importLines = config.imports.split('\n').filter((line) => line.startsWith('import '));
            // Push each filtered import line to the imports array
            imports.push(...importLines);
        }
        return imports;
    }
    generateComponentCode({ config, outputName }) {
        let code = `\n${config.code}`.replace(/output/g, outputName);
        return code;
    }
}


/***/ }),

/***/ "./lib/components/custom/CustomOutput.js":
/*!***********************************************!*\
  !*** ./lib/components/custom/CustomOutput.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CustomOutput: () => (/* binding */ CustomOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class CustomOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { code: "input.to_csv('output.csv', index=False)" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "info",
                    label: "Instructions",
                    id: "instructions",
                    text: "Write Python code with 'input', the input pandas dataframe of this component.",
                },
                {
                    type: "codeTextarea",
                    label: "Imports",
                    id: "imports",
                    placeholder: "import pandas as pd",
                    height: '50px',
                    advanced: true
                },
                {
                    type: "codeTextarea",
                    label: "Code",
                    tooltip: "Use the dataframe 'input' as input. For example, input.to_csv('myfile.csv').",
                    id: "code",
                    mode: "python",
                    height: '300px',
                    placeholder: "input.to_csv('output.csv', index=False)",
                    advanced: true
                }
            ],
        };
        const description = "Use custom Python code to apply Pandas operations on the input DataFrame, transforming it to produce the desired output DataFrame. You can also use this component as either an input or an output.";
        super("Python Output", "customOutput", description, "pandas_df_output", [], "outputs", _icons__WEBPACK_IMPORTED_MODULE_1__.codeIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        let imports = [];
        // Always add 'import pandas as pd'
        // imports.push("import pandas as pd");
        // Check if config.imports exists and is a string
        if (config.imports) {
            // Split config.imports by lines, filter lines starting with 'import '
            const importLines = config.imports.split('\n').filter(line => line.trim().startsWith('import ') || line.trim().startsWith('from '));
            // Push each filtered import line to the imports array
            imports.push(...importLines);
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        let code = `\n${config.code}`.replace(/input/g, inputName);
        return code;
    }
}


/***/ }),

/***/ "./lib/components/custom/CustomTransformations.js":
/*!********************************************************!*\
  !*** ./lib/components/custom/CustomTransformations.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CustomTransformations: () => (/* binding */ CustomTransformations)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class CustomTransformations extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { code: "output = input" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "info",
                    label: "Instructions",
                    id: "instructions",
                    text: "Write Python code with 'input' being the input dataframe, and 'output' the output dataframe.",
                },
                {
                    type: "codeTextarea",
                    label: "Imports",
                    id: "imports",
                    placeholder: "import pandas as pd",
                    height: '50px',
                    advanced: true
                },
                {
                    type: "codeTextarea",
                    label: "Code",
                    tooltip: "Use the dataframe 'input' as input and 'output' output. For example, output = input would return the same data as input.",
                    id: "code",
                    mode: "python",
                    height: '300px',
                    placeholder: "output = input",
                    advanced: true
                }
            ],
        };
        const description = "Use custom Python code to apply Pandas operations on the input DataFrame, transforming it to produce the desired output DataFrame. You can also use this component as either an input or an output.";
        super("Python Transforms", "customTransformations", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.codeIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        const imports = [];
        // Always include 'import pandas as pd'
        imports.push("import pandas as pd");
        // Check if `config.imports` is a valid string
        if (config.imports) {
            // Split by lines and trim each line to handle whitespace issues
            const importLines = config.imports
                .split('\n')
                .map(line => line.trim())
                .filter(line => line.startsWith('import ') || line.startsWith('from '));
            // Add the valid import lines to the imports array
            imports.push(...importLines);
        }
        return imports;
    }
    generateComponentCode({ config, inputName, outputName }) {
        let code = `\n${config.code}`.replace(/input/g, inputName);
        code = code.replace(/output/g, outputName);
        return code;
    }
}


/***/ }),

/***/ "./lib/components/developer/FormExample.js":
/*!*************************************************!*\
  !*** ./lib/components/developer/FormExample.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormExample: () => (/* binding */ FormExample)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
// Import necessary icons and the BaseCoreComponent class.
// Ensure the correct folder hierarchy is used (e.g., input/xx/yy...)


// Main class definition
class FormExample extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    // Constructor initializes the form structure
    constructor() {
        const defaultConfig = {};
        const form = {
            idPrefix: "component__form",
            fields: [
                // Form fields are displayed sequentially.
                // Each form has a type, label, tooltip, and additional properties.
                // Available form types are defined in:
                // amphi-etl\jupyterlab-amphi\packages\pipeline-components-manager\src\forms
                // Informational sections
                {
                    type: "info",
                    id: "description",
                    text: "This component serves as an example showcasing all types of data entry forms available with Amphi. ⚠️ It is not intended for use as part of a pipeline.",
                    advanced: false
                },
                {
                    type: "info",
                    id: "instructions",
                    text: "1. Informational text to show in the component.",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "2. File Location (radio)",
                    id: "fileLocation",
                    //options : value on the radio button
                    options: [
                        { value: "local", label: "Local" },
                        { value: "http", label: "HTTP" },
                        { value: "s3", label: "S3" },
                        { value: "option4", label: "Option 4" }
                    ],
                    advanced: true
                },
                {
                    type: "file",
                    label: "3. File path (file)",
                    id: "filePath",
                    placeholder: "Type file name or use '*' for patterns",
                    tooltip: "Provide a single CSV file path or use '*' for matching multiple files. Extensions accepted: .csv, .tsv, .txt. Can also read CSV files compressed as .gz, .bz2, .zip, .xz, .zst.",
                    validation: "^(.*(\\.csv|\\.tsv|\\.txt))$|^(.*\\*)$",
                    advanced: true
                },
                {
                    type: "selectCustomizable",
                    label: "4. Separator (selectCustomizable)",
                    id: "csvOptions.sep",
                    placeholder: "default: ,",
                    tooltip: "Select or provide a custom delimiter.",
                    options: [
                        { value: ",", label: "comma (,)" },
                        { value: ";", label: "semicolon (;)" },
                        { value: " ", label: "space" },
                        { value: "\\t", label: "tab" },
                        { value: "|", label: "pipe (|)" },
                        { value: "infer", label: "infer (tries to auto detect)" }
                    ],
                    advanced: true
                },
                {
                    type: "inputNumber",
                    tooltip: "Number of rows of file to read. Useful for reading pieces of large files.",
                    label: "5. Rows number (inputNumber)",
                    id: "csvOptions.nrows",
                    placeholder: "Default: all",
                    min: 0,
                    advanced: true
                },
                {
                    type: "selectTokenization",
                    tooltip: "Sequence of column labels to apply.",
                    label: "6. Column names (selectTokenization)",
                    id: "csvOptions.names",
                    placeholder: "Type header fields (ordered and comma-separated)",
                    options: [],
                    advanced: true
                },
                {
                    type: "input",
                    label: "7. Wrapper Character (input)",
                    id: "csvOptions.quotechar",
                    tooltip: "Defines the character used to wrap fields containing special characters like the delimiter or newline.",
                    advanced: true
                },
                {
                    type: "select",
                    label: "8. On Bad Lines (select)",
                    id: "csvOptions.on_bad_lines",
                    placeholder: "Error: raise an Exception when a bad line is encountered",
                    options: [
                        { value: "error", label: "Error", tooltip: "Raise an Exception when a bad line is encountered" },
                        { value: "warn", label: "Warn", tooltip: "Raise a warning when a bad line is encountered and skip that line." },
                        { value: "skip", label: "Skip", tooltip: "Skip bad lines without raising or warning when they are encountered." }
                    ],
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "9. Storage Options (keyvalue)",
                    id: "csvOptions.storage_options",
                    condition: { fileLocation: ["http", "s3"] },
                    advanced: true
                },
                {
                    type: "transferData",
                    label: "10. Filter columns (transferData)",
                    id: "columns",
                    advanced: true
                },
                {
                    type: "columns",
                    label: "11. Left Input Column(s) (columns)",
                    id: "leftKeyColumn",
                    placeholder: "Column name",
                    tooltip: "If you're joining by multiple columns, make sure the column lists are ordered to match the corresponding columns in the right dataset.",
                    inputNb: 1,
                    advanced: true
                },
                {
                    type: "keyvalueColumns",
                    label: "12. Columns (keyvalueColumns)",
                    id: "columns",
                    placeholders: { key: "column name", value: "new column name" },
                    advanced: true
                },
                {
                    type: "codeTextarea",
                    label: "13. Imports (codeTextarea)",
                    id: "import",
                    placeholder: "import langchain ...",
                    height: '50px',
                    advanced: true
                },
                {
                    type: "textarea",
                    label: "14. Body (textarea)",
                    id: "body",
                    placeholder: "Write body in JSON",
                    advanced: true
                },
                {
                    type: "table",
                    label: "15. Table Name (table)",
                    query: `SHOW TABLES;`,
                    id: "tableName",
                    placeholder: "Enter table name",
                    condition: { queryMethod: "table" },
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "16. Auto Commit (boolean)",
                    tooltip: "Setting autocommit True will cause the database to issue a commit after each SQL statement, otherwise database transactions will have to be explicity committed. As per the Python DB API, the default value is False (even though the ODBC default value is True). Typically, you will probably want to set autocommit True when creating a connection.",
                    id: "autoCommit",
                    advanced: true
                },
                {
                    type: "valuesList",
                    label: "17. URLs (valuesList)",
                    id: "urls",
                    placeholders: "Enter URLs",
                    advanced: true
                },
                {
                    type: "sheets",
                    label: "18. Sheets (sheets)",
                    id: "excelOptions.sheet_name",
                    placeholder: "Default: 0 (first sheet)",
                    tooltip: "Select one or multiple sheets. If multiple sheets are selected, the sheets are concatenated to output a single dataset.",
                    condition: { fileLocation: "local" },
                    advanced: true
                },
                {
                    type: "dataMapping",
                    label: "19. Mapping (dataMapping)",
                    id: "mapping",
                    tooltip: "By default, the mapping is inferred from the input data. By specifying a schema, you override the incoming schema.",
                    outputType: "relationalDatabase",
                    imports: ["pyodbc"],
                    drivers: "mssql",
                    query: `
SELECT 
    COLUMN_NAME AS "Field",
    DATA_TYPE AS "Type",
    IS_NULLABLE AS "Null",
    COLUMN_DEFAULT AS "Default",
    '' AS "Extra"
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = '{{table}}' AND TABLE_SCHEMA = 'dbo';
`,
                    typeOptions: [
                        { value: "INT", label: "INT" },
                        { value: "VARCHAR", label: "VARCHAR" },
                        { value: "NVARCHAR", label: "NVARCHAR" },
                        { value: "TEXT", label: "TEXT" },
                        { value: "DATETIME", label: "DATETIME" },
                        { value: "DATE", label: "DATE" },
                        { value: "FLOAT", label: "FLOAT" },
                        { value: "DECIMAL", label: "DECIMAL" },
                        { value: "BIT", label: "BIT" },
                        { value: "BIGINT", label: "BIGINT" },
                        { value: "SMALLINT", label: "SMALLINT" },
                        { value: "TINYINT", label: "TINYINT" },
                        { value: "CHAR", label: "CHAR" },
                        { value: "NCHAR", label: "NCHAR" },
                        { value: "NTEXT", label: "NTEXT" },
                        { value: "BINARY", label: "BINARY" },
                        { value: "VARBINARY", label: "VARBINARY" },
                        { value: "IMAGE", label: "IMAGE" },
                        { value: "UNIQUEIDENTIFIER", label: "UNIQUEIDENTIFIER" },
                        { value: "XML", label: "XML" },
                        { value: "TIME", label: "TIME" },
                        { value: "DATETIME2", label: "DATETIME2" },
                        { value: "DATETIMEOFFSET", label: "DATETIMEOFFSET" },
                        { value: "SMALLDATETIME", label: "SMALLDATETIME" },
                        { value: "REAL", label: "REAL" },
                        { value: "MONEY", label: "MONEY" },
                        { value: "SMALLMONEY", label: "SMALLMONEY" },
                    ],
                    advanced: true
                },
                {
                    type: "cascader",
                    label: "20. Data Type to convert to (cascader)",
                    id: "dataType",
                    placeholder: "Select ...",
                    onlyLastValue: true,
                    options: [
                        {
                            value: "numeric",
                            label: "Numeric",
                            children: [
                                {
                                    value: "int",
                                    label: "Integer",
                                    children: [
                                        { value: "int64", label: "int64: Standard integer type." },
                                        { value: "int32", label: "int32: For optimized memory usage." },
                                        { value: "int16", label: "int16: For more optimized memory usage." },
                                        { value: "int8", label: "int8: For more optimized memory usage." },
                                        { value: "uint64", label: "uint64: Unsigned integer (can only hold non-negative values)" },
                                        { value: "uint32", label: "uint32: For more optimized memory usage." },
                                        { value: "uint16", label: "uint16: For more optimized memory usage." },
                                        { value: "uint8", label: "uint8: For more optimized memory usage." }
                                    ]
                                },
                                {
                                    value: "float",
                                    label: "Float",
                                    children: [
                                        { value: "float64", label: "float64: Standard floating-point type." },
                                        { value: "float32", label: "float32: For optimized memory usage." },
                                        { value: "float16", label: "float16: For optimized memory usage." }
                                    ]
                                }
                            ]
                        },
                        {
                            value: "text",
                            label: "Text",
                            children: [
                                { value: "string", label: "string: For string data. (recommended)" },
                                { value: "object", label: "object: For generic objects (strings, timestamps, mixed types)." },
                                { value: "category", label: "category: For categorical variables." }
                            ]
                        },
                        {
                            value: "datetime",
                            label: "Date & Time",
                            children: [
                                { value: "datetime64[ns]", label: "datetime64[ns]: For datetime values." },
                                { value: "datetime64[ms]", label: "datetime64[ms]: For datetime values in milliseconds." },
                                { value: "datetime64[s]", label: "datetime64[s]: For datetime values in seconds." },
                                { value: "datetime32[ns]", label: "datetime32[ns]: For compact datetime storage in nanoseconds." },
                                { value: "datetime32[ms]", label: "datetime32[ms]: For compact datetime storage in milliseconds." },
                                { value: "timedelta[ns]", label: "timedelta[ns]: For differences between two datetimes." }
                            ]
                        },
                        {
                            value: "boolean",
                            label: "Boolean",
                            children: [
                                { value: "bool", label: "bool: For boolean values (True or False)." }
                            ]
                        }
                    ],
                    advanced: true
                },
                {
                    type: "keyvalueColumnsRadio",
                    label: "21. Columns Sorting Order(keyvalueColumnsRadio)",
                    id: "columnAndOrder",
                    options: [
                        { value: "True", label: "Asc." },
                        { value: "False", label: "Desc." }
                    ],
                    advanced: true
                },
                {
                    type: "selectMultipleCustomizable",
                    label: "22. Remove Unwanted Characters (selectMultipleCustomizable)",
                    id: "removeUnwantedCharacters",
                    options: [
                        { value: "whitespace", label: "Leading and Trailing Whitespace" },
                        { value: "tabs", label: "Tabs" },
                        { value: "Line breaks", label: "Line Breaks" },
                        { value: "allwhitespace", label: "All Whitespace" },
                        { value: "letters", label: "All Letters" },
                        { value: "numbers", label: "All Numbers" },
                        { value: "punctuation", label: "Punctuation" }
                    ],
                    advanced: true
                },
                {
                    type: "keyvalueColumnsSelect",
                    label: "23. Operations (keyvalueColumnsSelect)",
                    id: "columnsOperations",
                    placeholder: "Select column",
                    options: [
                        { value: "min", label: "Min", tooltip: "Returns the minimum value in the group." },
                        { value: "max", label: "Max", tooltip: "Returns the maximum value in the group." },
                        { value: "sum", label: "Sum", tooltip: "Returns the sum of all values in the group." },
                        { value: "mean", label: "Mean", tooltip: "Returns the average value of the group." },
                        { value: "count", label: "Count", tooltip: "Counts the number of non-null entries." },
                        { value: "nunique", label: "Distinct Count", tooltip: "Returns the number of distinct elements." },
                        { value: "first", label: "First", tooltip: "Returns the first value in the group." },
                        { value: "last", label: "Last", tooltip: "Returns the last value in the group." },
                        { value: "median", label: "Median", tooltip: "Returns the median value in the group." },
                        { value: "std", label: "Standard Deviation", tooltip: "Returns the standard deviation of the group." },
                        { value: "var", label: "Variance", tooltip: "Returns the variance of the group." },
                        { value: "prod", label: "Product", tooltip: "Returns the product of all values in the group." }
                    ],
                    advanced: true
                }
            ]
        };
        // Component description for tooltips in the menu
        const description = "Form examples";
        // Super constructor call with necessary parameters
        // 1. Do not forget to add the icon in amphi-etl\jupyterlab-amphi\packages\pipeline-components-core\src\icons.ts and in amphi-etl\jupyterlab-amphi\packages\pipeline-components-core\style\icons.
        super("Form Example", "form_example", description, "pandas_df_processor", [], "developer", _icons__WEBPACK_IMPORTED_MODULE_1__.formexampletypescriptIcon, defaultConfig, form);
    }
    // List of additional Python packages required (if any)
    provideImports({ config }) {
        return [];
    }
    // Generates the Python code for processing the form input
    generateComponentCode({ config, inputName, outputName }) {
        let columnsParam = "{";
        if (config.columns && config.columns.length > 0) {
            columnsParam += config.columns.map(column => {
                if (column.key.named) {
                    return `"${column.key.value}": "${column.value}"`;
                }
                else {
                    return `${column.key.value}: "${column.value}"`;
                }
            }).join(", ");
            columnsParam += "}";
        }
        else {
            columnsParam = "{}"; // Ensure columnsParam is always initialized
        }
        // Template for outputting the input data
        const code = `
${outputName} = ${inputName}
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/InlineInput.js":
/*!**********************************************!*\
  !*** ./lib/components/inputs/InlineInput.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InlineInput: () => (/* binding */ InlineInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class InlineInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const inlineDataDefault = `FirstName,LastName,Age
John,Doe,28
Jane,Smith,34
Emily,Jones,45
Michael,Brown,22
Sarah,Wilson,30`;
        const defaultConfig = { inlineData: inlineDataDefault };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "codeTextarea",
                    label: "Inline Data",
                    id: "inlineData",
                    placeholder: "Enter your CSV data here",
                    tooltip: "Type your CSV-like data directly. First line is header. For example:\nID,brand,criteria,assesement\n123,abc,Q9,Y\n145,abc,Q9,Y",
                    advanced: true
                }
            ],
        };
        const description = "Use Inline Input to manually enter data you can use in the pipeline using a CSV-like format.";
        super("Inline Input", "inlineInput", description, "pandas_df_input", [], "inputs", _icons__WEBPACK_IMPORTED_MODULE_1__.editIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd", "from io import StringIO"];
    }
    generateComponentCode({ config, outputName }) {
        const inlineData = config.inlineData.trim();
        if (!inlineData) {
            throw new Error("No inline data provided.");
        }
        const code = `
${outputName}_data = """${inlineData}"""
${outputName} = pd.read_csv(StringIO(${outputName}_data)).convert_dtypes()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/cloud/GoogleSheetsInput.js":
/*!**********************************************************!*\
  !*** ./lib/components/inputs/cloud/GoogleSheetsInput.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GoogleSheetsInput: () => (/* binding */ GoogleSheetsInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class GoogleSheetsInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { sheetOptions: { spreadsheetId: "", range: "Sheet1" } };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "file",
                    label: "Service Account Key",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\\.(json)$",
                    validationMessage: "This field expects a file with a .json extension such as your-service-account-file.json.",
                    advanced: true,
                    connection: "Google Sheet"
                },
                {
                    type: "input",
                    label: "Spreadsheet ID",
                    id: "sheetOptions.spreadsheetId",
                    placeholder: "Enter Google Sheets' name or ID",
                    validation: "^[a-zA-Z0-9-_]+$",
                    validationMessage: "Invalid Spreadsheet ID."
                },
                {
                    type: "input",
                    label: "Range",
                    id: "sheetOptions.range",
                    placeholder: "e.g., Sheet1 or Sheet1!A1:D5",
                    validation: "^[a-zA-Z0-9-_!]+$",
                    validationMessage: "Invalid Range."
                }
            ],
        };
        const description = "Use Google Sheet Input to retrieve spreadsheet data from a Google Sheet using its ID.";
        super("G. Sheets Input", "googleSheetsInput", description, "pandas_df_input", [], "inputs", _icons__WEBPACK_IMPORTED_MODULE_1__.googleSheetsIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('gspread');
        return deps;
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import gspread", "from oauth2client.service_account import ServiceAccountCredentials"];
    }
    generateComponentCode({ config, outputName }) {
        // Initialize an object to modify without affecting the original config
        let sheetOptions = { ...config.sheetOptions };
        // Check if service account file path is provided and not empty
        const isServiceAccountProvided = !!config.filePath && config.filePath.trim() !== '';
        // Prepare options string for pd.read_gbq
        let optionsString = Object.entries(sheetOptions)
            .filter(([key, value]) => value !== null && value !== '')
            .map(([key, value]) => `${key}="${value}"`)
            .join(', ');
        // Unique variables for each instance
        const uniqueClientVar = `${outputName}Client`;
        const uniqueSheetVar = `${outputName}Sheet`;
        // Conditional code based on service account availability
        let authenticationCode = isServiceAccountProvided ?
            `# Authentication with service account
scope = ["https://spreadsheets.google.com/feeds","https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("${config.filePath}", scope)
${uniqueClientVar} = gspread.authorize(creds)
` :
            `# Accessing public sheet without authentication
${uniqueClientVar} = gspread.service_account()
`;
        // Generate the Python code for reading data from Google Sheets
        const code = `
# Reading data from Google Sheets
${authenticationCode}
# Open the spreadsheet
${uniqueSheetVar} = ${uniqueClientVar}.open_by_key(${sheetOptions.spreadsheetId ? `"${sheetOptions.spreadsheetId}"` : 'None'}).worksheet(${sheetOptions.range ? `"${sheetOptions.range.split('!')[0]}"` : 'None'})
  
# Convert to DataFrame
${outputName} = pd.DataFrame(${uniqueSheetVar}.get_all_records())
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/cloud/RestInput.js":
/*!**************************************************!*\
  !*** ./lib/components/inputs/cloud/RestInput.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RestInput: () => (/* binding */ RestInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class RestInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { method: "GET", headers: [] };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "input",
                    label: "URL",
                    id: "url",
                    placeholder: "Endpoint URL",
                },
                {
                    type: "radio",
                    label: "Method",
                    id: "method",
                    options: [
                        { value: "GET", label: "GET" },
                        { value: "PUT", label: "PUT" },
                        { value: "POST", label: "POST" },
                        { value: "DELETE", label: "DELETE" }
                    ],
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Headers",
                    id: "headers",
                    advanced: true
                },
                {
                    type: "textarea",
                    label: "Body",
                    id: "body",
                    placeholder: "Write body in JSON",
                    advanced: true
                },
                {
                    type: "input",
                    label: "JSON Path",
                    id: "jsonPath",
                    placeholder: "JSON Path to retrieve from response",
                    advanced: true
                }
            ],
        };
        const description = "Use REST Input to perform GET, PUT, POST, and DELETE requests on REST endpoints.";
        super("REST Input", "restInput", description, "pandas_df_input", [], "inputs", _icons__WEBPACK_IMPORTED_MODULE_1__.apiIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import json", "import requests", "from jsonpath_ng import parse"];
    }
    generateComponentCode({ config, outputName }) {
        let bodyParam = '';
        if (config.body && config.body.trim() !== '') {
            // JSON body as a Python dictionary
            bodyParam = `json=${config.body.trim()}, `;
        }
        let headersParam = '';
        if (config.headers && config.headers.length > 0) {
            headersParam = 'headers={' + config.headers.map(header => `"${header.key}": "${header.value}"`).join(', ') + '}, ';
        }
        let jsonPathParam = '';
        if (config.jsonPath && config.jsonPath.trim() !== '') {
            jsonPathParam = `${outputName}_jsonpath_expr = parse('${config.jsonPath}')\nselected_data = [match.value for match in ${outputName}_jsonpath_expr.find(${outputName}_data)] if ${outputName}_jsonpath_expr.find(${outputName}_data) else []\n${outputName} = pd.DataFrame(selected_data).convert_dtypes() if selected_data else pd.DataFrame()\n`;
        }
        else {
            jsonPathParam = `${outputName} = pd.DataFrame([${outputName}_data]).convert_dtypes() if isinstance(data, dict) else pd.DataFrame(${outputName}_data).convert_dtypes()\n`;
        }
        const params = `${headersParam}${bodyParam}`;
        const trimmedParams = params.endsWith(', ') ? params.slice(0, -2) : params; // Remove trailing comma and space if present
        const code = `
${outputName}_response = requests.request(
  method="${config.method}",
  url="${config.url}"${trimmedParams ? ', ' + trimmedParams : ''}
)
${outputName}_data = ${outputName}_response.json()
${jsonPathParam}
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/databases/MySQLInput.js":
/*!*******************************************************!*\
  !*** ./lib/components/inputs/databases/MySQLInput.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MySQLInput: () => (/* binding */ MySQLInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class MySQLInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { host: "localhost", port: "3306", databaseName: "", username: "", password: "", tableName: "", queryMethod: "table" };
        const form = {
            fields: [
                {
                    type: "input",
                    label: "Host",
                    id: "host",
                    placeholder: "Enter database host",
                    connection: 'Mysql',
                    advanced: true
                },
                {
                    type: "input",
                    label: "Port",
                    id: "port",
                    placeholder: "Enter database port",
                    connection: 'Mysql',
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "databaseName",
                    placeholder: "Enter database name",
                    connection: 'Mysql',
                    advanced: true
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "Mysql",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Password",
                    id: "password",
                    placeholder: "Enter password",
                    inputType: "password",
                    connection: "Mysql",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Query Method",
                    id: "queryMethod",
                    tooltip: "Select whether you want to specify the table name to retrieve data or use a custom SQL query for greater flexibility.",
                    options: [
                        { value: "table", label: "Table Name" },
                        { value: "query", label: "SQL Query" }
                    ],
                    advanced: true
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SHOW TABLES;`,
                    id: "tableName",
                    placeholder: "Enter table name",
                    condition: { queryMethod: "table" }
                },
                {
                    type: "codeTextarea",
                    label: "SQL Query",
                    height: '50px',
                    mode: "sql",
                    placeholder: 'SELECT * FROM table_name',
                    id: "sqlQuery",
                    tooltip: 'Optional. By default the SQL query is: SELECT * FROM table_name_provided. If specified, the SQL Query is used.',
                    advanced: true,
                    condition: { queryMethod: "query" }
                }
            ],
        };
        const description = "Use MySQL Input to retrieve data from MySQL by specifying either a table name or a custom SQL query.";
        super("MySQL Input", "mySQLInput", description, "pandas_df_input", [], "inputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.mySQLIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('pymysql');
        return deps;
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import sqlalchemy", "import pymysql"];
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        let connectionString = `mysql+pymysql://${config.username}:${config.password}@${config.host}:${config.port}/${config.databaseName}`;
        const connectionCode = `
# Connect to the MySQL database
${connectionName} = sqlalchemy.create_engine("${connectionString}")
`;
        return connectionCode;
    }
    generateComponentCode({ config, outputName }) {
        const uniqueEngineName = `${outputName}_Engine`; // Unique engine name based on the outputName
        const sqlQuery = config.queryMethod === 'query' && config.sqlQuery && config.sqlQuery.trim()
            ? config.sqlQuery
            : `SELECT * FROM ${config.tableName.value}`;
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        const code = `
${connectionCode}

# Execute SQL statement
try:
    with ${uniqueEngineName}.connect() as conn:
        ${outputName} = pd.read_sql(
            """
            ${sqlQuery}
            """,
            con=conn.connection
        ).convert_dtypes()
finally:
    ${uniqueEngineName}.dispose()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/databases/ODBCInput.js":
/*!******************************************************!*\
  !*** ./lib/components/inputs/databases/ODBCInput.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ODBCInput: () => (/* binding */ ODBCInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class ODBCInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            connectionString: "",
            queryMethod: "table",
            tableName: "",
            sqlQuery: "",
            autoCommit: true
        };
        const form = {
            fields: [
                {
                    type: "input",
                    label: "Connection String",
                    id: "connectionString",
                    placeholder: "Enter ODBC connection string",
                    tooltip: "Provide the full ODBC connection string for your database. Reference: https://github.com/mkleehammer/pyodbc/wiki/Connecting-to-databases",
                    connection: "ODBC",
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Auto Commit",
                    tooltip: "Setting autocommit True will cause the database to issue a commit after each SQL statement, otherwise database transactions will have to be explicity committed. As per the Python DB API, the default value is False (even though the ODBC default value is True). Typically, you will probably want to set autocommit True when creating a connection.",
                    id: "autoCommit",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Query Method",
                    id: "queryMethod",
                    tooltip: "Select whether you want to specify the table name to retrieve data or use a custom SQL query for greater flexibility.",
                    options: [
                        { value: "table", label: "Table Name" },
                        { value: "query", label: "SQL Query" }
                    ],
                    advanced: true
                },
                {
                    type: "input",
                    label: "Table Name",
                    id: "tableName",
                    placeholder: "Enter table name",
                    condition: { queryMethod: "table" }
                },
                {
                    type: "codeTextarea",
                    label: "SQL Query",
                    height: '50px',
                    mode: "sql",
                    placeholder: 'SELECT * FROM table_name',
                    id: "sqlQuery",
                    tooltip: 'Optional. By default the SQL query is: SELECT * FROM table_name_provided. If specified, the SQL Query is used.',
                    condition: { queryMethod: "query" },
                    advanced: true
                }
            ],
        };
        const description = "Use ODBC Input to retrieve data from various databases using an ODBC connection string, along with either a table name or a custom SQL query.";
        super("ODBC Input", "odbcInput", description, "pandas_df_input", [], "inputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.databaseIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        return ['pyodbc'];
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import pyodbc"];
    }
    generateComponentCode({ config, outputName }) {
        // Escape single quotes in the connection string
        const connectionString = config.connectionString.replace(/'/g, "\\'");
        const autoCommit = config.autoCommit;
        const sqlQuery = config.queryMethod === 'query' && config.sqlQuery && config.sqlQuery.trim()
            ? config.sqlQuery
            : `SELECT * FROM ${config.tableName}`;
        const code = `
# Connect to the database using ODBC
conn = pyodbc.connect(f"""${connectionString}""", autocommit=${autoCommit ? 'True' : 'False'})

# Execute SQL statement
try:
    ${outputName} = pd.read_sql(
        """
        ${sqlQuery}
        """,
        conn
    ).convert_dtypes()
finally:
    conn.close()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/databases/OracleInput.js":
/*!********************************************************!*\
  !*** ./lib/components/inputs/databases/OracleInput.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OracleInput: () => (/* binding */ OracleInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class OracleInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { host: "localhost", port: "1521", databaseName: "", username: "", password: "", tableName: "", queryMethod: "table", dbapi: "oracledb" };
        const form = {
            fields: [
                {
                    type: "input",
                    label: "Host",
                    id: "host",
                    placeholder: "Enter database host",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Port",
                    id: "port",
                    placeholder: "Enter database port",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "databaseName",
                    placeholder: "Enter database name",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Password",
                    id: "password",
                    placeholder: "Enter password",
                    inputType: "password",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Query Method",
                    id: "queryMethod",
                    tooltip: "Select whether you want to specify the table name to retrieve data or use a custom SQL query for greater flexibility.",
                    options: [
                        { value: "table", label: "Table Name" },
                        { value: "query", label: "SQL Query" }
                    ],
                    advanced: true
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SELECT table_name FROM user_tables;`,
                    id: "tableName",
                    condition: { queryMethod: "table" },
                    placeholder: "Enter table name"
                },
                {
                    type: "codeTextarea",
                    label: "SQL Query",
                    height: '50px',
                    mode: "sql",
                    placeholder: 'SELECT * FROM table_name',
                    id: "sqlQuery",
                    tooltip: 'Optional. By default the SQL query is: SELECT * FROM table_name_provided. If specified, the SQL Query is used.',
                    condition: { queryMethod: "query" },
                    advanced: true
                },
                {
                    type: "input",
                    label: "Oracle Client Path (Optional)",
                    tooltip: "You might need to specify a different Oracle client path than the default one. To do this, use the option to point to the directory of the desired Oracle client.",
                    id: "oracleClient",
                    placeholder: "Specify oracle client path",
                    advanced: true
                },
                {
                    type: "select",
                    label: "Database API (DBAPI)",
                    tooltip: "",
                    id: "dbapi",
                    options: [
                        { value: "cx_Oracle", label: "cx-Oracle" },
                        { value: "oracledb", label: "python-oracledb" }
                    ],
                    advanced: true
                }
            ],
        };
        const description = "Use Oracle Input to retrieve data from an Oracle database by specifying either a table name or a custom SQL query.";
        super("Oracle Input", "oracleInput", description, "pandas_df_input", [], "inputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.oracleIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        if (config.dbapi === 'cx_Oracle') {
            deps.push("cx_Oracle");
        }
        else if (config.dbapi === 'oracledb') {
            deps.push("oracledb");
        }
        return deps;
    }
    provideImports({ config }) {
        const imports = ["import pandas as pd", "import sqlalchemy"];
        if (config.dbapi === 'cx_Oracle') {
            imports.push("import cx_Oracle");
        }
        else if (config.dbapi === 'oracledb') {
            imports.push("import oracledb");
        }
        return imports;
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        const dbapi = config.dbapi;
        // Initialize the Oracle client if oracleClient is provided
        const oracleClientInitialization = config.oracleClient && config.oracleClient.trim()
            ? `${dbapi}.init_oracle_client(lib_dir="${config.oracleClient}")\n`
            : "";
        let connectionString = `oracle+${dbapi}://${config.username}:${config.password}@${config.host}:${config.port}/?service_name=${config.databaseName}`;
        const connectionCode = `
# Connect to the Oracle database
${oracleClientInitialization}${connectionName} = sqlalchemy.create_engine("${connectionString}")
`;
        return connectionCode;
    }
    generateComponentCode({ config, outputName }) {
        const uniqueEngineName = `${outputName}_Engine`; // Unique engine name based on the outputName
        const sqlQuery = config.queryMethod === 'query' && config.sqlQuery && config.sqlQuery.trim()
            ? config.sqlQuery
            : `SELECT * FROM ${config.tableName.value}`;
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        const code = `
${connectionCode}

# Execute SQL statement
try:
    with ${uniqueEngineName}.connect() as conn:
        ${outputName} = pd.read_sql(
            """
            ${sqlQuery}
            """,
            con=conn.connection
        ).convert_dtypes()
finally:
    ${uniqueEngineName}.dispose()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/databases/PostgresInput.js":
/*!**********************************************************!*\
  !*** ./lib/components/inputs/databases/PostgresInput.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PostgresInput: () => (/* binding */ PostgresInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class PostgresInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { host: "localhost", port: "5432", databaseName: "", username: "", password: "", schema: "public", tableName: "", queryMethod: "table" };
        const form = {
            fields: [
                {
                    type: "input",
                    label: "Host",
                    id: "host",
                    placeholder: "Enter database host",
                    connection: "Postgres",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Port",
                    id: "port",
                    placeholder: "Enter database port",
                    connection: "Postgres",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "databaseName",
                    placeholder: "Enter database name",
                    connection: "Postgres",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "Postgres",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Password",
                    id: "password",
                    placeholder: "Enter password",
                    connection: "Postgres",
                    inputType: "password",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Schema",
                    id: "schema",
                    placeholder: "Enter schema name",
                },
                {
                    type: "radio",
                    label: "Query Method",
                    id: "queryMethod",
                    tooltip: "Select whether you want to specify the table name to retrieve data or use a custom SQL query for greater flexibility.",
                    options: [
                        { value: "table", label: "Table Name" },
                        { value: "query", label: "SQL Query" }
                    ],
                    advanced: true
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';`,
                    id: "tableName",
                    placeholder: "Enter table name",
                    condition: { queryMethod: "table" }
                },
                {
                    type: "codeTextarea",
                    label: "SQL Query",
                    height: '50px',
                    mode: "sql",
                    placeholder: 'SELECT * FROM table_name',
                    id: "sqlQuery",
                    tooltip: 'Optional. By default the SQL query is: SELECT * FROM table_name_provided. If specified, the SQL Query is used.',
                    condition: { queryMethod: "query" },
                    advanced: true
                }
            ],
        };
        const description = "Use Postgres Input to retrieve data from Postgres by specifying either a table name or a custom SQL query.";
        super("Postgres Input", "postgresInput", description, "pandas_df_input", [], "inputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.postgresIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('psycopg2-binary');
        return deps;
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import sqlalchemy", "import psycopg2"];
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        let connectionString = `postgresql://${config.username}:${config.password}@${config.host}:${config.port}/${config.databaseName}`;
        const connectionCode = `
# Connect to the PostgreSQL database
${connectionName} = sqlalchemy.create_engine("${connectionString}")
`;
        return connectionCode;
    }
    generateComponentCode({ config, outputName }) {
        const uniqueEngineName = `${outputName}_Engine`; // Unique engine name based on the outputName
        const tableReference = `"${config.schema}"."${config.tableName.value}"`;
        const sqlQuery = config.queryMethod === 'query' && config.sqlQuery && config.sqlQuery.trim()
            ? config.sqlQuery
            : `SELECT * FROM ${tableReference}`;
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        const code = `
${connectionCode}

# Execute SQL statement
try:
    with ${uniqueEngineName}.connect() as conn:
        ${outputName} = pd.read_sql(
            """
            ${sqlQuery}
            """,
            con=conn.connection
        ).convert_dtypes()
finally:
    ${uniqueEngineName}.dispose()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/databases/SnowflakeInput.js":
/*!***********************************************************!*\
  !*** ./lib/components/inputs/databases/SnowflakeInput.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SnowflakeInput: () => (/* binding */ SnowflakeInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class SnowflakeInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { schema: "PUBLIC", tableName: "", queryMethod: "table" };
        const form = {
            fields: [
                {
                    type: "input",
                    label: "Account",
                    id: "account",
                    placeholder: "Enter Account",
                    connection: "Snowflake",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "database",
                    connection: "Snowflake",
                    placeholder: "Enter database name",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "Snowflake",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Password",
                    id: "password",
                    placeholder: "Enter password",
                    connection: "Snowflake",
                    inputType: "password",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Warehouse",
                    id: "warehouse",
                    placeholder: "Enter warehouse name",
                    connection: "Snowflake",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Schema",
                    id: "schema",
                    connection: "Snowflake",
                    placeholder: "Enter schema name",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Query Method",
                    id: "queryMethod",
                    tooltip: "Select whether you want to specify the table name to retrieve data or use a custom SQL query for greater flexibility.",
                    options: [
                        { value: "table", label: "Table Name" },
                        { value: "query", label: "SQL Query" }
                    ],
                    advanced: true
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SELECT table_name FROM information_schema.tables WHERE table_schema = '{{schema}}'`,
                    id: "tableName",
                    placeholder: "Enter table name",
                    condition: { queryMethod: "table" }
                },
                {
                    type: "codeTextarea",
                    label: "SQL Query",
                    height: '50px',
                    mode: "sql",
                    placeholder: 'SELECT * FROM table_name',
                    id: "sqlQuery",
                    tooltip: 'Optional. By default the SQL query is: SELECT * FROM table_name_provided. If specified, the SQL Query is used.',
                    condition: { queryMethod: "query" },
                    advanced: true
                },
                {
                    type: "input",
                    label: "Role (Optional)",
                    id: "role",
                    placeholder: "Role name",
                    advanced: true
                }
            ],
        };
        const description = "Use Snowflake Input to retrieve data from Snowflake by specifying either a table name or a custom SQL query.";
        super("Snowflake Input", "snowflakeInput", description, "pandas_df_input", [], "inputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.snowflakeIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('snowflake-sqlalchemy');
        return deps;
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import sqlalchemy", "import urllib.parse", "from snowflake.sqlalchemy import URL"];
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        const connectionCode = `
# Connect to the Snowflake database
${connectionName} = sqlalchemy.create_engine(URL(
    account = '${config.account}',
    user = '${config.username}',
    password = urllib.parse.quote("${config.password}"),
    database = '${config.database}',
    schema = '${config.schema}',
    warehouse = '${config.warehouse}'
))
`;
        return connectionCode;
    }
    generateComponentCode({ config, outputName }) {
        const uniqueEngineName = `${outputName}_Engine`; // Unique engine name based on the outputName
        const tableReference = (config.schema && config.schema.toLowerCase() !== 'public')
            ? `"${config.schema}"."${config.tableName.value}"`
            : `"${config.tableName.value}"`;
        const sqlQuery = config.queryMethod === 'query' && config.sqlQuery && config.sqlQuery.trim()
            ? config.sqlQuery
            : `SELECT * FROM ${tableReference}`;
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        const code = `
${connectionCode}

# Execute SQL statement
try:
    with ${uniqueEngineName}.connect() as conn:
        ${outputName} = pd.read_sql(
            """
            ${sqlQuery}
            """,
            con=conn.connection
        ).convert_dtypes()
finally:
    ${uniqueEngineName}.dispose()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/databases/SqlServerInput.js":
/*!***********************************************************!*\
  !*** ./lib/components/inputs/databases/SqlServerInput.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SqlServerInput: () => (/* binding */ SqlServerInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class SqlServerInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { host: "localhost", port: "1433", databaseName: "", username: "", password: "", tableName: "", queryMethod: "table" };
        const form = {
            fields: [
                {
                    type: "input",
                    label: "Host",
                    id: "host",
                    placeholder: "Enter database host",
                    connection: "SQL Server",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Port",
                    id: "port",
                    placeholder: "Enter database port",
                    connection: "SQL Server",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "databaseName",
                    placeholder: "Enter database name",
                    connection: "SQL Server",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "SQL Server",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Password",
                    id: "password",
                    placeholder: "Enter password",
                    connection: "SQL Server",
                    inputType: "password",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Query Method",
                    id: "queryMethod",
                    tooltip: "Select whether you want to specify the table name to retrieve data or use a custom SQL query for greater flexibility.",
                    options: [
                        { value: "table", label: "Table Name" },
                        { value: "query", label: "SQL Query" }
                    ],
                    advanced: true
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE';`,
                    id: "tableName",
                    condition: { queryMethod: "table" },
                    placeholder: "Enter table name"
                },
                {
                    type: "codeTextarea",
                    label: "SQL Query",
                    height: '50px',
                    mode: "sql",
                    placeholder: 'SELECT * FROM table_name',
                    id: "sqlQuery",
                    tooltip: 'Optional. By default the SQL query is: SELECT * FROM table_name_provided. If specified, the SQL Query is used.',
                    condition: { queryMethod: "query" },
                    advanced: true
                },
                {
                    type: "info",
                    label: "Drivers installation",
                    id: "driversInstallation",
                    text: "You may need to install additional drivers on your machine for this component to function. /n For Mac you need to install 'brew install unixodbc'",
                    advanced: true
                },
            ],
        };
        const description = "Use SQL Server Input to retrieve data from SQL Server by specifying either a table name or a custom SQL query.";
        super("SQL Server Input", "sqlServerInput", description, "pandas_df_input", [], "inputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.sqlServerIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('pyodbc');
        return deps;
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import sqlalchemy", "import pyodbc"];
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        let connectionString = `mssql+pyodbc://${config.username}:${config.password}@${config.host}:${config.port}/${config.databaseName}?driver=ODBC+Driver+17+for+SQL+Server`;
        const connectionCode = `
# Connect to the SQL Server database
${connectionName} = sqlalchemy.create_engine("${connectionString}")
`;
        return connectionCode;
    }
    generateComponentCode({ config, outputName }) {
        const uniqueEngineName = `${outputName}_Engine`; // Unique engine name based on the outputName
        const sqlQuery = config.queryMethod === 'query' && config.sqlQuery && config.sqlQuery.trim()
            ? config.sqlQuery
            : `SELECT * FROM ${config.tableName.value}`;
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        const code = `
${connectionCode}

# Execute SQL statement
try:
    with ${uniqueEngineName}.connect() as conn:
        ${outputName} = pd.read_sql(
            """
            ${sqlQuery}
            """,
            con=conn.connection
        ).convert_dtypes()
finally:
    ${uniqueEngineName}.dispose()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/AzureBlobFileInput.js":
/*!***********************************************************!*\
  !*** ./lib/components/inputs/files/AzureBlobFileInput.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AzureBlobFileInput: () => (/* binding */ AzureBlobFileInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CsvFileInput */ "./lib/components/inputs/files/CsvFileInput.js");
/* harmony import */ var _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./JsonFileInput */ "./lib/components/inputs/files/JsonFileInput.js");
/* harmony import */ var _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ExcelFileInput */ "./lib/components/inputs/files/ExcelFileInput.js");
/* harmony import */ var _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ParquetFileInput */ "./lib/components/inputs/files/ParquetFileInput.js");
/* harmony import */ var _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./XmlFileInput */ "./lib/components/inputs/files/XmlFileInput.js");







class AzureBlobFileInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileType: "csv", fileLocation: "azb", connectionMethod: "env" };
        const csvComponent = new _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__.CsvFileInput();
        const jsonComponent = new _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__.JsonFileInput();
        const excelComponent = new _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileInput();
        const parquetComponent = new _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileInput();
        const xmlComponent = new _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__.XmlFileInput();
        const fieldsToRemove = ["fileLocation"]; // Fields to remove from all components
        const filteredCsvFields = csvComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredJsonFields = jsonComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredExcelFields = excelComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredParquetFields = parquetComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredXmlFields = xmlComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Type",
                    id: "fileType",
                    options: [
                        { value: "csv", label: "CSV" },
                        { value: "json", label: "JSON" },
                        { value: "excel", label: "Excel" },
                        { value: "parquet", label: "Parquet" },
                        { value: "xml", label: "XML" }
                    ]
                },
                // Conditionally display filtered fields based on selected file type
                ...filteredCsvFields.map(field => ({
                    ...field,
                    condition: { fileType: ["csv"], ...(field.condition || {}) }
                })),
                ...filteredJsonFields.map(field => ({
                    ...field,
                    condition: { fileType: ["json"], ...(field.condition || {}) }
                })),
                ...filteredExcelFields.map(field => ({
                    ...field,
                    condition: { fileType: ["excel"], ...(field.condition || {}) }
                })),
                ...filteredParquetFields.map(field => ({
                    ...field,
                    condition: { fileType: ["parquet"], ...(field.condition || {}) }
                })),
                ...filteredXmlFields.map(field => ({
                    ...field,
                    condition: { fileType: ["xml"], ...(field.condition || {}) }
                }))
            ]
        };
        const description = "Use File Input to read data from a file remotely (Azure blob). Supports CSV, JSON, Excel, Parquet, and XML formats.";
        super("Azure Blob File Input", "azureBlobFileInput", description, "pandas_df_input", [], "inputs.AZB", _icons__WEBPACK_IMPORTED_MODULE_6__.azureServicesIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('adlfs');
        return deps;
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports;
    }
    generateComponentCode({ config, outputName }) {
        console.log("configconfigconfigconfigconfigconfig=", config);
        if (config.fileType === "csv") {
            const csvComponent = new _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__.CsvFileInput();
            return csvComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "json") {
            const jsonComponent = new _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__.JsonFileInput();
            return jsonComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "excel") {
            const excelComponent = new _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileInput();
            return excelComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "parquet") {
            const parquetComponent = new _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileInput();
            return parquetComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "xml") {
            const xmlComponent = new _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__.XmlFileInput();
            return xmlComponent.generateComponentCode({ config, outputName });
        }
        return '';
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/CsvFileInput.js":
/*!*****************************************************!*\
  !*** ./lib/components/inputs/files/CsvFileInput.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CsvFileInput: () => (/* binding */ CsvFileInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");
/* harmony import */ var _common_FileUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../common/FileUtils */ "./lib/components/common/FileUtils.js");
/* harmony import */ var _common_AzureOptionsHandler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/AzureOptionsHandler */ "./lib/components/common/AzureOptionsHandler.js");



 // Import the FileUtils class

class CsvFileInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            fileLocation: "local",
            connectionMethod: "env",
            csvOptions: {
                sep: ","
            }
        };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "http", label: "HTTP" },
                        { value: "s3", label: "S3" },
                        { value: "azb", label: "AZBLOB" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                ..._common_AzureOptionsHandler__WEBPACK_IMPORTED_MODULE_2__.AzureOptionsHandler.getAZBFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name or use '*' for patterns",
                    tooltip: "Provide a single CSV file path or use '*' for matching multiple files. Extensions accepted: .csv, .tsv, .txt. Can also read CSV files compressed as .gz, .bz2, .zip, .xz, .zst.",
                    validation: "^(.*(\\.csv|\\.tsv|\\.txt))$|^(.*\\*)$"
                },
                {
                    type: "selectCustomizable",
                    label: "Separator",
                    id: "csvOptions.sep",
                    placeholder: "default: ,",
                    tooltip: "Select or provide a custom delimiter.",
                    options: [
                        { value: ",", label: "comma (,)" },
                        { value: ";", label: "semicolon (;)" },
                        { value: " ", label: "space" },
                        { value: "\\t", label: "tab" },
                        { value: "|", label: "pipe (|)" },
                        { value: "infer", label: "infer (tries to auto detect)" }
                    ],
                },
                {
                    type: "inputNumber",
                    tooltip: "Number of rows of file to read. Useful for reading pieces of large files.",
                    label: "Rows number",
                    id: "csvOptions.nrows",
                    placeholder: "Default: all",
                    min: 0,
                    advanced: true
                },
                {
                    type: "selectCustomizable",
                    label: "Decimal separator",
                    id: "csvOptions.decimal",
                    placeholder: "Default: .",
                    tooltip: "Character to recognize as decimal point for parsing string columns to numeric. Note that this parameter is only necessary for columns stored as TEXT in Excel, any numeric columns will automatically be parsed, regardless of display format.(e.g. use , for European data).",
                    options: [
                        { value: ".", label: "." },
                        { value: ",", label: "," }
                    ],
                    advanced: true
                },
                {
                    type: "selectTokenization",
                    tooltip: "Sequence of column labels to apply.",
                    label: "Column names",
                    id: "csvOptions.names",
                    placeholder: "Type header fields (ordered and comma-separated)",
                    options: [],
                    advanced: true
                },
                {
                    type: "input",
                    label: "Wrapper Character",
                    id: "csvOptions.quotechar",
                    tooltip: "Defines the character used to wrap fields containing special characters like the delimiter or newline.",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Escaped character",
                    id: "csvOptions.escapechar",
                    tooltip: "Character used to escape other characters.",
                    advanced: true
                },
                {
                    type: "select",
                    label: "On Bad Lines",
                    id: "csvOptions.on_bad_lines",
                    placeholder: "Error: raise an Exception when a bad line is encountered",
                    options: [
                        { value: "error", label: "Error", tooltip: "Raise an Exception when a bad line is encountered" },
                        { value: "warn", label: "Warn", tooltip: "Raise a warning when a bad line is encountered and skip that line." },
                        { value: "skip", label: "Skip", tooltip: "Skip bad lines without raising or warning when they are encountered." }
                    ],
                    advanced: true
                },
                {
                    type: "select",
                    label: "Engine",
                    id: "csvOptions.engine",
                    placeholder: "Select engine",
                    options: [
                        { value: "python", label: "python", tooltip: "Python is more feature complete." },
                        { value: "c", label: "c", tooltip: "C is faster." },
                        { value: "pyarrow", label: "pyarrow", tooltip: "The pyarrow engine was added as an experimental engine, and some features are unsupported, or may not work correctly, with this engine." }
                    ],
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "csvOptions.storage_options",
                    condition: { fileLocation: ["http", "s3", "azb"] },
                    advanced: true
                }
            ],
        };
        const description = "Use CSV File Input to access data from a CSV file or multiple CSV files using a wildcard, locally or remotely (via HTTP or S3).";
        super("CSV File Input", "csvFileInput", description, "pandas_df_input", ["csv", "tsv"], "inputs", _icons__WEBPACK_IMPORTED_MODULE_3__.fileCsvIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        if (config.csvOptions.engine === "pyarrow") {
            deps.push('pyarrow');
        }
        if (config.fileLocation === "s3") {
            deps.push('s3fs');
        }
        if (config.fileLocation === "azb") {
            deps.push('adlfs');
        }
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.isWildcardInput(config.filePath)) {
            deps.push(config.fileLocation === "s3" ? 's3fs' : config.fileLocation === "azb" ? 'adlfs' : 'glob');
        }
        return deps;
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.isWildcardInput(config.filePath)) {
            if (config.fileLocation === "s3") {
                imports.push("import s3fs");
            }
            else if (config.fileLocation === "azb") {
                imports.push("import adlfs");
            }
            else {
                imports.push("import glob");
            }
        }
        return imports;
    }
    // Utility method to determine if input uses a wildcard
    // Main generation method
    generateComponentCode({ config, outputName }) {
        const optionsString = this.generateOptionsCode({ config });
        const storageOptionsString = config.csvOptions.storage_options ? JSON.stringify(config.csvOptions.storage_options) : '{}';
        let code = '';
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.isWildcardInput(config.filePath)) {
            if (config.fileLocation === "s3") {
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.getS3FilePaths(config.filePath, storageOptionsString, outputName);
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.generateConcatCode(outputName, "read_csv", optionsString, true);
            }
            if (config.fileLocation === "azb") {
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.getADLSFilePaths(config.filePath, storageOptionsString, outputName);
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.generateConcatCode(outputName, "read_csv", optionsString, true);
            }
            else {
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.getLocalFilePaths(config.filePath, outputName);
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_4__.FileUtils.generateConcatCode(outputName, "read_csv", optionsString, false);
            }
        }
        else {
            code = `
fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x);
# Reading data---- from ${config.filePath}
${outputName} = pd.read_csv("${config.filePath}"${optionsString}).convert_dtypes()
      `;
        }
        return code.trim();
    }
    generateOptionsCode({ config }) {
        let csvOptions = { ...config.csvOptions };
        if (csvOptions.sep === 'infer') {
            csvOptions.sep = 'None';
            csvOptions.engine = 'python';
        }
        if (config.header === '0' || config.header === '1' || config.header === 'None') {
            csvOptions.header = config.header;
        }
        if (csvOptions.names && csvOptions.names.length > 0) {
            csvOptions.names = `['${csvOptions.names.join("', '")}']`;
            csvOptions.header = 0;
        }
        let storageOptions = csvOptions.storage_options || {};
        // Transform storage_options array into the correct format
        if (Array.isArray(storageOptions)) {
            const transformedStorageOptions = storageOptions.reduce((acc, item) => {
                acc[item.key] = item.value;
                return acc;
            }, {});
            // Merge transformed options with the S3-specific options
            const s3Options = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, {});
            storageOptions = { ...transformedStorageOptions, ...s3Options };
        }
        else {
            // Ensure S3-specific options are handled when storageOptions is not an array
            storageOptions = config.fileLocation === 'azb' ?
                _common_AzureOptionsHandler__WEBPACK_IMPORTED_MODULE_2__.AzureOptionsHandler.handleAZBptions(config, storageOptions)
                : _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions);
        }
        // Update the storage_options in csvOptions
        if (Object.keys(storageOptions).length > 0) {
            csvOptions.storage_options = storageOptions;
        }
        const optionsEntries = Object.entries(csvOptions)
            .filter(([key, value]) => value !== null &&
            value !== '' &&
            !(key === 'sep' && value === 'None') &&
            (Array.isArray(value) ? value.length > 0 : true))
            .map(([key, value]) => {
            if (key === 'header' && (value === '0' || value === '1' || value === 'None')) {
                return `${key}=${value}`;
            }
            else if (key === 'names') {
                return `${key}=${value}`;
            }
            else if (key === 'storage_options') {
                return `${key}=${JSON.stringify(value)}`;
            }
            else if (value == '"') {
                return `${key}='${value}'`;
            }
            else if (typeof value === 'string' && value !== 'None') {
                return `${key}="${value}"`;
            }
            else {
                return `${key}=${value}`;
            }
        });
        // Prepend a comma if there are options
        return optionsEntries.length > 0 ? `, ${optionsEntries.join(', ')}` : '';
    }
    generateSampledComponentCode({ config, outputName, nrows }) {
        config = {
            ...config,
            csvOptions: {
                ...config.csvOptions,
                nrows: nrows
            }
        };
        return this.generateComponentCode({ config, outputName });
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/ExcelFileInput.js":
/*!*******************************************************!*\
  !*** ./lib/components/inputs/files/ExcelFileInput.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExcelFileInput: () => (/* binding */ ExcelFileInput)
/* harmony export */ });
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");
/* harmony import */ var _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/FileUtils */ "./lib/components/common/FileUtils.js");



 // Import the FileUtils class
class ExcelFileInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env", excelOptions: { engine: "None" } };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "http", label: "HTTP" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name or use '*' for patterns",
                    validation: "\\.(xlsx)$|^(.*\\*)$",
                    tooltip: "This field expects a file with an xlsx extension or a wildcard pattern such as input*.xlsx."
                },
                {
                    type: "sheets",
                    label: "Sheets",
                    id: "excelOptions.sheet_name",
                    placeholder: "Default: 0 (first sheet)",
                    tooltip: "Select one or multiple sheets. If multiple sheets are selected, the sheets are concatenated to output a single dataset.",
                    condition: { fileLocation: "local" }
                },
                {
                    type: "selectTokenization",
                    label: "Sheets",
                    id: "excelOptions.sheet_name",
                    placeholder: "Default: 0 (first sheet)",
                    tooltip: "Type the sheet names to read data from. If multiple sheets are provided, the sheets are concatenated to output a single dataset.",
                    options: [],
                    condition: { fileLocation: ["http", "s3"] }
                },
                {
                    type: "selectCustomizable",
                    label: "Header",
                    id: "excelOptions.header",
                    placeholder: "default: 0 (first row)",
                    options: [
                        { value: "0", label: "0 (1st row)" },
                        { value: "1", label: "1 (2nd row)" },
                        { value: "None", label: "None (No header)" }
                    ],
                    advanced: true
                },
                {
                    type: "inputNumber",
                    tooltip: "Number of rows of file to read. Useful for reading pieces of large files.",
                    label: "Rows number",
                    min: 0,
                    id: "excelOptions.nrows",
                    placeholder: "Default: all",
                    advanced: true
                },
                {
                    type: "inputNumber",
                    tooltip: "Number of rows to skip at the start of the file.",
                    label: "Skip rows at the start",
                    id: "excelOptions.skiprows",
                    min: 0,
                    advanced: true
                },
                {
                    type: "selectCustomizable",
                    label: "Decimal separator",
                    id: "excelOptions.decimal",
                    placeholder: "Default: .",
                    tooltip: "Character to recognize as decimal point for parsing string columns to numeric. Note that this parameter is only necessary for columns stored as TEXT in Excel, any numeric columns will automatically be parsed, regardless of display format.(e.g. use , for European data).",
                    options: [
                        { value: ".", label: "." },
                        { value: ",", label: "," }
                    ],
                    advanced: true
                },
                {
                    type: "select",
                    label: "Engine",
                    id: "excelOptions.engine",
                    tooltip: "Depending on the file format, different engines might be used.\nopenpyxl supports newer Excel file formats.\n calamine supports Excel (.xls, .xlsx, .xlsm, .xlsb) and OpenDocument (.ods) file formats.\n odf supports OpenDocument file formats (.odf, .ods, .odt).\n pyxlsb supports Binary Excel files.\n xlrd supports old-style Excel files (.xls).",
                    options: [
                        { value: "openpyxl", label: "openpyxl" },
                        { value: "calamine", label: "calamine" },
                        { value: "odf", label: "odf (for .ods files)" },
                        { value: "pyxlsb", label: "pyxlsb (for *.xlsb)" },
                        { value: "xlrd", label: "xlrd (for *.xls)" },
                        { value: "None", label: "Default" }
                    ],
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "excelOptions.storage_options",
                    condition: { fileLocation: ["http", "s3"] },
                    advanced: true
                }
            ],
        };
        const description = "Use Excel File Input to access data from Excel files (e.g., xlsx, xls, ods) locally or remotely (via HTTP or S3).";
        super("Excel/ODS File Input", "excelfileInput", description, "pandas_df_input", ["xlsx", "xls", "ods", "xlsb"], "inputs", _icons__WEBPACK_IMPORTED_MODULE_2__.fileExcelIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        const engine = config.excelOptions.engine;
        if (engine === 'None' || engine === 'openpyxl') {
            deps.push('openpyxl');
        }
        else if (engine === 'calamine') {
            deps.push('python-calamine');
        }
        else if (engine === 'odf') {
            deps.push('odfpy');
        }
        else if (engine === 'pyxlsb') {
            deps.push('pyxlsb');
        }
        else if (engine === 'xlrd') {
            deps.push('xlrd');
        }
        else {
            deps.push(config.engine);
        }
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.isWildcardInput(config.filePath)) {
            deps.push(config.fileLocation === "s3" ? 's3fs' : '');
        }
        return deps;
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.isWildcardInput(config.filePath)) {
            if (config.fileLocation === "s3") {
                imports.push("import s3fs");
            }
            else {
                imports.push("import glob");
            }
        }
        return imports;
    }
    generateComponentCode({ config, outputName }) {
        const excelOptions = { ...config.excelOptions };
        const storageOptionsString = excelOptions.storage_options ? JSON.stringify(excelOptions.storage_options) : '{}';
        let optionsString = this.generateOptionsCode(config);
        let code = '';
        // Handle sheet_name dynamically
        if (excelOptions.sheet_name && excelOptions.sheet_name.length > 0) {
            if (excelOptions.sheet_name.length === 1) {
                optionsString += `, sheet_name='${excelOptions.sheet_name[0]}'`;
            }
            else {
                optionsString += `, sheet_name=${JSON.stringify(excelOptions.sheet_name)}`;
            }
        }
        // Check for wildcard input and generate appropriate code
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.isWildcardInput(config.filePath)) {
            if (config.fileLocation === "s3") {
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.getS3FilePaths(config.filePath, storageOptionsString, outputName);
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.generateConcatCode(outputName, "read_excel", optionsString, true);
            }
            else {
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.getLocalFilePaths(config.filePath, outputName);
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.generateConcatCode(outputName, "read_excel", optionsString, false);
            }
        }
        else {
            // Simple file reading without wildcard
            if (excelOptions.sheet_name && excelOptions.sheet_name.length > 1) {
                // Multiple sheets: Concatenate DataFrames into a single output
                code += `${outputName}_dict = pd.read_excel("${config.filePath}"${optionsString})\n`;
                code += `${outputName} = pd.concat(${outputName}_dict.values(), ignore_index=True).convert_dtypes()\n`;
            }
            else {
                // Single sheet or no sheet_name specified
                code += `${outputName} = pd.read_excel("${config.filePath}"${optionsString}).convert_dtypes()\n`;
            }
        }
        return code;
    }
    generateOptionsCode(config) {
        let excelOptions = { ...config.excelOptions };
        let storageOptions = excelOptions.storage_options || {};
        // Transform storage_options array into the correct format
        if (Array.isArray(storageOptions)) {
            const transformedStorageOptions = storageOptions.reduce((acc, item) => {
                acc[item.key] = item.value;
                return acc;
            }, {});
            // Merge transformed options with the S3-specific options
            const s3Options = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, {});
            storageOptions = { ...transformedStorageOptions, ...s3Options };
        }
        else {
            // Ensure S3-specific options are handled when storageOptions is not an array
            storageOptions = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions);
        }
        // Update the storage_options in excelOptions
        if (Object.keys(storageOptions).length > 0) {
            excelOptions.storage_options = storageOptions;
        }
        const options = Object.entries(excelOptions)
            .filter(([key, value]) => value !== null && value !== '' && key !== 'sheet_name') // Ignore sheet_name since it's handled separately
            .map(([key, value]) => {
            if (typeof value === 'boolean') {
                return `${key}=${value ? 'True' : 'False'}`;
            }
            else if (value === "None") {
                return `${key}=None`;
            }
            else if (key === 'storage_options') {
                return `${key}=${JSON.stringify(value)}`;
            }
            else if (/^\d+$/.test(value)) {
                return `${key}=${value}`;
            }
            else if (typeof value === 'string' && value.startsWith('[') && value.endsWith(']')) {
                return `${key}=${value}`;
            }
            else {
                return `${key}='${value}'`;
            }
        });
        // Prepend a comma if there are options
        return options.length > 0 ? `, ${options.join(', ')}` : '';
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/JsonFileInput.js":
/*!******************************************************!*\
  !*** ./lib/components/inputs/files/JsonFileInput.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JsonFileInput: () => (/* binding */ JsonFileInput)
/* harmony export */ });
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");



class JsonFileInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env", jsonOptions: {} };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "http", label: "HTTP" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\.(json|jsonl)$",
                    validationMessage: "This field expects a file with a json extension such as input.json."
                },
                {
                    type: "select",
                    label: "Orientation",
                    id: "jsonOptions.orient",
                    placeholder: "default: columns",
                    options: [
                        { value: 'columns', label: 'Columns - JSON object with column labels as keys' },
                        { value: 'records', label: 'Records - List of rows as JSON objects' },
                        { value: 'index', label: 'Index - Dict with index labels as keys' },
                        { value: 'split', label: 'Split - Dict with "index", "columns", and "data" keys' },
                        { value: 'table', label: 'Table - Dict with "schema" and "data" keys, following the Table Schema' }
                    ],
                },
                /*
                {
                  type: "input",
                  label: "JSON Path (Optional)",
                  id: "jsonPath",
                  placeholder: "Enter JSON path to extract specific data",
                  advanced: true
                },
                */
                {
                    type: "boolean",
                    label: "Infer Data Types",
                    id: "jsonOptions.dtype",
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Line-delimited",
                    id: "jsonOptions.lines",
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "jsonOptions.storage_options",
                    condition: { fileLocation: ["http", "s3"] },
                    advanced: true
                }
            ],
        };
        const description = "Use JSON File Input to access data from a JSON file locally or remotely (via HTTP or S3).";
        super("JSON File Input", "jsonFileInput", description, "pandas_df_input", ["json", "jsonl"], "inputs", _icons__WEBPACK_IMPORTED_MODULE_2__.fileJsonIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    generateComponentCode({ config, outputName }) {
        // Generate the JSON options string using the separate function
        const optionsString = this.generateJsonOptionsCode({ config });
        // Generate the final Python code for reading JSON
        const code = `
${outputName} = pd.read_json("${config.filePath}"${optionsString}).convert_dtypes()
  `;
        return code.trim();
    }
    generateJsonOptionsCode({ config }) {
        let jsonOptions = { ...config.jsonOptions };
        // Initialize storage_options if not already present
        let storageOptions = jsonOptions.storage_options || {};
        // Transform storage_options array into the correct format
        if (Array.isArray(storageOptions)) {
            const transformedStorageOptions = storageOptions.reduce((acc, item) => {
                acc[item.key] = item.value;
                return acc;
            }, {});
            // Merge transformed options with the S3-specific options
            const s3Options = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, {});
            storageOptions = { ...transformedStorageOptions, ...s3Options };
        }
        else {
            // Ensure S3-specific options are handled when storageOptions is not an array
            storageOptions = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions);
        }
        // Update the storage_options in csvOptions
        if (Object.keys(storageOptions).length > 0) {
            jsonOptions.storage_options = storageOptions;
        }
        // Helper function to convert JavaScript values to Python literals
        const toPythonLiteral = (value) => {
            if (typeof value === 'boolean') {
                return value ? 'True' : 'False';
            }
            else if (typeof value === 'string') {
                return `"${value}"`; // Handle strings with quotes
            }
            else if (Array.isArray(value)) {
                return JSON.stringify(value); // Convert arrays to JSON strings
            }
            else if (typeof value === 'object' && value !== null) {
                return JSON.stringify(value); // Convert objects to JSON strings
            }
            else {
                return String(value); // Handle numbers and other types
            }
        };
        // Process jsonOptions into a string
        let optionsEntries = Object.entries(jsonOptions)
            .filter(([key, value]) => value !== null && value !== '')
            .map(([key, value]) => {
            if (key === 'storage_options') {
                return `${key}=${toPythonLiteral(value)}`;
            }
            else {
                return `${key}=${toPythonLiteral(value)}`;
            }
        });
        return optionsEntries.length > 0 ? `, ${optionsEntries.join(', ')}` : '';
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/LocalFileInput.js":
/*!*******************************************************!*\
  !*** ./lib/components/inputs/files/LocalFileInput.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LocalFileInput: () => (/* binding */ LocalFileInput)
/* harmony export */ });
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CsvFileInput */ "./lib/components/inputs/files/CsvFileInput.js");
/* harmony import */ var _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./JsonFileInput */ "./lib/components/inputs/files/JsonFileInput.js");
/* harmony import */ var _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ExcelFileInput */ "./lib/components/inputs/files/ExcelFileInput.js");
/* harmony import */ var _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ParquetFileInput */ "./lib/components/inputs/files/ParquetFileInput.js");
/* harmony import */ var _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./XmlFileInput */ "./lib/components/inputs/files/XmlFileInput.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");







class LocalFileInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileType: "csv", fileLocation: "local" };
        const csvComponent = new _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__.CsvFileInput();
        const jsonComponent = new _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__.JsonFileInput();
        const excelComponent = new _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileInput();
        const parquetComponent = new _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileInput();
        const xmlComponent = new _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__.XmlFileInput();
        const fieldsToRemove = ["fileLocation"]; // Fields to remove from all components
        const filteredCsvFields = csvComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredJsonFields = jsonComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredExcelFields = excelComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredParquetFields = parquetComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredXmlFields = xmlComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Type",
                    id: "fileType",
                    options: [
                        { value: "csv", label: "CSV" },
                        { value: "json", label: "JSON" },
                        { value: "excel", label: "Excel" },
                        { value: "parquet", label: "Parquet" },
                        { value: "xml", label: "XML" }
                    ]
                },
                // Conditionally display filtered fields based on selected file type
                ...filteredCsvFields.map(field => ({
                    ...field,
                    condition: { fileType: "csv", ...(field.condition || {}) }
                })),
                ...filteredJsonFields.map(field => ({
                    ...field,
                    condition: { fileType: "json", ...(field.condition || {}) }
                })),
                ...filteredExcelFields.map(field => ({
                    ...field,
                    condition: { fileType: "excel", ...(field.condition || {}) }
                })),
                ...filteredParquetFields.map(field => ({
                    ...field,
                    condition: { fileType: "parquet", ...(field.condition || {}) }
                })),
                ...filteredXmlFields.map(field => ({
                    ...field,
                    condition: { fileType: "xml", ...(field.condition || {}) }
                }))
            ]
        };
        const description = "Use File Input to read data from a local file. Supports CSV, JSON, Excel, Parquet, and XML formats.";
        super("File Input", "localFileInput", description, "pandas_df_input", [], "inputs", _icons__WEBPACK_IMPORTED_MODULE_6__.fileTextIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        return deps;
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        return imports;
    }
    generateComponentCode({ config, outputName }) {
        if (config.fileType === "csv") {
            const csvComponent = new _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__.CsvFileInput();
            return csvComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "json") {
            const jsonComponent = new _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__.JsonFileInput();
            return jsonComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "excel") {
            const excelComponent = new _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileInput();
            return excelComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "parquet") {
            const parquetComponent = new _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileInput();
            return parquetComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "xml") {
            const xmlComponent = new _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__.XmlFileInput();
            return xmlComponent.generateComponentCode({ config, outputName });
        }
        return '';
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/ParquetFileInput.js":
/*!*********************************************************!*\
  !*** ./lib/components/inputs/files/ParquetFileInput.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ParquetFileInput: () => (/* binding */ ParquetFileInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");
/* harmony import */ var _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/FileUtils */ "./lib/components/common/FileUtils.js");



 // Import the FileUtils class
class ParquetFileInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "http", label: "HTTP" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name or use '*' for patterns",
                    validation: "\\.(parquet)$|^(.*\\*)$",
                    tooltip: "This field expects a file with a .parquet extension or a wildcard pattern such as input*.parquet."
                },
                {
                    type: "select",
                    label: "Engine",
                    id: "parquetOptions.engine",
                    placeholder: "Select engine",
                    options: [
                        { value: "auto", label: "auto", tooltip: "The default behavior is to try ‘pyarrow’, falling back to ‘fastparquet’ if ‘pyarrow’ is unavailable." },
                        { value: "pyarrow", label: "pyarrow" },
                        { value: "fastparquet", label: "fastparquet" }
                    ],
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "parquetOptions.storage_options",
                    condition: { fileLocation: ["http", "s3"] },
                    advanced: true
                }
            ],
        };
        const description = "Use Parquet File Input to access data from Parquet files locally or remotely (via HTTP or S3).";
        super("Parquet File Input", "parquetFileInput", description, "pandas_df_input", ["parquet"], "inputs", _icons__WEBPACK_IMPORTED_MODULE_2__.fileParquetIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        var _a;
        let deps = ['pyarrow'];
        if (((_a = config.parquetOptions) === null || _a === void 0 ? void 0 : _a.engine) === "fastparquet") {
            deps.push('fastparquet');
        }
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.isWildcardInput(config.filePath)) {
            deps.push(config.fileLocation === "s3" ? 's3fs' : 'glob');
        }
        return deps;
    }
    provideImports({ config }) {
        var _a;
        const imports = ["import pandas as pd"];
        if (((_a = config.parquetOptions) === null || _a === void 0 ? void 0 : _a.engine) === "fastparquet") {
            imports.push("import fastparquet");
        }
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.isWildcardInput(config.filePath)) {
            if (config.fileLocation === "s3") {
                imports.push("import s3fs");
            }
            else {
                imports.push("import glob");
            }
        }
        return imports;
    }
    generateComponentCode({ config, outputName }) {
        const parquetOptions = { ...config.parquetOptions };
        const storageOptionsString = parquetOptions.storage_options ? JSON.stringify(parquetOptions.storage_options) : '{}';
        const optionsString = this.generateParquetOptionsCode({ config });
        let code = '';
        // Check for wildcard input and generate appropriate code
        if (_common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.isWildcardInput(config.filePath)) {
            if (config.fileLocation === "s3") {
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.getS3FilePaths(config.filePath, storageOptionsString, outputName);
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.generateConcatCode(outputName, "read_parquet", optionsString, true);
            }
            else {
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.getLocalFilePaths(config.filePath, outputName);
                code += _common_FileUtils__WEBPACK_IMPORTED_MODULE_3__.FileUtils.generateConcatCode(outputName, "read_parquet", optionsString, false);
            }
        }
        else {
            // Simple file reading without wildcard
            code += `${outputName} = pd.read_parquet("${config.filePath}"${optionsString}).convert_dtypes()\n`;
        }
        return code.trim();
    }
    generateParquetOptionsCode({ config }) {
        let parquetOptions = { ...config.parquetOptions };
        let storageOptions = parquetOptions.storage_options || {};
        // Transform storage_options array into the correct format
        if (Array.isArray(storageOptions)) {
            const transformedStorageOptions = storageOptions.reduce((acc, item) => {
                acc[item.key] = item.value;
                return acc;
            }, {});
            // Merge transformed options with the S3-specific options
            const s3Options = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, {});
            storageOptions = { ...transformedStorageOptions, ...s3Options };
        }
        else {
            // Ensure S3-specific options are handled when storageOptions is not an array
            storageOptions = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions);
        }
        // Update the storage_options in parquetOptions
        if (Object.keys(storageOptions).length > 0) {
            parquetOptions.storage_options = storageOptions;
        }
        const options = Object.entries(parquetOptions)
            .filter(([key, value]) => value !== null && value !== '')
            .map(([key, value]) => {
            if (key === 'storage_options' && typeof value === 'object') {
                return `${key}=${JSON.stringify(value)}`;
            }
            else if (typeof value === 'string') {
                return `${key}="${value}"`;
            }
            else {
                return `${key}=${value}`;
            }
        });
        // Prepend a comma if there are options
        return options.length > 0 ? `, ${options.join(', ')}` : '';
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/PdfTablesInput.js":
/*!*******************************************************!*\
  !*** ./lib/components/inputs/files/PdfTablesInput.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PdfTablesInput: () => (/* binding */ PdfTablesInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class PdfTablesInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { pageNumber: 0, tableNumber: 0 };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name",
                    tooltip: "This field expects a file path with a csv, tsv or txt extension such as input.csv.",
                    validation: "\\.(pdf)$",
                },
                {
                    type: "inputNumber",
                    label: "Page number",
                    id: "pageNumber",
                    tooltip: "Page number where table is located starting at 0.",
                },
                {
                    type: "inputNumber",
                    label: "Table number",
                    id: "tableNumber",
                    tooltip: "If multiple tables are present on the page, specify the number starting at 0.",
                }
            ],
        };
        super("PDF Tables Input", "pdfTablesInput", "no desc", "pandas_df_input", ["pdf"], "inputs", _icons__WEBPACK_IMPORTED_MODULE_1__.fileTextIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('PyMuPDF');
        return deps;
    }
    provideImports({ config }) {
        return ["import fitz"];
    }
    generateComponentCode({ config, outputName }) {
        // Generate the Python code
        const code = `
# Extract tables from ${config.filePath}
${outputName}_doc = fitz.open("${config.filePath}")
${outputName}_tabs = ${outputName}_doc[${config.pageNumber}].find_tables() # detect the tables
${outputName} = ${outputName}_tabs[${config.tableNumber}].to_pandas()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/S3FileInput.js":
/*!****************************************************!*\
  !*** ./lib/components/inputs/files/S3FileInput.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   S3FileInput: () => (/* binding */ S3FileInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CsvFileInput */ "./lib/components/inputs/files/CsvFileInput.js");
/* harmony import */ var _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./JsonFileInput */ "./lib/components/inputs/files/JsonFileInput.js");
/* harmony import */ var _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ExcelFileInput */ "./lib/components/inputs/files/ExcelFileInput.js");
/* harmony import */ var _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ParquetFileInput */ "./lib/components/inputs/files/ParquetFileInput.js");
/* harmony import */ var _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./XmlFileInput */ "./lib/components/inputs/files/XmlFileInput.js");







class S3FileInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileType: "csv", fileLocation: "s3", connectionMethod: "env" };
        const csvComponent = new _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__.CsvFileInput();
        const jsonComponent = new _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__.JsonFileInput();
        const excelComponent = new _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileInput();
        const parquetComponent = new _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileInput();
        const xmlComponent = new _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__.XmlFileInput();
        const fieldsToRemove = ["fileLocation"]; // Fields to remove from all components
        const filteredCsvFields = csvComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredJsonFields = jsonComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredExcelFields = excelComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredParquetFields = parquetComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredXmlFields = xmlComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Type",
                    id: "fileType",
                    options: [
                        { value: "csv", label: "CSV" },
                        { value: "json", label: "JSON" },
                        { value: "excel", label: "Excel" },
                        { value: "parquet", label: "Parquet" },
                        { value: "xml", label: "XML" }
                    ]
                },
                // Conditionally display filtered fields based on selected file type
                ...filteredCsvFields.map(field => ({
                    ...field,
                    condition: { fileType: ["csv"], ...(field.condition || {}) }
                })),
                ...filteredJsonFields.map(field => ({
                    ...field,
                    condition: { fileType: ["json"], ...(field.condition || {}) }
                })),
                ...filteredExcelFields.map(field => ({
                    ...field,
                    condition: { fileType: ["excel"], ...(field.condition || {}) }
                })),
                ...filteredParquetFields.map(field => ({
                    ...field,
                    condition: { fileType: ["parquet"], ...(field.condition || {}) }
                })),
                ...filteredXmlFields.map(field => ({
                    ...field,
                    condition: { fileType: ["xml"], ...(field.condition || {}) }
                }))
            ]
        };
        const description = "Use File Input to read data from a file remotely (S3). Supports CSV, JSON, Excel, Parquet, and XML formats.";
        super("S3 File Input", "s3FileInput", description, "pandas_df_input", [], "inputs.AWS", _icons__WEBPACK_IMPORTED_MODULE_6__.s3Icon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('s3fs');
        return deps;
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports;
    }
    generateComponentCode({ config, outputName }) {
        if (config.fileType === "csv") {
            const csvComponent = new _CsvFileInput__WEBPACK_IMPORTED_MODULE_1__.CsvFileInput();
            return csvComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "json") {
            const jsonComponent = new _JsonFileInput__WEBPACK_IMPORTED_MODULE_2__.JsonFileInput();
            return jsonComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "excel") {
            const excelComponent = new _ExcelFileInput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileInput();
            return excelComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "parquet") {
            const parquetComponent = new _ParquetFileInput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileInput();
            return parquetComponent.generateComponentCode({ config, outputName });
        }
        else if (config.fileType === "xml") {
            const xmlComponent = new _XmlFileInput__WEBPACK_IMPORTED_MODULE_5__.XmlFileInput();
            return xmlComponent.generateComponentCode({ config, outputName });
        }
        return '';
    }
}


/***/ }),

/***/ "./lib/components/inputs/files/XmlFileInput.js":
/*!*****************************************************!*\
  !*** ./lib/components/inputs/files/XmlFileInput.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   XmlFileInput: () => (/* binding */ XmlFileInput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");



class XmlFileInput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env", xmlOptions: { xpath: '', parser: 'lxml' } };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "http", label: "HTTP" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\\.xml$",
                    validationMessage: "This field expects a file with an xml extension such as input.xml."
                },
                {
                    type: "text",
                    label: "XPath Expression",
                    id: "xmlOptions.xpath",
                    placeholder: "/root/child"
                },
                {
                    type: "select",
                    label: "Parser",
                    id: "xmlOptions.parser",
                    placeholder: "Select Parser",
                    options: [
                        { value: 'lxml', label: 'lxml' },
                        { value: 'etree', label: 'etree' },
                    ],
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "xmlOptions.storage_options",
                    condition: { fileLocation: ["http", "s3"] },
                    advanced: true
                }
            ],
        };
        const description = "Use XML File Input to access data from a XML file locally or remotely (via HTTP or S3).";
        super("XML File Input", "xmlFileInput", description, "pandas_df_input", ["xml"], "inputs", _icons__WEBPACK_IMPORTED_MODULE_2__.fileTextIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        switch (config.parser) {
            case 'lxml':
                deps.push('lxml');
                break;
            default:
        }
        return deps;
    }
    provideImports({ config }) {
        return ["import pandas as pd"]; // Adjust import based on XML parsing library
    }
    generateComponentCode({ config, outputName }) {
        let xmlOptions = { ...config.xmlOptions };
        // Initialize storage_options if not already present
        let storageOptions = xmlOptions.storage_options || {};
        storageOptions = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions);
        // Only add storage_options to csvOptions if it's not empty
        if (Object.keys(storageOptions).length > 0) {
            xmlOptions.storage_options = storageOptions;
        }
        let optionsString = Object.entries(xmlOptions || {})
            .filter(([key, value]) => value !== null && value !== '')
            .map(([key, value]) => {
            if (key === 'storage_options') {
                return `${key}=${JSON.stringify(value)}`;
            }
            else {
                return `${key}="${value}"`; // Handle numbers and Python's None without quotes
            }
        })
            .join(', ');
        const optionsCode = optionsString ? `, ${optionsString}` : ''; // Only add optionsString if it exists
        const code = `
${outputName} = pd.read_xml("${config.filePath}"${optionsCode}).convert_dtypes()
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/outputs/Console.js":
/*!*******************************************!*\
  !*** ./lib/components/outputs/Console.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Console: () => (/* binding */ Console)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Console extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { type: "Data", dataFormat: "text" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "select",
                    label: "Type",
                    id: "type",
                    placeholder: "Select type",
                    options: [
                        { value: "Info", label: "Info", tooltip: "Display a regular message in console." },
                        // { value: "Warning", label: "Warning", tooltip: "Display a warning message in the console." },
                        { value: "Error", label: "Error", tooltip: "Raise an error and display error message in console." },
                        { value: "Data", label: "Data", tooltip: "Display data from input component." },
                        // { value: "Markdown", label: "Markdown", tooltip: "Display Markdown in the console. The markdown might not be rendered outside Amphi console." },
                        // { value: "HTML", label: "HTML", tooltip: "Display HTML in the console. The markdown might not be rendered outside HTML console." }
                    ],
                },
                {
                    type: "textarea",
                    label: "Message",
                    id: "message",
                    placeholder: "Write text message",
                    advanced: true,
                    condition: { type: ["Info", "Error"] }
                },
                {
                    type: "inputNumber",
                    label: "Records limit",
                    id: "limit",
                    placeholder: "Number of records to print in console",
                    min: 0,
                    condition: { type: "Data" },
                    advanced: true
                },
                {
                    type: "select",
                    label: "Data Format",
                    id: "dataFormat",
                    options: [
                        { value: "text", label: "Text", tooltip: "Display data as text in console." },
                        { value: "csv", label: "CSV", tooltip: "Display data as a csv in console." }
                    ],
                    condition: { type: "Data" },
                    advanced: true
                },
            ],
        };
        const description = "Use Console Message to display a message (info, warning, error) or data into the Pipeline Console.";
        super("Console Message", "console", description, "pandas_df_output", [], "outputs", _icons__WEBPACK_IMPORTED_MODULE_1__.monitorIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        return deps;
    }
    provideImports({ config }) {
        const imports = ["import pandas as pd"];
        if (config.type === "Warning") {
            imports.push("import warnings");
        }
        if (config.type === "Markdown" || config.type === "HTML") {
            imports.push("from IPython.display import display, Markdown, HTML");
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        let code = "";
        switch (config.type) {
            case "Info":
                code += `print("Info: ${config.message || ''}")\n`;
                break;
            case "Warning":
                code += `warnings.warn("${config.message || ''}")\n`;
                break;
            case "Error":
                code += `raise Exception("Error: ${config.message || ''}")\n`;
                break;
            case "Data":
                if (config.limit) {
                    inputName += `.head(${config.limit})`;
                }
                // Handle different data formats
                switch (config.dataFormat) {
                    case "text":
                        code += `print(${inputName}.to_string(index=False))\n`;
                        break;
                    case "csv":
                        code += `print(${inputName}.to_csv(index=False))\n`;
                        break;
                    default:
                        code += `print(${inputName}.to_string(index=False))\n`; // Default to text output if format is not specified
                }
                break;
            case "Markdown":
                code += `display(Markdown("${config.message || ''}"))\n`;
                break;
            case "HTML":
                code += `display(HTML("${config.message || ''}"))\n`;
                break;
            default:
                code += `print(${inputName})\n`;
        }
        return code;
    }
}


/***/ }),

/***/ "./lib/components/outputs/cloud/GoogleSheetsOutput.js":
/*!************************************************************!*\
  !*** ./lib/components/outputs/cloud/GoogleSheetsOutput.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GoogleSheetsOutput: () => (/* binding */ GoogleSheetsOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class GoogleSheetsOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { sheetOptions: { spreadsheetId: "", range: "Sheet1" } };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "file",
                    label: "Service Account Key",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\\.(json)$",
                    validationMessage: "This field expects a file with a .json extension such as your-service-account-file.json.",
                    connection: "Google Sheet",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Spreadsheet ID",
                    id: "sheetOptions.spreadsheetId",
                    placeholder: "Enter Google Sheets' name or ID",
                    validation: "^[a-zA-Z0-9-_]+$",
                    validationMessage: "Invalid Spreadsheet ID."
                },
                {
                    type: "input",
                    label: "Range",
                    id: "sheetOptions.range",
                    placeholder: "e.g., Sheet1 or Sheet1!A1:D5",
                    validation: "^[a-zA-Z0-9-_!]+$",
                    validationMessage: "Invalid Range.",
                    advanced: true
                }
            ],
        };
        super("G. Sheets Output", "googleSheetsOutput", "no desc", "pandas_df_output", [], "outputs", _icons__WEBPACK_IMPORTED_MODULE_1__.googleSheetsIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import gspread", "from oauth2client.service_account import ServiceAccountCredentials"];
    }
    generateComponentCode({ config, inputName }) {
        // Initialize an object to modify without affecting the original config
        let sheetOptions = { ...config.sheetOptions };
        // Validate and set the service account file path
        const serviceAccountFilePath = config.filePath ? `"${config.filePath}"` : 'None';
        // Unique variables for each instance
        const uniqueClientVar = `${inputName}Client`;
        const uniqueSheetVar = `${inputName}Sheet`;
        // Generate the Python code for outputting data to Google Sheets
        const code = `
# Outputting data to Google Sheets
scope = ["https://spreadsheets.google.com/feeds","https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(${serviceAccountFilePath}, scope)
${uniqueClientVar} = gspread.authorize(creds)

# Open the spreadsheet and select the right worksheet
${uniqueSheetVar} = ${uniqueClientVar}.open_by_key(${sheetOptions.spreadsheetId ? `"${sheetOptions.spreadsheetId}"` : 'None'}).worksheet(${sheetOptions.range ? `"${sheetOptions.range.split('!')[0]}"` : 'None'})

# Update the sheet with dataframe's data
${uniqueSheetVar}.update([${inputName}.columns.values.tolist()] + ${inputName}.values.tolist())
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/outputs/databases/MySQLOutput.js":
/*!*********************************************************!*\
  !*** ./lib/components/outputs/databases/MySQLOutput.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MySQLOutput: () => (/* binding */ MySQLOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class MySQLOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            host: "localhost",
            port: "3306",
            databaseName: "",
            tableName: "",
            username: "",
            password: "",
            ifTableExists: "fail",
            mode: "insert"
        };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "input",
                    label: "Host",
                    id: "host",
                    placeholder: "Enter database host",
                    connection: "Mysql",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Port",
                    id: "port",
                    placeholder: "Enter database port",
                    connection: "Mysql",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "databaseName",
                    connection: "Mysql",
                    placeholder: "Enter database name"
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SHOW TABLES;`,
                    id: "tableName",
                    placeholder: "Enter table name"
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    connection: "Mysql",
                    placeholder: "Enter username",
                    advanced: true
                },
                {
                    type: "input",
                    inputType: "password",
                    label: "Password",
                    id: "password",
                    connection: "Mysql",
                    placeholder: "Enter password",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "If Table Exists",
                    id: "ifTableExists",
                    options: [
                        { value: "fail", label: "Fail" },
                        { value: "replace", label: "Replace" },
                        { value: "append", label: "Append" }
                    ],
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Mode",
                    id: "mode",
                    options: [
                        { value: "insert", label: "INSERT" }
                    ],
                    advanced: true
                },
                {
                    type: "dataMapping",
                    imports: ["pymysql"],
                    label: "Mapping",
                    id: "mapping",
                    tooltip: "By default the mapping is inferred from the input data. By specifying a schema you override the incoming schema.",
                    outputType: "relationalDatabase",
                    drivers: "mysql+pymysql",
                    query: "DESCRIBE {{table}}",
                    pythonExtraction: "column_info = schema[[\"Field\", \"Type\"]]\nformatted_output = \", \".join([f\"{row['Field']} ({row['Type']})\" for _, row in column_info.iterrows()])\nprint(formatted_output)",
                    typeOptions: [
                        { value: "INT", label: "INT" },
                        { value: "VARCHAR", label: "VARCHAR" },
                        { value: "TEXT", label: "TEXT" },
                        { value: "DATE", label: "DATE" },
                        { value: "DATETIME", label: "DATETIME" },
                        { value: "TIMESTAMP", label: "TIMESTAMP" },
                        { value: "TIME", label: "TIME" },
                        { value: "YEAR", label: "YEAR" },
                        { value: "BOOLEAN", label: "BOOLEAN" },
                        { value: "DECIMAL", label: "DECIMAL" },
                        { value: "FLOAT", label: "FLOAT" },
                        { value: "DOUBLE", label: "DOUBLE" },
                        { value: "BLOB", label: "BLOB" },
                        { value: "BIT", label: "BIT" },
                        { value: "ENUM", label: "ENUM" },
                        { value: "SET", label: "SET" },
                        { value: "JSON", label: "JSON" }
                    ],
                    advanced: true
                }
            ],
        };
        const description = "Use MySQL Output to insert data into a MySQL table by specifying a data mapping between the incoming data and the existing table schema.";
        super("MySQL Output", "mySQLOutput", description, "pandas_df_output", [], "outputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.mySQLIcon, defaultConfig, form);
    }
    // https://stackoverflow.com/questions/63881687/how-to-upsert-pandas-dataframe-to-mysql-with-sqlalchemy
    provideDependencies({ config }) {
        let deps = [];
        deps.push('pymysql');
        return deps;
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import sqlalchemy", "import pymysql"];
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        return `
# Connect to the MySQL database
${connectionName} = sqlalchemy.create_engine(
  "mysql+pymysql://${config.username}:${config.password}@${config.host}:${config.port}/${config.databaseName}"
)
`;
    }
    generateComponentCode({ config, inputName }) {
        const uniqueEngineName = `${inputName}Engine`;
        let mappingsCode = "";
        let columnsCode = "";
        if (config.mapping && config.mapping.length > 0) {
            const renameMap = config.mapping
                .filter(map => map.input && (map.input.value || typeof map.input.value === 'number'))
                .map(map => {
                if (map.input.value != map.value) {
                    if (map.input.named) {
                        return `"${map.input.value}": "${map.value}"`; // Handles named columns
                    }
                    else {
                        return `${map.input.value}: "${map.value}"`; // Handles numeric index
                    }
                }
                return undefined; // Explicitly return undefined for clarity
            })
                .filter(value => value !== undefined);
            if (renameMap.length > 0) {
                mappingsCode = `
# Rename columns based on the mapping
${inputName} = ${inputName}.rename(columns={${renameMap.join(", ")}})
`;
            }
            const selectedColumns = config.mapping
                .filter(map => map.value !== null && map.value !== undefined)
                .map(map => `"${map.value}"`)
                .join(', ');
            if (selectedColumns) {
                columnsCode = `
# Only keep relevant columns
${inputName} = ${inputName}[[${selectedColumns}]]
`;
            }
        }
        const ifExistsAction = config.ifTableExists;
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        return `
${connectionCode}
${mappingsCode}${columnsCode}
# Write DataFrame to MySQL
try:
    ${inputName}.to_sql(
        name="${config.tableName.value}",
        con=${uniqueEngineName},
        if_exists="${ifExistsAction}",
        index=False
    )
finally:
    ${uniqueEngineName}.dispose()
`;
    }
}


/***/ }),

/***/ "./lib/components/outputs/databases/OracleOutput.js":
/*!**********************************************************!*\
  !*** ./lib/components/outputs/databases/OracleOutput.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OracleOutput: () => (/* binding */ OracleOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class OracleOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            host: "localhost",
            port: "1521",
            databaseName: "",
            schema: "",
            username: "",
            password: "",
            tableName: "",
            ifTableExists: "fail",
            mode: "insert",
            dbapi: "oracledb",
            oracleClient: ""
        };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "input",
                    label: "Host",
                    id: "host",
                    placeholder: "Enter database host",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Port",
                    id: "port",
                    placeholder: "Enter database port",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "databaseName",
                    placeholder: "Enter database name",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Schema",
                    id: "schema",
                    placeholder: "Enter schema name",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Password",
                    id: "password",
                    placeholder: "Enter password",
                    inputType: "password",
                    connection: "Oracle DB",
                    advanced: true
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SELECT table_name FROM user_tables;`,
                    id: "tableName",
                    placeholder: "Enter table name"
                },
                {
                    type: "radio",
                    label: "If Table Exists",
                    id: "ifTableExists",
                    options: [
                        { value: "fail", label: "Fail" },
                        { value: "replace", label: "Replace" },
                        { value: "append", label: "Append" }
                    ],
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Mode",
                    id: "mode",
                    options: [
                        { value: "insert", label: "INSERT" }
                    ],
                    advanced: true
                },
                {
                    type: "dataMapping",
                    label: "Mapping",
                    id: "mapping",
                    tooltip: "By default, the mapping is inferred from the input data. By specifying a schema, you override the incoming schema.",
                    outputType: "relationalDatabase",
                    imports: ["cx_Oracle", "oracledb"],
                    drivers: "oracle",
                    query: "DESCRIBE {{table}}",
                    typeOptions: [
                        { value: "VARCHAR2", label: "VARCHAR2" },
                        { value: "NUMBER", label: "NUMBER" },
                        { value: "DATE", label: "DATE" },
                        { value: "TIMESTAMP", label: "TIMESTAMP" },
                        { value: "CHAR", label: "CHAR" },
                        { value: "NCHAR", label: "NCHAR" },
                        { value: "NVARCHAR2", label: "NVARCHAR2" },
                        { value: "CLOB", label: "CLOB" },
                        { value: "NCLOB", label: "NCLOB" },
                        { value: "BLOB", label: "BLOB" },
                        { value: "BFILE", label: "BFILE" },
                        { value: "RAW", label: "RAW" },
                        { value: "LONG RAW", label: "LONG RAW" },
                        { value: "LONG", label: "LONG" },
                        { value: "XMLTYPE", label: "XMLTYPE" },
                        { value: "ROWID", label: "ROWID" },
                        { value: "UROWID", label: "UROWID" },
                        { value: "FLOAT", label: "FLOAT" },
                        { value: "BINARY_FLOAT", label: "BINARY_FLOAT" },
                        { value: "BINARY_DOUBLE", label: "BINARY_DOUBLE" }
                    ],
                    advanced: true
                },
                {
                    type: "input",
                    label: "Oracle Client Path (Optional)",
                    tooltip: "Specify the directory of the desired Oracle client if needed.",
                    id: "oracleClient",
                    placeholder: "Specify oracle client path",
                    advanced: true
                },
                {
                    type: "select",
                    label: "Database API (DBAPI)",
                    id: "dbapi",
                    options: [
                        { value: "cx_oracle", label: "cx-Oracle" },
                        { value: "oracledb", label: "python-oracledb" }
                    ],
                    advanced: true
                }
            ]
        };
        const description = "Use Oracle Output to insert data into an Oracle database table by specifying a data mapping between the incoming data and the existing table schema.";
        super("Oracle Output", "oracleOutput", description, "pandas_df_output", [], "outputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.oracleIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        if (config.dbapi === 'cx_oracle') {
            deps.push("cx_Oracle");
        }
        else if (config.dbapi === 'oracledb') {
            deps.push("oracledb");
        }
        return deps;
    }
    provideImports({ config }) {
        const imports = ["import pandas as pd", "import sqlalchemy"];
        if (config.dbapi === 'cx_oracle') {
            imports.push("import cx_Oracle");
        }
        else if (config.dbapi === 'oracledb') {
            imports.push("import oracledb");
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        const dbapi = config.dbapi;
        const uniqueEngineName = `${inputName}_Engine`;
        // Build connection string
        let connectionString = `oracle+${dbapi}://${config.username}:${config.password}@${config.host}:${config.port}/?service_name=${config.databaseName}`;
        // Initialize the Oracle client if oracleClient is provided
        const oracleClientInitialization = config.oracleClient && config.oracleClient.trim()
            ? `${dbapi}.init_oracle_client(lib_dir="${config.oracleClient}")\n`
            : "";
        // Prepare mappings and columns code
        let mappingsCode = "";
        let columnsCode = "";
        if (config.mapping && config.mapping.length > 0) {
            const renameMap = config.mapping
                .filter(map => map.input && map.input.value !== undefined && map.input.value !== null)
                .map(map => {
                if (map.input.value != map.value) {
                    return `"${map.input.value}": "${map.value}"`;
                }
                return undefined;
            })
                .filter(value => value !== undefined);
            if (renameMap.length > 0) {
                mappingsCode = `
# Rename columns based on the mapping
${inputName} = ${inputName}.rename(columns={${renameMap.join(", ")}})
`;
            }
            const selectedColumns = config.mapping
                .filter(map => map.value !== null && map.value !== undefined)
                .map(map => `"${map.value}"`)
                .join(', ');
            if (selectedColumns) {
                columnsCode = `
# Only keep relevant columns
${inputName} = ${inputName}[[${selectedColumns}]]
`;
            }
        }
        const ifExistsAction = config.ifTableExists;
        const schemaParam = config.schema && config.schema.trim()
            ? `,
        schema="${config.schema}"`
            : '';
        return `
# Connect to the Oracle database
${oracleClientInitialization}${uniqueEngineName} = sqlalchemy.create_engine("${connectionString}")
${mappingsCode}${columnsCode}
# Write DataFrame to Oracle
try:
    ${inputName}.to_sql(
        name="${config.tableName}",
        schema="${config.schema}",
        con=${uniqueEngineName},
        if_exists="${ifExistsAction}",
        index=False${schemaParam}
    )
finally:
    ${uniqueEngineName}.dispose()
`;
    }
}


/***/ }),

/***/ "./lib/components/outputs/databases/PostgresOutput.js":
/*!************************************************************!*\
  !*** ./lib/components/outputs/databases/PostgresOutput.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PostgresOutput: () => (/* binding */ PostgresOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class PostgresOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            host: "localhost",
            port: "5432",
            databaseName: "",
            schema: "public",
            username: "",
            password: "",
            ifTableExists: "fail",
            mode: "insert"
        };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "input",
                    label: "Host",
                    id: "host",
                    placeholder: "Enter database host",
                    connection: "Postgres",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Port",
                    id: "port",
                    placeholder: "Enter database port",
                    connection: "Postgres",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "databaseName",
                    connection: "Postgres",
                    placeholder: "Enter database name"
                },
                {
                    type: "input",
                    label: "Schema",
                    id: "schema",
                    connection: "Postgres",
                    placeholder: "Enter schema name",
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';`,
                    id: "tableName",
                    placeholder: "Enter table name"
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "Postgres",
                    advanced: true
                },
                {
                    type: "input",
                    inputType: "password",
                    label: "Password",
                    id: "password",
                    connection: "Postgres",
                    placeholder: "Enter password",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "If Table Exists",
                    id: "ifTableExists",
                    options: [
                        { value: "fail", label: "Fail" },
                        { value: "replace", label: "Replace" },
                        { value: "append", label: "Append" }
                    ],
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Mode",
                    id: "mode",
                    options: [
                        { value: "insert", label: "INSERT" }
                    ],
                    advanced: true
                },
                {
                    type: "dataMapping",
                    label: "Mapping",
                    id: "mapping",
                    tooltip: "By default the mapping is inferred from the input data. By specifying a schema you override the incoming schema.",
                    outputType: "relationalDatabase",
                    imports: ["psycopg2-binary"],
                    drivers: "postgresql",
                    query: `
SELECT 
    column_name AS "Field",
    data_type AS "Type",
    is_nullable AS "Null",
    column_default AS "Default",
    CASE 
        WHEN character_maximum_length IS NOT NULL THEN character_maximum_length::text
        ELSE ''
    END AS "Extra"
FROM 
    information_schema.columns
WHERE 
    table_schema = '{{schema}}' AND
    table_name = '{{table}}';`,
                    pythonExtraction: `column_info = schema[[\"Field\", \"Type\"]]\nformatted_output = \", \".join([f\"{row['Field']} ({row['Type']})\" for _, row in column_info.iterrows()])\nprint(formatted_output)`,
                    typeOptions: [
                        { value: "SMALLINT", label: "SMALLINT" },
                        { value: "INTEGER", label: "INTEGER" },
                        { value: "BIGINT", label: "BIGINT" },
                        { value: "SERIAL", label: "SERIAL" },
                        { value: "BIGSERIAL", label: "BIGSERIAL" },
                        { value: "DECIMAL", label: "DECIMAL" },
                        { value: "NUMERIC", label: "NUMERIC" },
                        { value: "REAL", label: "REAL" },
                        { value: "DOUBLE PRECISION", label: "DOUBLE PRECISION" },
                        { value: "SMALLSERIAL", label: "SMALLSERIAL" },
                        { value: "MONEY", label: "MONEY" },
                        { value: "CHAR", label: "CHAR" },
                        { value: "VARCHAR", label: "VARCHAR" },
                        { value: "TEXT", label: "TEXT" },
                        { value: "BYTEA", label: "BYTEA" },
                        { value: "TIMESTAMP", label: "TIMESTAMP" },
                        { value: "DATE", label: "DATE" },
                        { value: "TIME", label: "TIME" },
                        { value: "INTERVAL", label: "INTERVAL" },
                        { value: "BOOLEAN", label: "BOOLEAN" },
                        { value: "UUID", label: "UUID" },
                        { value: "XML", label: "XML" },
                        { value: "JSON", label: "JSON" },
                        { value: "JSONB", label: "JSONB" },
                        { value: "ARRAY", label: "ARRAY" },
                        { value: "CIDR", label: "CIDR" },
                        { value: "INET", label: "INET" },
                        { value: "MACADDR", label: "MACADDR" },
                        { value: "BIT", label: "BIT" },
                        { value: "TSVECTOR", label: "TSVECTOR" },
                        { value: "TSQUERY", label: "TSQUERY" }
                    ],
                    advanced: true
                }
            ],
        };
        const description = "Use Postgres Output to insert data into a Postgres table by specifying a data mapping between the incoming data and the existing table schema.";
        super("Postgres Output", "postgresOutput", description, "pandas_df_output", [], "outputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.postgresIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('psycopg2-binary');
        return deps;
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import sqlalchemy", "import psycopg2"];
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        return `
# Connect to the Postgres database
${connectionName} = sqlalchemy.create_engine(
  "postgresql://${config.username}:${config.password}@${config.host}:${config.port}/${config.databaseName}"
)
`;
    }
    generateComponentCode({ config, inputName }) {
        const uniqueEngineName = `${inputName}Engine`;
        let mappingsCode = "";
        let columnsCode = "";
        if (config.mapping && config.mapping.length > 0) {
            const renameMap = config.mapping
                .filter(map => map.input && (map.input.value || typeof map.input.value === 'number'))
                .map(map => {
                if (map.input.value != map.value) {
                    if (map.input.named) {
                        return `"${map.input.value}": "${map.value}"`; // Handles named columns
                    }
                    else {
                        return `${map.input.value}: "${map.value}"`; // Handles numeric index
                    }
                }
                return undefined; // Explicitly return undefined for clarity
            })
                .filter(value => value !== undefined);
            if (renameMap.length > 0) {
                mappingsCode = `
# Rename columns based on the mapping
${inputName} = ${inputName}.rename(columns={${renameMap.join(", ")}})
`;
            }
            const selectedColumns = config.mapping
                .filter(map => map.value !== null && map.value !== undefined)
                .map(map => `"${map.value}"`)
                .join(', ');
            if (selectedColumns) {
                columnsCode = `
# Only keep relevant columns
${inputName} = ${inputName}[[${selectedColumns}]]
`;
            }
        }
        const ifExistsAction = config.ifTableExists;
        const schemaParam = (config.schema && config.schema.toLowerCase() !== 'public')
            ? `,
  schema="${config.schema}"`
            : '';
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        return `
${connectionCode}
${mappingsCode}${columnsCode}
# Write DataFrame to Postgres
try:
    ${inputName}.to_sql(
        name="${config.tableName.value}",
        con=${uniqueEngineName},
        if_exists="${ifExistsAction}",
        index=False${schemaParam}
    )
finally:
    ${uniqueEngineName}.dispose()
`;
    }
}


/***/ }),

/***/ "./lib/components/outputs/databases/SnowflakeOutput.js":
/*!*************************************************************!*\
  !*** ./lib/components/outputs/databases/SnowflakeOutput.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SnowflakeOutput: () => (/* binding */ SnowflakeOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class SnowflakeOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            account: "",
            database: "",
            schema: "PUBLIC",
            tableName: "",
            username: "",
            password: "",
            warehouse: "",
            role: "",
            ifTableExists: "fail",
            mode: "insert"
        };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "input",
                    label: "Account",
                    id: "account",
                    placeholder: "Enter Account",
                    connection: "Snowflake",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "database",
                    connection: "Snowflake",
                    placeholder: "Enter database name",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "Snowflake",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Password",
                    id: "password",
                    placeholder: "Enter password",
                    connection: "Snowflake",
                    inputType: "password",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Warehouse",
                    id: "warehouse",
                    placeholder: "Enter warehouse name",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Schema",
                    id: "schema",
                    placeholder: "Enter schema name",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Role (Optional)",
                    id: "role",
                    placeholder: "Role name",
                    advanced: true
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SELECT table_name FROM information_schema.tables WHERE table_schema = '{{schema}}'`,
                    id: "tableName",
                    placeholder: "Enter table name"
                },
                {
                    type: "radio",
                    label: "If Table Exists",
                    id: "ifTableExists",
                    options: [
                        { value: "fail", label: "Fail" },
                        { value: "replace", label: "Replace" },
                        { value: "append", label: "Append" }
                    ],
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Mode",
                    id: "mode",
                    options: [
                        { value: "insert", label: "INSERT" }
                    ],
                    advanced: true
                },
                {
                    type: "dataMapping",
                    label: "Mapping",
                    id: "mapping",
                    tooltip: "By default, the mapping is inferred from the input data. By specifying a schema, you override the incoming schema.",
                    outputType: "relationalDatabase",
                    imports: ["snowflake-sqlalchemy"],
                    drivers: "snowflake",
                    query: `DESCRIBE TABLE "{{schema}}"."{{table}}"`,
                    pythonExtraction: `columns_types = ', '.join(f"{row['name']} ({row['type']})" for _, row in schema.iterrows())\nprint(columns_types)`,
                    typeOptions: [
                        { value: "INTEGER", label: "INTEGER" },
                        { value: "FLOAT", label: "FLOAT" },
                        { value: "NUMBER", label: "NUMBER" },
                        { value: "VARCHAR", label: "VARCHAR" },
                        { value: "BOOLEAN", label: "BOOLEAN" },
                        { value: "DATE", label: "DATE" },
                        { value: "TIMESTAMP", label: "TIMESTAMP" },
                        { value: "VARIANT", label: "VARIANT" },
                        { value: "OBJECT", label: "OBJECT" },
                        { value: "ARRAY", label: "ARRAY" }
                    ],
                    advanced: true
                }
            ]
        };
        const description = "Use Snowflake Output to insert data into a Snowflake table by specifying a data mapping between the incoming data and the existing table schema.";
        super("Snowflake Output", "snowflakeOutput", description, "pandas_df_output", [], "outputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.snowflakeIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        return ['snowflake-sqlalchemy'];
    }
    provideImports({ config }) {
        return [
            "import pandas as pd",
            "import sqlalchemy",
            "import urllib.parse",
            "from snowflake.sqlalchemy import URL"
        ];
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        const rolePart = config.role ? `, role='${config.role}'` : '';
        return `
# Connect to the Snowflake database
${connectionName} = sqlalchemy.create_engine(URL(
    account='${config.account}',
    user='${config.username}',
    password=urllib.parse.quote("${config.password}"),
    database='${config.database}',
    schema='${config.schema}',
    warehouse='${config.warehouse}'${rolePart}
))
`;
    }
    generateComponentCode({ config, inputName }) {
        const uniqueEngineName = `${inputName}Engine`;
        let mappingsCode = "";
        let columnsCode = "";
        if (config.mapping && config.mapping.length > 0) {
            const renameMap = config.mapping
                .filter(map => map.input && map.input.value !== undefined && map.input.value !== null)
                .map(map => {
                if (map.input.value != map.value) {
                    return `"${map.input.value}": "${map.value}"`;
                }
                return undefined;
            })
                .filter(value => value !== undefined);
            if (renameMap.length > 0) {
                mappingsCode = `
# Rename columns based on the mapping
${inputName} = ${inputName}.rename(columns={${renameMap.join(", ")}})
`;
            }
            const selectedColumns = config.mapping
                .filter(map => map.value !== null && map.value !== undefined)
                .map(map => `"${map.value}"`)
                .join(', ');
            if (selectedColumns) {
                columnsCode = `
# Only keep relevant columns
${inputName} = ${inputName}[[${selectedColumns}]]
`;
            }
        }
        const ifExistsAction = config.ifTableExists;
        const schemaParam = (config.schema && config.schema.toUpperCase() !== 'PUBLIC')
            ? `,
    schema="${config.schema}"`
            : '';
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        return `
${connectionCode}
${mappingsCode}${columnsCode}
# Write DataFrame to Snowflake
try:
    ${inputName}.to_sql(
        name="${config.tableName.value}",
        schema="${config.schema}",
        con=${uniqueEngineName},
        if_exists="${ifExistsAction}",
        index=False${schemaParam}
    )
finally:
    ${uniqueEngineName}.dispose()
`;
    }
}


/***/ }),

/***/ "./lib/components/outputs/databases/SqlServerOutput.js":
/*!*************************************************************!*\
  !*** ./lib/components/outputs/databases/SqlServerOutput.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SqlServerOutput: () => (/* binding */ SqlServerOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class SqlServerOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            host: "localhost",
            port: "1433",
            databaseName: "",
            username: "",
            password: "",
            tableName: "",
            ifTableExists: "fail",
            mode: "insert"
        };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "input",
                    label: "Host",
                    id: "host",
                    placeholder: "Enter database host",
                    connection: "SQL Server",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Port",
                    id: "port",
                    placeholder: "Enter database port",
                    connection: "SQL Server",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Database Name",
                    id: "databaseName",
                    placeholder: "Enter database name",
                    connection: "SQL Server",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Username",
                    id: "username",
                    placeholder: "Enter username",
                    connection: "SQL Server",
                    advanced: true
                },
                {
                    type: "input",
                    label: "Password",
                    id: "password",
                    placeholder: "Enter password",
                    connection: "SQL Server",
                    inputType: "password",
                    advanced: true
                },
                {
                    type: "table",
                    label: "Table Name",
                    query: `SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE';`,
                    id: "tableName",
                    placeholder: "Enter table name"
                },
                {
                    type: "radio",
                    label: "If Table Exists",
                    id: "ifTableExists",
                    options: [
                        { value: "fail", label: "Fail" },
                        { value: "replace", label: "Replace" },
                        { value: "append", label: "Append" }
                    ],
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Mode",
                    id: "mode",
                    options: [
                        { value: "insert", label: "INSERT" }
                    ],
                    advanced: true
                },
                {
                    type: "dataMapping",
                    label: "Mapping",
                    id: "mapping",
                    tooltip: "By default, the mapping is inferred from the input data. By specifying a schema, you override the incoming schema.",
                    outputType: "relationalDatabase",
                    imports: ["pyodbc"],
                    drivers: "mssql",
                    query: `
SELECT 
    COLUMN_NAME AS "Field",
    DATA_TYPE AS "Type",
    IS_NULLABLE AS "Null",
    COLUMN_DEFAULT AS "Default",
    '' AS "Extra"
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = '{{table}}' AND TABLE_SCHEMA = 'dbo';
`,
                    typeOptions: [
                        { value: "INT", label: "INT" },
                        { value: "VARCHAR", label: "VARCHAR" },
                        { value: "NVARCHAR", label: "NVARCHAR" },
                        { value: "TEXT", label: "TEXT" },
                        { value: "DATETIME", label: "DATETIME" },
                        { value: "DATE", label: "DATE" },
                        { value: "FLOAT", label: "FLOAT" },
                        { value: "DECIMAL", label: "DECIMAL" },
                        { value: "BIT", label: "BIT" },
                        { value: "BIGINT", label: "BIGINT" },
                        { value: "SMALLINT", label: "SMALLINT" },
                        { value: "TINYINT", label: "TINYINT" },
                        { value: "CHAR", label: "CHAR" },
                        { value: "NCHAR", label: "NCHAR" },
                        { value: "NTEXT", label: "NTEXT" },
                        { value: "BINARY", label: "BINARY" },
                        { value: "VARBINARY", label: "VARBINARY" },
                        { value: "IMAGE", label: "IMAGE" },
                        { value: "UNIQUEIDENTIFIER", label: "UNIQUEIDENTIFIER" },
                        { value: "XML", label: "XML" },
                        { value: "TIME", label: "TIME" },
                        { value: "DATETIME2", label: "DATETIME2" },
                        { value: "DATETIMEOFFSET", label: "DATETIMEOFFSET" },
                        { value: "SMALLDATETIME", label: "SMALLDATETIME" },
                        { value: "REAL", label: "REAL" },
                        { value: "MONEY", label: "MONEY" },
                        { value: "SMALLMONEY", label: "SMALLMONEY" },
                    ],
                    advanced: true
                },
                {
                    type: "info",
                    label: "Drivers installation",
                    id: "driversInstallation",
                    text: "You may need to install additional drivers on your machine for this component to function.\nFor Mac you need to install 'brew install unixodbc'",
                    advanced: true
                },
            ],
        };
        const description = "Use SQL Server Output to insert data into a SQL Server table by specifying a data mapping between the incoming data and the existing table schema.";
        super("SQL Server Output", "sqlServerOutput", description, "pandas_df_output", [], "outputs.Databases", _icons__WEBPACK_IMPORTED_MODULE_1__.sqlServerIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        return ['pyodbc'];
    }
    provideImports({ config }) {
        return ["import pandas as pd", "import sqlalchemy", "import pyodbc"];
    }
    generateDatabaseConnectionCode({ config, connectionName }) {
        return `
# Connect to the SQL Server database
${connectionName} = sqlalchemy.create_engine(
  "mssql+pyodbc://${config.username}:${config.password}@${config.host}:${config.port}/${config.databaseName}?driver=ODBC+Driver+17+for+SQL+Server"
)
`;
    }
    generateComponentCode({ config, inputName }) {
        const uniqueEngineName = `${inputName}_Engine`;
        let mappingsCode = "";
        let columnsCode = "";
        if (config.mapping && config.mapping.length > 0) {
            const renameMap = config.mapping
                .filter(map => map.input && map.input.value !== undefined && map.input.value !== null)
                .map(map => {
                if (map.input.value != map.value) {
                    return `"${map.input.value}": "${map.value}"`;
                }
                return undefined;
            })
                .filter(value => value !== undefined);
            if (renameMap.length > 0) {
                mappingsCode = `
    # Rename columns based on the mapping
    ${inputName} = ${inputName}.rename(columns={${renameMap.join(", ")}})
    `;
            }
            const selectedColumns = config.mapping
                .filter(map => map.value !== null && map.value !== undefined)
                .map(map => `"${map.value}"`)
                .join(', ');
            if (selectedColumns) {
                columnsCode = `
    # Only keep relevant columns
    ${inputName} = ${inputName}[[${selectedColumns}]]
    `;
            }
        }
        const ifExistsAction = config.ifTableExists;
        const connectionCode = this.generateDatabaseConnectionCode({ config, connectionName: uniqueEngineName });
        return `
${connectionCode}
${mappingsCode}${columnsCode}
# Write DataFrame to SQL Server
try:
    ${inputName}.to_sql(
        name="${config.tableName}",
        con=${uniqueEngineName},
        if_exists="${ifExistsAction}",
        index=False,
        schema="dbo"
    )
finally:
    ${uniqueEngineName}.dispose()
`;
    }
}


/***/ }),

/***/ "./lib/components/outputs/files/AzureBlobFileOutput.js":
/*!*************************************************************!*\
  !*** ./lib/components/outputs/files/AzureBlobFileOutput.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AzureBlobFileOutput: () => (/* binding */ AzureBlobFileOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _CsvFileOutput__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CsvFileOutput */ "./lib/components/outputs/files/CsvFileOutput.js");
/* harmony import */ var _JsonFileOutput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./JsonFileOutput */ "./lib/components/outputs/files/JsonFileOutput.js");
/* harmony import */ var _ExcelFileOutput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ExcelFileOutput */ "./lib/components/outputs/files/ExcelFileOutput.js");
/* harmony import */ var _ParquetFileOutput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ParquetFileOutput */ "./lib/components/outputs/files/ParquetFileOutput.js");
/* harmony import */ var _XmlFileOutput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./XmlFileOutput */ "./lib/components/outputs/files/XmlFileOutput.js");







class AzureBlobFileOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileType: "csv", fileLocation: "azb", connectionMethod: "env" };
        const csvComponent = new _CsvFileOutput__WEBPACK_IMPORTED_MODULE_1__.CsvFileOutput();
        const jsonComponent = new _JsonFileOutput__WEBPACK_IMPORTED_MODULE_2__.JsonFileOutput();
        const excelComponent = new _ExcelFileOutput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileOutput();
        const parquetComponent = new _ParquetFileOutput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileOutput();
        const xmlComponent = new _XmlFileOutput__WEBPACK_IMPORTED_MODULE_5__.XmlFileOutput();
        const fieldsToRemove = ["fileLocation"]; // Fields to remove from all components
        const filteredCsvFields = csvComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredJsonFields = jsonComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredExcelFields = excelComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredParquetFields = parquetComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredXmlFields = xmlComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Type",
                    id: "fileType",
                    options: [
                        { value: "csv", label: "CSV" },
                        { value: "json", label: "JSON" },
                        { value: "excel", label: "Excel" },
                        { value: "parquet", label: "Parquet" },
                        { value: "xml", label: "XML" }
                    ]
                },
                // Conditionally display filtered fields based on selected file type
                ...filteredCsvFields.map(field => ({
                    ...field,
                    condition: { fileType: ["csv"], ...(field.condition || {}) }
                })),
                ...filteredJsonFields.map(field => ({
                    ...field,
                    condition: { fileType: ["json"], ...(field.condition || {}) }
                })),
                ...filteredExcelFields.map(field => ({
                    ...field,
                    condition: { fileType: ["excel"], ...(field.condition || {}) }
                })),
                ...filteredParquetFields.map(field => ({
                    ...field,
                    condition: { fileType: ["parquet"], ...(field.condition || {}) }
                })),
                ...filteredXmlFields.map(field => ({
                    ...field,
                    condition: { fileType: ["xml"], ...(field.condition || {}) }
                }))
            ]
        };
        const description = "Use File Output to write or append data to a file remotely (Azure Blob). Supports CSV, JSON, Excel, Parquet, and XML formats.";
        super("Azure Blob File Output", "fileOutput", description, "pandas_df_output", [], "outputs.Azure", _icons__WEBPACK_IMPORTED_MODULE_6__.azureServicesIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        if (config.fileType === "csv") {
            const csvComponent = new _CsvFileOutput__WEBPACK_IMPORTED_MODULE_1__.CsvFileOutput();
            return csvComponent.generateComponentCode({ config, inputName });
        }
        else if (config.fileType === "json") {
            const jsonComponent = new _JsonFileOutput__WEBPACK_IMPORTED_MODULE_2__.JsonFileOutput();
            return jsonComponent.generateComponentCode({ config, inputName });
        }
        else if (config.fileType === "excel") {
            const excelComponent = new _ExcelFileOutput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileOutput();
            return excelComponent.generateComponentCode({ config, inputName });
        }
        else if (config.fileType === "parquet") {
            const parquetComponent = new _ParquetFileOutput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileOutput();
            return parquetComponent.generateComponentCode({ config, inputName });
        }
        else if (config.fileType === "xml") {
            const xmlComponent = new _XmlFileOutput__WEBPACK_IMPORTED_MODULE_5__.XmlFileOutput();
            return xmlComponent.generateComponentCode({ config, inputName });
        }
        return '';
    }
}


/***/ }),

/***/ "./lib/components/outputs/files/CsvFileOutput.js":
/*!*******************************************************!*\
  !*** ./lib/components/outputs/files/CsvFileOutput.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CsvFileOutput: () => (/* binding */ CsvFileOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");
/* harmony import */ var _common_AzureOptionsHandler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/AzureOptionsHandler */ "./lib/components/common/AzureOptionsHandler.js");




class CsvFileOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env", csvOptions: { sep: ",", header: true, index: false } };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                ..._common_AzureOptionsHandler__WEBPACK_IMPORTED_MODULE_2__.AzureOptionsHandler.getAZBFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\\.(csv|tsv|txt)$",
                    validationMessage: "This field expects a file with a csv, tsv or txt extension such as output.csv."
                },
                {
                    type: "selectCustomizable",
                    label: "Separator",
                    id: "csvOptions.sep",
                    placeholder: "auto",
                    options: [
                        { value: ",", label: "comma (,)" },
                        { value: ";", label: "semicolon (;)" },
                        { value: " ", label: "space" },
                        { value: "  ", label: "tab" },
                        { value: "|", label: "pipe (|)" }
                    ],
                },
                {
                    type: "boolean",
                    label: "Create folders if don't exist",
                    id: "createFoldersIfNotExist",
                    condition: { fileLocation: ["local"] },
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Mode",
                    id: "csvOptions.mode",
                    options: [
                        { value: "w", label: "Write" },
                        { value: "x", label: "Exclusive Creation" },
                        { value: "a", label: "Append" }
                    ],
                    advanced: true
                },
                {
                    type: "selectCustomizable",
                    label: "Quoting",
                    id: "csvOptions.quoting",
                    placeholder: "Default: 0 (Minimal Quoting)",
                    tooltip: "Controls how special characters like commas, quotes, or newlines are handled in text fields when writing to or reading from a CSV file.",
                    options: [
                        { value: "0", label: "Minimal quoting", tooltip: "Quotes only fields that contain special characters (commas, quotes, newlines)." },
                        { value: "1", label: "Quote All", tooltip: "Quotes all fields, regardless of content." },
                        { value: "2", label: "Quote All Non-Numeric", tooltip: "Quotes all non-numeric fields. Numeric fields are written without quotes." },
                        { value: "3", label: "Quote None", tooltip: "Disables quoting entirely. You should use an escape character for special characters." }
                    ],
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Header",
                    id: "csvOptions.header",
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Row index",
                    tooltip: "Write row names (index).",
                    id: "csvOptions.index",
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "csvOptions.storage_options",
                    condition: { fileLocation: ["s3"] },
                    advanced: true
                }
            ],
        };
        const description = "Use CSV File Output to write or append data to a CSV file locally or remotely (S3).";
        super("CSV File Output", "csvFileOutput", description, "pandas_df_output", [], "outputs", _icons__WEBPACK_IMPORTED_MODULE_3__.filePlusIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        const optionsString = this.generateOptionsCode(config);
        const createFoldersCode = config.createFoldersIfNotExist
            ? `os.makedirs(os.path.dirname("${config.filePath}"), exist_ok=True)\n`
            : '';
        const code = `
# Export to CSV file
${createFoldersCode}${inputName}.to_csv("${config.filePath}"${optionsString})
`;
        return code.trim();
    }
    generateOptionsCode(config) {
        let csvOptions = { ...config.csvOptions };
        // Handle storage options
        let storageOptions = csvOptions.storage_options || {};
        storageOptions = config.fileLocation === 's3' ?
            _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions)
            : _common_AzureOptionsHandler__WEBPACK_IMPORTED_MODULE_2__.AzureOptionsHandler.handleAZBptions(config, storageOptions);
        if (Object.keys(storageOptions).length > 0) {
            csvOptions.storage_options = storageOptions;
        }
        // Generate options string
        let optionsEntries = Object.entries(csvOptions)
            .filter(([key, value]) => value !== null && value !== '')
            .map(([key, value]) => {
            if (typeof value === 'boolean') {
                return `${key}=${value ? 'True' : 'False'}`;
            }
            else if (key === 'storage_options') {
                return `${key}=${JSON.stringify(value)}`;
            }
            else if (key === 'quoting') {
                return `${key}=${value}`;
            }
            return `${key}='${value}'`;
        });
        const optionsString = optionsEntries.join(', ');
        return optionsString ? `, ${optionsString}` : '';
    }
}


/***/ }),

/***/ "./lib/components/outputs/files/ExcelFileOutput.js":
/*!*********************************************************!*\
  !*** ./lib/components/outputs/files/ExcelFileOutput.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExcelFileOutput: () => (/* binding */ ExcelFileOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");



class ExcelFileOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env", excelOptions: { header: true }, engine: 'xlsxwriter' };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\\.(xlsx)$",
                    validationMessage: "This field expects a file with a xlsx extension such as output.xlsx."
                },
                {
                    type: "input",
                    label: "Sheet",
                    id: "excelOptions.sheet_name",
                    placeholder: "default: Sheet1"
                },
                {
                    type: "boolean",
                    label: "Create folders if don't exist",
                    condition: { fileLocation: ["local"] },
                    id: "createFoldersIfNotExist",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Mode",
                    id: "mode",
                    options: [
                        { value: "write", label: "Write" },
                        { value: "append", label: "Append" }
                    ],
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Header",
                    id: "excelOptions.header",
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Row index",
                    tooltip: "Write row names (index).",
                    id: "excelOptions.index",
                    advanced: true
                },
                {
                    type: "select",
                    label: "Engine",
                    id: "engine",
                    tooltip: "Depending on the file format, different engines might be used.\nopenpyxl supports newer Excel file formats.\n calamine supports Excel (.xls, .xlsx, .xlsm, .xlsb) and OpenDocument (.ods) file formats.\n odf supports OpenDocument file formats (.odf, .ods, .odt).\n pyxlsb supports Binary Excel files.\n xlrd supports old-style Excel files (.xls).",
                    options: [
                        { value: "openpyxl", label: "openpyxl" },
                        { value: "xlsxwriter", label: "xlsxwriter" }
                    ],
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "csvOptions.storage_options",
                    condition: { fileLocation: ["s3"] },
                    advanced: true
                },
            ],
        };
        const description = "Use Excel File Output to write or append data to an Excel file locally or remotely (S3).";
        super("Excel File Output", "excelFileOutput", description, "pandas_df_output", [], "outputs", _icons__WEBPACK_IMPORTED_MODULE_2__.filePlusIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        const engine = config.engine;
        if (engine === 'None' || engine === 'openpyxl') {
            deps.push('openpyxl');
        }
        if (engine === 'xlsxwriter') {
            deps.push('xlsxwriter');
        }
        return deps;
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        const optionsString = this.generateOptionsCode(config);
        const createFoldersCode = config.createFoldersIfNotExist
            ? `os.makedirs(os.path.dirname("${config.filePath}"), exist_ok=True)\n`
            : '';
        const engine = config.engine !== 'None' ? `'${config.engine}'` : config.engine;
        let code = '';
        if (config.excelOptions.mode === 'append') {
            code = `
# Exporting to Excel (append mode)
with pd.ExcelWriter("${config.filePath}", mode="a", engine=${engine}) as writer:
    ${inputName}.to_excel(writer${optionsString})
`;
        }
        else {
            code = `
# Exporting to Excel
${inputName}.to_excel("${config.filePath}", engine=${engine}${optionsString})
`;
        }
        return `${createFoldersCode}${code.trim()}`;
    }
    generateOptionsCode(config) {
        let excelOptions = { ...config.excelOptions };
        // Handle storage options
        let storageOptions = excelOptions.storage_options || {};
        storageOptions = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions);
        if (Object.keys(storageOptions).length > 0) {
            excelOptions.storage_options = storageOptions;
        }
        // Generate options string
        let optionsEntries = Object.entries(excelOptions)
            .filter(([key, value]) => value !== null && value !== '')
            .map(([key, value]) => {
            if (typeof value === 'boolean') {
                return `${key}=${value ? 'True' : 'False'}`;
            }
            else if (key === 'storage_options') {
                return `${key}=${JSON.stringify(value)}`;
            }
            else if (value === "None") {
                return `${key}=None`;
            }
            return `${key}='${value}'`;
        });
        const optionsString = optionsEntries.join(', ');
        return optionsString ? `, ${optionsString}` : '';
    }
}


/***/ }),

/***/ "./lib/components/outputs/files/JsonFileOutput.js":
/*!********************************************************!*\
  !*** ./lib/components/outputs/files/JsonFileOutput.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JsonFileOutput: () => (/* binding */ JsonFileOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");



class JsonFileOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env", jsonOptions: { "orient": "records" } };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\.(json|jsonl)$",
                    validationMessage: "This field expects a file with a json or jsonl extension such as output.json."
                },
                {
                    type: "select",
                    label: "Orientation",
                    id: "jsonOptions.orient",
                    placeholder: "Select orientation",
                    options: [
                        { value: "columns", label: "columns (JSON object with column labels as keys)" },
                        { value: "records", label: "records (List of rows as JSON objects)" },
                        { value: "index", label: "index (Dict with index labels as keys)" },
                        { value: "split", label: "split (Dict with 'index', 'columns', and 'data' keys)" },
                        { value: "table", label: "table (Dict with 'schema' and 'data' keys, following the Table Schema)" }
                    ],
                },
                {
                    type: "boolean",
                    label: "Create folders if don't exist",
                    condition: { fileLocation: ["local"] },
                    id: "createFoldersIfNotExist",
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "csvOptions.storage_options",
                    condition: { fileLocation: ["s3"] },
                    advanced: true
                }
            ],
        };
        const description = "Use JSON File Output to write or append data to a JSON file locally or remotely (S3).";
        super("JSON File Output", "jsonFileOutput", description, "pandas_df_output", [], "outputs", _icons__WEBPACK_IMPORTED_MODULE_2__.filePlusIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        const optionsString = this.generateOptionsCode(config);
        const createFoldersCode = config.createFoldersIfNotExist
            ? `os.makedirs(os.path.dirname("${config.filePath}"), exist_ok=True)\n`
            : '';
        const code = `
# Export to JSON file
${createFoldersCode}${inputName}.to_json("${config.filePath}"${optionsString})
`;
        return code.trim();
    }
    generateOptionsCode(config) {
        let jsonOptions = { ...config.jsonOptions };
        // Handle storage options
        let storageOptions = jsonOptions.storage_options || {};
        storageOptions = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions);
        if (Object.keys(storageOptions).length > 0) {
            jsonOptions.storage_options = storageOptions;
        }
        // Generate options string
        let optionsEntries = Object.entries(jsonOptions)
            .filter(([key, value]) => value !== null && value !== '')
            .map(([key, value]) => {
            if (key === 'storage_options') {
                return `${key}=${JSON.stringify(value)}`;
            }
            return `${key}="${value}"`;
        });
        const optionsString = optionsEntries.join(', ');
        return optionsString ? `, ${optionsString}` : '';
    }
}


/***/ }),

/***/ "./lib/components/outputs/files/ParquetFileOutput.js":
/*!***********************************************************!*\
  !*** ./lib/components/outputs/files/ParquetFileOutput.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ParquetFileOutput: () => (/* binding */ ParquetFileOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");



class ParquetFileOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env", parquetOptions: { compression: "snappy" } };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\\.(parquet)$",
                    validationMessage: "This field expects a file with a .parquet extension such as output.parquet."
                },
                {
                    type: "radio",
                    label: "Compression",
                    id: "parquetOptions.compression",
                    options: [
                        { value: "snappy", label: "Snappy" },
                        { value: "gzip", label: "GZip" },
                        { value: "brotli", label: "Brotli" },
                        { value: "None", label: "None" }
                    ],
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Create folders if don't exist",
                    condition: { fileLocation: ["local"] },
                    id: "createFoldersIfNotExist",
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "csvOptions.storage_options",
                    condition: { fileLocation: ["s3"] },
                    advanced: true
                }
            ],
        };
        const description = "Use Parquet File Output to write or append data to a Parquet file locally or remotely (S3).";
        super("Parquet File Output", "parquetFileOutput", "no desc", "pandas_df_output", [], "outputs", _icons__WEBPACK_IMPORTED_MODULE_2__.filePlusIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('pyarrow');
        return deps;
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        const optionsString = this.generateOptionsCode(config);
        const createFoldersCode = config.createFoldersIfNotExist
            ? `os.makedirs(os.path.dirname("${config.filePath}"), exist_ok=True)\n`
            : '';
        const code = `
# Export to Parquet file
${createFoldersCode}${inputName}.to_parquet("${config.filePath}"${optionsString})
`;
        return code.trim();
    }
    generateOptionsCode(config) {
        let parquetOptions = { ...config.parquetOptions };
        // Handle storage options
        let storageOptions = parquetOptions.storage_options || {};
        storageOptions = _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.handleS3SpecificOptions(config, storageOptions);
        if (Object.keys(storageOptions).length > 0) {
            parquetOptions.storage_options = storageOptions;
        }
        // Generate options string
        let optionsEntries = Object.entries(parquetOptions)
            .filter(([key, value]) => value !== null && value !== '')
            .map(([key, value]) => {
            if (key === 'storage_options') {
                return `${key}=${JSON.stringify(value)}`;
            }
            else if (value === "None") {
                return `${key}=None`;
            }
            return `${key}="${value}"`;
        });
        const optionsString = optionsEntries.join(', ');
        return optionsString ? `, ${optionsString}` : '';
    }
}


/***/ }),

/***/ "./lib/components/outputs/files/S3FileOutput.js":
/*!******************************************************!*\
  !*** ./lib/components/outputs/files/S3FileOutput.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   S3FileOutput: () => (/* binding */ S3FileOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _CsvFileOutput__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CsvFileOutput */ "./lib/components/outputs/files/CsvFileOutput.js");
/* harmony import */ var _JsonFileOutput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./JsonFileOutput */ "./lib/components/outputs/files/JsonFileOutput.js");
/* harmony import */ var _ExcelFileOutput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ExcelFileOutput */ "./lib/components/outputs/files/ExcelFileOutput.js");
/* harmony import */ var _ParquetFileOutput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ParquetFileOutput */ "./lib/components/outputs/files/ParquetFileOutput.js");
/* harmony import */ var _XmlFileOutput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./XmlFileOutput */ "./lib/components/outputs/files/XmlFileOutput.js");







class S3FileOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileType: "csv", fileLocation: "s3", connectionMethod: "env" };
        const csvComponent = new _CsvFileOutput__WEBPACK_IMPORTED_MODULE_1__.CsvFileOutput();
        const jsonComponent = new _JsonFileOutput__WEBPACK_IMPORTED_MODULE_2__.JsonFileOutput();
        const excelComponent = new _ExcelFileOutput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileOutput();
        const parquetComponent = new _ParquetFileOutput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileOutput();
        const xmlComponent = new _XmlFileOutput__WEBPACK_IMPORTED_MODULE_5__.XmlFileOutput();
        const fieldsToRemove = ["fileLocation"]; // Fields to remove from all components
        const filteredCsvFields = csvComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredJsonFields = jsonComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredExcelFields = excelComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredParquetFields = parquetComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const filteredXmlFields = xmlComponent._form['fields'].filter(field => !fieldsToRemove.includes(field.id));
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Type",
                    id: "fileType",
                    options: [
                        { value: "csv", label: "CSV" },
                        { value: "json", label: "JSON" },
                        { value: "excel", label: "Excel" },
                        { value: "parquet", label: "Parquet" },
                        { value: "xml", label: "XML" }
                    ]
                },
                // Conditionally display filtered fields based on selected file type
                ...filteredCsvFields.map(field => ({
                    ...field,
                    condition: { fileType: ["csv"], ...(field.condition || {}) }
                })),
                ...filteredJsonFields.map(field => ({
                    ...field,
                    condition: { fileType: ["json"], ...(field.condition || {}) }
                })),
                ...filteredExcelFields.map(field => ({
                    ...field,
                    condition: { fileType: ["excel"], ...(field.condition || {}) }
                })),
                ...filteredParquetFields.map(field => ({
                    ...field,
                    condition: { fileType: ["parquet"], ...(field.condition || {}) }
                })),
                ...filteredXmlFields.map(field => ({
                    ...field,
                    condition: { fileType: ["xml"], ...(field.condition || {}) }
                }))
            ]
        };
        const description = "Use File Output to write or append data to a file remotely (S3). Supports CSV, JSON, Excel, Parquet, and XML formats.";
        super("S3 File Output", "fileOutput", description, "pandas_df_output", [], "outputs.AWS", _icons__WEBPACK_IMPORTED_MODULE_6__.s3Icon, defaultConfig, form);
    }
    provideImports({ config }) {
        let imports = ["import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports;
    }
    generateComponentCode({ config, inputName }) {
        if (config.fileType === "csv") {
            const csvComponent = new _CsvFileOutput__WEBPACK_IMPORTED_MODULE_1__.CsvFileOutput();
            return csvComponent.generateComponentCode({ config, inputName });
        }
        else if (config.fileType === "json") {
            const jsonComponent = new _JsonFileOutput__WEBPACK_IMPORTED_MODULE_2__.JsonFileOutput();
            return jsonComponent.generateComponentCode({ config, inputName });
        }
        else if (config.fileType === "excel") {
            const excelComponent = new _ExcelFileOutput__WEBPACK_IMPORTED_MODULE_3__.ExcelFileOutput();
            return excelComponent.generateComponentCode({ config, inputName });
        }
        else if (config.fileType === "parquet") {
            const parquetComponent = new _ParquetFileOutput__WEBPACK_IMPORTED_MODULE_4__.ParquetFileOutput();
            return parquetComponent.generateComponentCode({ config, inputName });
        }
        else if (config.fileType === "xml") {
            const xmlComponent = new _XmlFileOutput__WEBPACK_IMPORTED_MODULE_5__.XmlFileOutput();
            return xmlComponent.generateComponentCode({ config, inputName });
        }
        return '';
    }
}


/***/ }),

/***/ "./lib/components/outputs/files/XmlFileOutput.js":
/*!*******************************************************!*\
  !*** ./lib/components/outputs/files/XmlFileOutput.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   XmlFileOutput: () => (/* binding */ XmlFileOutput)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
/* harmony import */ var _common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/S3OptionsHandler */ "./lib/components/common/S3OptionsHandler.js");



class XmlFileOutput extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { fileLocation: "local", connectionMethod: "env" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "File Location",
                    id: "fileLocation",
                    options: [
                        { value: "local", label: "Local" },
                        { value: "s3", label: "S3" }
                    ],
                    advanced: true
                },
                ..._common_S3OptionsHandler__WEBPACK_IMPORTED_MODULE_1__.S3OptionsHandler.getAWSFields(),
                {
                    type: "file",
                    label: "File path",
                    id: "filePath",
                    placeholder: "Type file name",
                    validation: "\\.xml$",
                    validationMessage: "This field expects a file with an xml extension such as output.xml."
                },
                {
                    type: "boolean",
                    label: "Create folders if don't exist",
                    condition: { fileLocation: ["local"] },
                    id: "createFoldersIfNotExist",
                    advanced: true
                },
                {
                    type: "keyvalue",
                    label: "Storage Options",
                    id: "csvOptions.storage_options",
                    condition: { fileLocation: ["s3"] },
                    advanced: true
                }
            ],
        };
        const description = "Use XML File Output to write or append data to a XML file locally or remotely (S3).";
        super("XML File Output", "xmlFileOutput", "no desc", "pandas_df_output", [], "outputs", _icons__WEBPACK_IMPORTED_MODULE_2__.filePlusIcon, defaultConfig, form);
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('lxml');
        return deps;
    }
    provideImports({ config }) {
        // Adjust this based on the XML library you choose to use for output
        let imports = ["import xml.etree.ElementTree as ET", "import pandas as pd"];
        if (config.createFoldersIfNotExist) {
            imports.push("import os");
        }
        return imports; // Adjust if pandas isn't required
    }
    generateComponentCode({ config, inputName }) {
        // Create unique variable names based on the inputName for the XML output
        const xmlOutputVar = `${inputName}_xml_output`;
        const fileVar = `${inputName}_file`;
        const createFoldersCode = config.createFoldersIfNotExist ? `os.makedirs(os.path.dirname("${config.filePath}"), exist_ok=True)\n` : '';
        const code = `
# Export to XML file
${createFoldersCode}${xmlOutputVar} = ${inputName}.to_xml()
with open("${config.filePath}", "w") as ${fileVar}:
    ${fileVar}.write(${xmlOutputVar})
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/settings/Connection.js":
/*!***********************************************!*\
  !*** ./lib/components/settings/Connection.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Connection: () => (/* binding */ Connection)
/* harmony export */ });
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @amphi/pipeline-components-manager */ "webpack/sharing/consume/default/@amphi/pipeline-components-manager");
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/CopyOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactflow */ "webpack/sharing/consume/default/reactflow/reactflow");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(reactflow__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
var _a;






class Connection extends (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.PipelineComponent)() {
    constructor() {
        super(...arguments);
        this._name = "Connection";
        this._id = "connection";
        this._type = "connection";
        this._category = "configuration";
        this._description = `Use Connection to set up a connection (e.g., credentials, database parameters, configuration file)
  once for the pipeline, and reuse it across different components. This approach ensures that no credentials are stored 
  in the pipeline, as they can be retrieved from environment variables or a configuration files.`;
        this._icon = _icons__WEBPACK_IMPORTED_MODULE_4__.keyIcon;
        this._default = {};
        this._form = {};
    }
    UIComponent({ id, data, context, componentService, manager, commands, rendermimeRegistry }) {
        const { setNodes, deleteElements, setViewport } = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useReactFlow)();
        const store = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStoreApi)();
        const deleteNode = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(() => {
            deleteElements({ nodes: [{ id }] });
        }, [id, deleteElements]);
        const zoomSelector = (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.createZoomSelector)();
        const showContent = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)(zoomSelector);
        const selector = (s) => ({
            nodeInternals: s.nodeInternals,
            edges: s.edges,
        });
        const { nodeInternals, edges } = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)(selector);
        const nodeId = id;
        const internals = { nodeInternals, edges, nodeId, componentService };
        const handleElement = react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.renderHandle, {
            type: Connection.Type,
            Handle: reactflow__WEBPACK_IMPORTED_MODULE_3__.Handle,
            Position: reactflow__WEBPACK_IMPORTED_MODULE_3__.Position,
            internals: internals
        });
        const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((evtTargetValue, field) => {
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.onChange)({ evtTargetValue, field, nodeId, store, setNodes });
        }, [nodeId, store, setNodes]);
        const isSelected = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)((state) => { var _b; return !!((_b = state.nodeInternals.get(id)) === null || _b === void 0 ? void 0 : _b.selected); });
        const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), null,
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.renderComponentUI)({
                id: id,
                data: data,
                context: context,
                manager: manager,
                commands: commands,
                name: Connection.Name,
                ConfigForm: Connection.ConfigForm,
                configFormProps: {
                    nodeId: id,
                    data,
                    context,
                    componentService,
                    manager,
                    commands,
                    store,
                    setNodes,
                    handleChange,
                    modalOpen,
                    setModalOpen
                },
                Icon: Connection.Icon,
                showContent: showContent,
                handle: handleElement,
                deleteNode: deleteNode,
                setViewport: setViewport,
                handleChange,
                isSelected
            }),
            showContent && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(reactflow__WEBPACK_IMPORTED_MODULE_3__.NodeToolbar, { isVisible: true, position: reactflow__WEBPACK_IMPORTED_MODULE_3__.Position.Bottom },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("button", { onClick: () => setModalOpen(true) },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_4__.settingsIcon.react, null))))));
    }
    provideImports({ config }) {
        const imports = ["import os"];
        if (config.fetchMethod === "envFile") {
            imports.push("from dotenv import load_dotenv");
        }
        return imports;
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('python-dotenv');
        // console.log("python-dotenv");
        return deps;
    }
    generateComponentCode({ config }) {
        let code = `# Connection constants for ${config.connectionType}\n`;
        // If the fetch method is "envFile", load the environment variables from the specified file
        if (config.fetchMethod === "envFile") {
            code += `load_dotenv(dotenv_path="${config.environmentVariableFile}")\n\n`;
        }
        // Define the variables based on the fetch method
        config.variables.forEach(variable => {
            let varName = variable.name;
            if (config.fetchMethod === "clear") {
                code += `${varName} = "${variable.value}"\n`;
            }
            else if (config.fetchMethod === "envVars") {
                if (variable.default) {
                    code += `${varName} = os.getenv('${varName}', '${variable.default}')\n`;
                }
                else {
                    code += `${varName} = os.getenv('${varName}')\n`;
                }
            }
            else if (config.fetchMethod === "envFile") {
                if (variable.default) {
                    code += `${varName} = os.getenv('${varName}', '${variable.default}')\n`;
                }
                else {
                    code += `${varName} = os.getenv('${varName}')\n`;
                }
            }
        });
        code += "\n";
        return code;
    }
}
_a = Connection;
Connection.ConfigForm = ({ nodeId, data, context, componentService, manager, commands, store, setNodes, handleChange, modalOpen, setModalOpen }) => {
    const EditableContext = react__WEBPACK_IMPORTED_MODULE_2___default().createContext(null);
    const EditableRow = ({ index, ...props }) => {
        const [form] = antd__WEBPACK_IMPORTED_MODULE_1__.Form.useForm();
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form, { form: form, component: false },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(EditableContext.Provider, { value: form },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("tr", { ...props }))));
    };
    const EditableCell = ({ title, editable, children, dataIndex, record, handleSave, required, ...restProps }) => {
        const [editing, setEditing] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
        const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
        const form = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(EditableContext);
        (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
            var _b;
            if (editing) {
                (_b = inputRef.current) === null || _b === void 0 ? void 0 : _b.focus();
            }
        }, [editing]);
        const toggleEdit = () => {
            setEditing(!editing);
            form.setFieldsValue({ [dataIndex]: record[dataIndex] });
        };
        const save = async () => {
            try {
                const values = await form.validateFields();
                toggleEdit();
                handleSave({ ...record, ...values });
            }
            catch (errInfo) {
                console.error('Save failed:', errInfo);
            }
        };
        let childNode = children;
        if (editable) {
            childNode = editing ? (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { style: { margin: 0 }, name: dataIndex, rules: required ? [
                    {
                        required: true,
                        message: `${title} is required.`,
                    },
                ] : [] },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { ref: inputRef, onPressEnter: save, onBlur: save, onKeyDown: (e) => e.stopPropagation(), autoComplete: "off" }))) : (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: "editable-cell-value-wrap", style: { paddingRight: 24, minHeight: '20px', width: '100%', display: 'inline-block' }, onClick: () => toggleEdit() }, children));
        }
        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", { ...restProps },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { onDoubleClick: (e) => e.stopPropagation() }, childNode)));
    };
    const [dataSource, setDataSource] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(data.variables || []);
    const [connections, setConnections] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [selectedConnection, setSelectedConnection] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        label: data.connectionType,
        value: data.connectionType
    });
    const [connectionName, setConnectionName] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(data.connectionName || "");
    // const [fetchMethod, setFetchMethod] = useState<Option>(data.fetchMethod || "clear" );
    const fetchMethod = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => data.fetchMethod || "clear", [data.fetchMethod]);
    if (!data.fetchMethod) {
        handleChange(fetchMethod, "fetchMethod");
    }
    const [envVarFile, setEnvVarFile] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(data.envVarFile || "");
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
        handleChange(dataSource, "variables");
    }, [dataSource]);
    const handleDelete = (key) => {
        const newData = dataSource.filter((item) => item.key !== key);
        setDataSource(newData);
    };
    const defaultColumns = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => ([
        {
            title: (react__WEBPACK_IMPORTED_MODULE_2___default().createElement((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), null,
                "Name",
                dataSource.length > 0 && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: () => {
                        const variables = dataSource.map(item => `${item.name}=""\n`).join('');
                        return `Copy the following variables:\n${variables}`;
                    }, trigger: "hover" },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["default"], { style: { marginLeft: 8, cursor: 'pointer' }, onClick: async () => {
                            const variables = dataSource.map(item => `${item.name}=""\n`).join('');
                            try {
                                await navigator.clipboard.writeText(variables);
                                // Temporarily change the tooltip to "Copied to clipboard"
                                document.querySelector('.ant-tooltip-inner').textContent = 'Copied to clipboard';
                                setTimeout(() => {
                                    document.querySelector('.ant-tooltip-inner').textContent = `Copy the following variables:\n${variables}`;
                                }, 2000); // Change back after 2 seconds
                            }
                            catch (err) {
                                console.error('Could not copy text: ', err);
                            }
                        } }))))),
            dataIndex: 'name',
            width: '30%',
            editable: true,
            required: true
        },
        {
            title: 'Value',
            dataIndex: 'value',
            width: '40%',
            editable: true,
            required: false
        },
        {
            title: 'Default',
            dataIndex: 'default',
            width: '30%',
            editable: true,
            required: false
        }
        /*
        {
          title: '',
          dataIndex: 'operation',
          render: (_, record) =>
            dataSource.length >= 1 ? (
              <Popconfirm title="Sure to delete?" onConfirm={() => handleDelete(record.key)}>
                <DeleteOutlined />
              </Popconfirm>
            ) : null,
        }
        */
    ]), [dataSource]);
    const handleSave = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((row) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, { ...item, ...row });
        setDataSource(newData);
    }, [dataSource]);
    const components = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => ({
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    }), []);
    const columns = defaultColumns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                required: col.required,
                handleSave,
            }),
        };
    });
    const handleSelectChange = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((value) => {
        var _b;
        setSelectedConnection(value);
        const selectedConnectionFields = ((_b = connections.find(conn => conn.value === value.value)) === null || _b === void 0 ? void 0 : _b.fields) || [];
        handleChange(value.value, "connectionType");
        if (!data.customTitle) {
            handleChange(value.value + " Connection", "customTitle");
        }
        handleChange(value.value, "connectionName");
        setConnectionName(value.value);
        setDataSource(selectedConnectionFields.map(field => ({
            key: field.id,
            name: field.label.includes('_')
                ? field.label
                : _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.PipelineService.formatVarName(value.value + '_' + field.label),
            value: '',
            default: '',
        })));
    }, [connections, data.customTitle, handleChange]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
        const extractedConnections = extractConnections(componentService);
        setConnections(extractedConnections.map(conn => ({
            label: conn.connection,
            value: conn.connection,
            fields: conn.fields
        })));
    }, [componentService]);
    const extractConnections = (componentService) => {
        const components = componentService.getComponents();
        const connectionMap = {};
        components.forEach(component => {
            if (component._form && component._form.fields) {
                component._form.fields.forEach(field => {
                    if (field.connection && !field.ignoreConnection) {
                        if (!connectionMap[field.connection]) {
                            connectionMap[field.connection] = [];
                        }
                        const existingField = connectionMap[field.connection].find(f => f.id === field.id);
                        if (!existingField) {
                            const newField = {
                                id: field.id,
                                label: field.connectionVariableName || field.label
                            };
                            connectionMap[field.connection].push(newField);
                        }
                    }
                });
            }
        });
        return Object.keys(connectionMap).map(connection => ({
            connection,
            fields: connectionMap[connection]
        }));
    };
    const connectionNameTooltip = "Provide a name to the connection to describe and differentiate it with other connections.";
    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { theme: {
                token: {
                    colorPrimary: '#5F9B97',
                },
            } },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: "flex justify-center mt-1 pt-1.5 space-x-4" },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { direction: "vertical", size: "middle" },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space.Compact, null,
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { label: "Connection Name", tooltip: connectionNameTooltip },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.InputRegular, { field: {
                                    type: "input", label: "Submission", id: "connectionName", placeholder: "Optional name",
                                }, handleChange: (value) => {
                                    handleChange(value, 'connectionName');
                                    setConnectionName(value);
                                }, context: context, advanced: false, value: connectionName }))))),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Modal, { title: _a.Name, open: modalOpen, onOk: () => setModalOpen(false), onCancel: () => setModalOpen(false), width: 1000, footer: (_, { OkBtn }) => (react__WEBPACK_IMPORTED_MODULE_2___default().createElement((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(OkBtn, null))) },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form, { layout: "vertical", size: "small" },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { label: "Select connection type" },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { showSearch: true, labelInValue: true, className: "nodrag", onChange: handleSelectChange, value: selectedConnection, placeholder: 'Select connection', options: connections.map(conn => ({ label: conn.label, value: conn.value })), size: "middle" })),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("br", null),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { label: "Connection Name", tooltip: connectionNameTooltip },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.InputRegular, { field: {
                                type: "input", id: "connectionName", placeholder: "Optional name", label: ""
                            }, handleChange: (value) => {
                                handleChange(value, 'connectionName');
                                setConnectionName(value);
                            }, context: context, advanced: true, value: connectionName })),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("br", null),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { label: "Values to fetch from", tooltip: "Select the method used to retrieve the connection information. When choosing from an environment variables file, please specify the file in the file input below." },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.SelectRegular, { field: {
                                type: "select",
                                id: "fetchMethod",
                                label: "Values to fetch from",
                                placeholder: "Select method",
                                options: [
                                    { value: "clear", label: "Values in clear (not recommended)" },
                                    { value: "envVars", label: "Environment Variables (provided using Env. Variables component)" },
                                    { value: "envFile", label: "Environment Variables from .env file (recommended)" }
                                ]
                            }, handleChange: (value) => {
                                handleChange(value, 'fetchMethod');
                                if (value === "envVars" || value === "envFile") {
                                    setDataSource(prevDataSource => prevDataSource.map(item => ({
                                        ...item,
                                        value: `{os.getenv('${item.name}')}`
                                    })));
                                }
                                else {
                                    setDataSource(prevDataSource => prevDataSource.map(item => ({
                                        ...item,
                                        value: ''
                                    })));
                                }
                            }, advanced: true, defaultValue: fetchMethod })),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("br", null),
                    data.fetchMethod === "envFile" && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { label: "Environment Variables File (.env)", tooltip: "If the environment file is the selected method, specify the file from which to extract the connection information. The file is a dot env (.env) file which consists of VARIABLE='value', one per line. You can use the helper to copy-paste the list of variable names below next to the Name column title." },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.InputFile, { field: {
                                type: "input", id: "environmentVariableFile", placeholder: "config.env", label: ""
                            }, handleChange: handleChange, context: context, advanced: true, value: envVarFile, manager: manager }))),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("br", null),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { label: "Variables" },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Table, { components: components, rowClassName: () => 'editable-row', bordered: true, dataSource: dataSource, columns: columns })))))));
};



/***/ }),

/***/ "./lib/components/settings/EnvFile.js":
/*!********************************************!*\
  !*** ./lib/components/settings/EnvFile.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EnvFile: () => (/* binding */ EnvFile)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @amphi/pipeline-components-manager */ "webpack/sharing/consume/default/@amphi/pipeline-components-manager");
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactflow */ "webpack/sharing/consume/default/reactflow/reactflow");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(reactflow__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);
var _a;





class EnvFile extends (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__.PipelineComponent)() {
    constructor() {
        super(...arguments);
        this._name = "Env. Variables File";
        this._id = "envFile";
        this._type = "env_variables";
        this._category = "configuration";
        this._description = "Use Env. Variables to define environment variable names for use in the pipeline. You can also assign a value directly and set a default value. It is not recommended for credentials or sensitive data unless you fully understand the implications.";
        this._icon = _icons__WEBPACK_IMPORTED_MODULE_4__.bracesIcon;
        this._default = {};
        this._form = {};
    }
    UIComponent({ id, data, context, componentService, manager, commands, rendermimeRegistry, settings }) {
        const { setNodes, deleteElements, setViewport } = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useReactFlow)();
        const store = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useStoreApi)();
        const deleteNode = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
            deleteElements({ nodes: [{ id }] });
        }, [id, deleteElements]);
        const zoomSelector = (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__.createZoomSelector)();
        const showContent = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useStore)(zoomSelector);
        const selector = (s) => ({
            nodeInternals: s.nodeInternals,
            edges: s.edges,
        });
        const { nodeInternals, edges } = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useStore)(selector);
        const nodeId = id;
        const internals = { nodeInternals, edges, nodeId, componentService };
        // Create the handle element
        const handleElement = react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__.renderHandle, {
            type: EnvFile.Type,
            Handle: reactflow__WEBPACK_IMPORTED_MODULE_2__.Handle,
            Position: reactflow__WEBPACK_IMPORTED_MODULE_2__.Position,
            internals: internals
        });
        const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((evtTargetValue, field) => {
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__.onChange)({ evtTargetValue, field, nodeId, store, setNodes });
        }, [nodeId, store, setNodes]);
        // Selector to determine if the node is selected
        const isSelected = (0,reactflow__WEBPACK_IMPORTED_MODULE_2__.useStore)((state) => { var _b; return !!((_b = state.nodeInternals.get(id)) === null || _b === void 0 ? void 0 : _b.selected); });
        const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__.renderComponentUI)({
                id: id,
                data: data,
                context: context,
                manager: manager,
                commands: commands,
                name: EnvFile.Name,
                ConfigForm: EnvFile.ConfigForm,
                configFormProps: {
                    nodeId: id,
                    data,
                    context,
                    componentService,
                    manager,
                    commands,
                    store,
                    setNodes,
                    handleChange,
                    modalOpen,
                    setModalOpen
                },
                Icon: EnvFile.Icon,
                showContent: showContent,
                handle: handleElement,
                deleteNode: deleteNode,
                setViewport: setViewport,
                handleChange,
                isSelected
            }),
            showContent && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(reactflow__WEBPACK_IMPORTED_MODULE_2__.NodeToolbar, { isVisible: true, position: reactflow__WEBPACK_IMPORTED_MODULE_2__.Position.Bottom },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: () => setModalOpen(true) },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_4__.settingsIcon.react, null))))));
    }
    provideImports({ config }) {
        return ["from dotenv import load_dotenv"];
    }
    provideDependencies({ config }) {
        let deps = [];
        deps.push('python-dotenv');
        return deps;
    }
    generateComponentCode({ config }) {
        let code = `
# Load environment variables from ${config.envVarFile}
load_dotenv(dotenv_path="${config.envVarFile}")
`;
        code += "\n";
        return code;
    }
}
_a = EnvFile;
EnvFile.ConfigForm = ({ nodeId, data, context, componentService, manager, commands, store, setNodes, handleChange, modalOpen, setModalOpen }) => {
    // Define your default config
    const EditableContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(null);
    const EditableRow = ({ index, ...props }) => {
        const [form] = antd__WEBPACK_IMPORTED_MODULE_3__.Form.useForm();
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Form, { form: form, component: false },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(EditableContext.Provider, { value: form },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { ...props }))));
    };
    const EditableCell = ({ title, editable, children, dataIndex, record, handleSave, required, ...restProps }) => {
        const [editing, setEditing] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
        const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
        const form = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(EditableContext);
        (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
            var _b;
            if (editing) {
                (_b = inputRef.current) === null || _b === void 0 ? void 0 : _b.focus();
            }
        }, [editing]);
        const toggleEdit = () => {
            setEditing(!editing);
            form.setFieldsValue({ [dataIndex]: record[dataIndex] });
        };
        const save = async () => {
            try {
                const values = await form.validateFields();
                toggleEdit();
                handleSave({ ...record, ...values });
            }
            catch (errInfo) {
                console.error('Save failed:', errInfo);
            }
        };
        let childNode = children;
        if (editable) {
            childNode = editing ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, { style: { margin: 0 }, name: dataIndex, rules: required ? [
                    {
                        required: true,
                        message: `${title} is required.`,
                    },
                ] : [] },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Input, { ref: inputRef, onPressEnter: save, onBlur: save, onKeyDown: (e) => e.stopPropagation(), autoComplete: "off" }))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "editable-cell-value-wrap", style: { paddingRight: 24, minHeight: '20px', width: '100%', display: 'inline-block' }, onClick: () => toggleEdit() }, children));
        }
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...restProps },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onDoubleClick: (e) => e.stopPropagation() }, childNode)));
    };
    const [dataSource, setDataSource] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.variables || []);
    const [envVarFile, setEnvVarFile] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.envVarFile || "");
    const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        handleChange(dataSource, "variables");
    }, [dataSource]);
    const [count, setCount] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(dataSource.length || 0);
    const handleDelete = (key) => {
        const newData = dataSource.filter((item) => item.key !== key);
        setDataSource(newData);
    };
    const defaultColumns = [
        {
            title: 'Name',
            dataIndex: 'name',
            width: '50%',
            editable: false,
            required: true
        },
        {
            title: 'Default',
            dataIndex: 'default',
            width: '50%',
            editable: true,
            required: false
        },
    ];
    const retrieveEnvVariablesFromFile = () => {
        setLoadings(true);
        // Define the request to retrieve environment variables
        const code = `
    !pip install --quiet python-dotenv --disable-pip-version-check
    from dotenv import dotenv_values
    
    env_vars = dotenv_values("${data.envVarFile || 'config.env'}")
    formatted_output = ", ".join([f"{k} ({v})" for k, v in env_vars.items()])
    print(formatted_output)
    `;
        const future = context.sessionContext.session.kernel.requestExecute({ code: code });
        future.onReply = reply => {
            if (reply.content.status == "ok") {
                console.log("OK");
            }
            else {
                console.log("Error or abort");
                setLoadings(false);
            }
        };
        future.onIOPub = msg => {
            if (msg.header.msg_type === 'stream') {
                const streamMsg = msg;
                const output = streamMsg.content.text;
                const regex = /([^\s,]+)\s+\(((?:[^()]+|\([^)]*\))*)\)/g;
                const newItems = [];
                let match;
                while ((match = regex.exec(output)) !== null) {
                    const [_, name, value] = match;
                    newItems.push({
                        key: name,
                        name: name,
                        value: value
                    });
                }
                setDataSource((items) => {
                    const existingKeys = new Set(newItems.map((item) => item.key));
                    const filteredItems = items.filter((item) => existingKeys.has(item.key));
                    const uniqueItems = newItems.filter((newItem) => !filteredItems.some((item) => item.key === newItem.key));
                    return [...filteredItems, ...uniqueItems];
                });
                setLoadings(false);
            }
            else if (msg.header.msg_type === 'error') {
                setLoadings(false);
                const errorMsg = msg;
                const errorOutput = errorMsg.content;
                console.error(`Received error: ${errorOutput.ename}: ${errorOutput.evalue}`);
            }
        };
    };
    const handleSave = (row) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, {
            ...item,
            ...row,
        });
        setDataSource(newData);
    };
    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };
    const columns = defaultColumns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                required: col.required,
                handleSave,
            }),
        };
    });
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.ConfigProvider, { theme: {
                token: {
                    // Seed Token
                    colorPrimary: '#5F9B97',
                },
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Form, { layout: "vertical", size: "small" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, { label: "File (.env)" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__.InputFile, { field: {
                            type: "input", id: "environmentVariableFile", placeholder: "config.env", label: ""
                        }, handleChange: (value) => {
                            handleChange(value, 'envVarFile');
                            setEnvVarFile(value);
                        }, context: context, advanced: false, value: envVarFile, manager: manager })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Modal, { title: "Env. Variables File (.env)", centered: true, open: modalOpen, onOk: () => setModalOpen(false), onCancel: () => setModalOpen(false), width: 800, footer: (_, { OkBtn }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(OkBtn, null))) },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Form, { layout: "vertical" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, { label: "Environment Variables File (.env)", tooltip: "Specify the file from which to extract the connection information. The file is a dot env (.env) file which consists of VARIABLE='value', one per line. You can use the helper to copy-paste the list of variable names below next to the Name column title." },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_1__.InputFile, { field: {
                                        type: "input", id: "environmentVariableFile", placeholder: "config.env", label: ""
                                    }, handleChange: (value) => {
                                        handleChange(value, 'envVarFile');
                                        setEnvVarFile(value);
                                    }, context: context, advanced: true, value: envVarFile, manager: manager })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Button, { onClick: retrieveEnvVariablesFromFile, type: "primary", loading: loadings, style: { marginBottom: 16 } }, "Retrieve Environment Variables from .env file"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__.Table, { components: components, rowClassName: () => 'editable-row', bordered: true, dataSource: dataSource, columns: columns }))))))));
};



/***/ }),

/***/ "./lib/components/settings/EnvVariables.js":
/*!*************************************************!*\
  !*** ./lib/components/settings/EnvVariables.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EnvVariables: () => (/* binding */ EnvVariables)
/* harmony export */ });
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @amphi/pipeline-components-manager */ "webpack/sharing/consume/default/@amphi/pipeline-components-manager");
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/DeleteOutlined.js");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactflow */ "webpack/sharing/consume/default/reactflow/reactflow");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(reactflow__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
var _a;






class EnvVariables extends (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.PipelineComponent)() {
    constructor() {
        super(...arguments);
        this._name = "Env. Variables";
        this._id = "envVariables";
        this._type = "env_variables";
        this._category = "configuration";
        this._description = "Use Env. Variables File to retrieve environment variables from configuration files. This is the recommended approach for handling credentials or sensitive data that should not be exposed in plain text within the pipeline.";
        this._icon = _icons__WEBPACK_IMPORTED_MODULE_4__.bracesIcon;
        this._default = {};
        this._form = {};
    }
    UIComponent({ id, data, context, componentService, manager, commands, rendermimeRegistry, settings }) {
        const { setNodes, deleteElements, setViewport } = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useReactFlow)();
        const store = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStoreApi)();
        const deleteNode = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
            deleteElements({ nodes: [{ id }] });
        }, [id, deleteElements]);
        const zoomSelector = (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.createZoomSelector)();
        const showContent = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)(zoomSelector);
        const selector = (s) => ({
            nodeInternals: s.nodeInternals,
            edges: s.edges,
        });
        const { nodeInternals, edges } = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)(selector);
        const nodeId = id;
        const internals = { nodeInternals, edges, nodeId, componentService };
        // Create the handle element
        const handleElement = react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.renderHandle, {
            type: EnvVariables.Type,
            Handle: reactflow__WEBPACK_IMPORTED_MODULE_3__.Handle,
            Position: reactflow__WEBPACK_IMPORTED_MODULE_3__.Position,
            internals: internals
        });
        const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((evtTargetValue, field) => {
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.onChange)({ evtTargetValue, field, nodeId, store, setNodes });
        }, [nodeId, store, setNodes]);
        // Selector to determine if the node is selected
        const isSelected = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)((state) => { var _b; return !!((_b = state.nodeInternals.get(id)) === null || _b === void 0 ? void 0 : _b.selected); });
        const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.renderComponentUI)({
                id: id,
                data: data,
                context: context,
                manager: manager,
                commands: commands,
                name: EnvVariables.Name,
                ConfigForm: EnvVariables.ConfigForm,
                configFormProps: {
                    nodeId: id,
                    data,
                    context,
                    componentService,
                    manager,
                    commands,
                    store,
                    setNodes,
                    handleChange,
                    modalOpen,
                    setModalOpen
                },
                Icon: EnvVariables.Icon,
                showContent: showContent,
                handle: handleElement,
                deleteNode: deleteNode,
                setViewport: setViewport,
                handleChange,
                isSelected
            }),
            showContent && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(reactflow__WEBPACK_IMPORTED_MODULE_3__.NodeToolbar, { isVisible: true, position: reactflow__WEBPACK_IMPORTED_MODULE_3__.Position.Bottom },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { onClick: () => setModalOpen(true) },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_4__.settingsIcon.react, null))))));
    }
    provideImports({ config }) {
        return ["import os"];
    }
    generateComponentCode({ config }) {
        let code = ``;
        config.variables.forEach(variable => {
            // Initialize all environment variables to an empty string or the default value if provided
            if (variable.value) {
                code += `os.environ["${variable.name}"] = "${variable.value}"\n`;
            }
        });
        code += "\n";
        return code;
    }
}
_a = EnvVariables;
EnvVariables.ConfigForm = ({ nodeId, data, context, componentService, manager, commands, store, setNodes, handleChange, modalOpen, setModalOpen }) => {
    // Define your default config
    const EditableContext = react__WEBPACK_IMPORTED_MODULE_1___default().createContext(null);
    const EditableRow = ({ index, ...props }) => {
        const [form] = antd__WEBPACK_IMPORTED_MODULE_2__.Form.useForm();
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form, { form: form, component: false },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(EditableContext.Provider, { value: form },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tr", { ...props }))));
    };
    const EditableCell = ({ title, editable, children, dataIndex, record, handleSave, required, ...restProps }) => {
        const [editing, setEditing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
        const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
        const form = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(EditableContext);
        (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
            var _b;
            if (editing) {
                (_b = inputRef.current) === null || _b === void 0 ? void 0 : _b.focus();
            }
        }, [editing]);
        const toggleEdit = () => {
            setEditing(!editing);
            form.setFieldsValue({ [dataIndex]: record[dataIndex] });
        };
        const save = async () => {
            try {
                const values = await form.validateFields();
                toggleEdit();
                handleSave({ ...record, ...values });
            }
            catch (errInfo) {
                console.error('Save failed:', errInfo);
            }
        };
        let childNode = children;
        if (editable) {
            childNode = editing ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, { style: { margin: 0 }, name: dataIndex, rules: required ? [
                    {
                        required: true,
                        message: `${title} is required.`,
                    },
                ] : [] },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Input, { ref: inputRef, onPressEnter: save, onBlur: save, onKeyDown: (e) => e.stopPropagation(), autoComplete: "off" }))) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "editable-cell-value-wrap", style: { paddingRight: 24, minHeight: '20px', width: '100%', display: 'inline-block' }, onClick: () => toggleEdit() }, children));
        }
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", { ...restProps },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { onDoubleClick: (e) => e.stopPropagation() }, childNode)));
    };
    const [dataSource, setDataSource] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data.variables || []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        handleChange(dataSource, "variables");
    }, [dataSource]);
    const [count, setCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dataSource.length || 0);
    const handleDelete = (key) => {
        const newData = dataSource.filter((item) => item.key !== key);
        setDataSource(newData);
    };
    const defaultColumns = [
        {
            title: 'Name',
            dataIndex: 'name',
            width: '30%',
            editable: true,
            required: true
        },
        {
            title: 'Value',
            dataIndex: 'value',
            width: '40%',
            editable: true,
            required: false
        },
        {
            title: 'Default',
            dataIndex: 'default',
            width: '30%',
            editable: true,
            required: false
        },
        {
            title: '',
            dataIndex: 'operation',
            render: (_, record) => dataSource.length >= 1 ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Popconfirm, { title: "Sure to delete?", onConfirm: () => handleDelete(record.key) },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["default"], null))) : null,
        }
    ];
    const handleAdd = () => {
        const newData = {
            key: count,
            name: `ENV_${count}`,
            value: '',
            default: ``,
        };
        setDataSource([...dataSource, newData]);
        setCount(count + 1);
    };
    const handleSave = (row) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, {
            ...item,
            ...row,
        });
        setDataSource(newData);
    };
    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };
    const columns = defaultColumns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                required: col.required,
                handleSave,
            }),
        };
    });
    const { Paragraph, Text } = antd__WEBPACK_IMPORTED_MODULE_2__.Typography;
    const info = (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(Text, null, "Use Env. Variables in components by clicking on the braces icon in inputs fields.")));
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.ConfigProvider, { theme: {
                token: {
                    // Seed Token
                    colorPrimary: '#5F9B97',
                },
            } },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form, { layout: "vertical", size: "small" },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "flex justify-center mt-1 pt-1.5 space-x-4" },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Space, { direction: "vertical", size: "middle" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Space.Compact, null,
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(Paragraph, { style: { padding: '5px' } }, info)))),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Modal, { title: _a.Name, centered: true, open: modalOpen, onOk: () => setModalOpen(false), onCancel: () => setModalOpen(false), width: 800, footer: (_, { OkBtn }) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(OkBtn, null))) },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form, { layout: "vertical" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(Paragraph, { style: { padding: '5px' } }, info),
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Button, { onClick: handleAdd, type: "primary", style: { marginBottom: 16 } }, "Add environment variable"),
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Table, { components: components, rowClassName: () => 'editable-row', bordered: true, dataSource: dataSource, columns: columns }))))))));
};



/***/ }),

/***/ "./lib/components/transforms/Aggregate.js":
/*!************************************************!*\
  !*** ./lib/components/transforms/Aggregate.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Aggregate: () => (/* binding */ Aggregate)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Aggregate extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {};
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "columns",
                    label: "Group by",
                    id: "groupByColumns",
                    placeholder: "Select columns"
                },
                {
                    type: "keyvalueColumnsSelect",
                    label: "Operations",
                    id: "columnsOperations",
                    placeholder: "Select column",
                    options: [
                        { value: "min", label: "Min", tooltip: "Returns the minimum value in the group." },
                        { value: "max", label: "Max", tooltip: "Returns the maximum value in the group." },
                        { value: "sum", label: "Sum", tooltip: "Returns the sum of all values in the group." },
                        { value: "mean", label: "Mean", tooltip: "Returns the average value of the group." },
                        { value: "count", label: "Count", tooltip: "Counts the number of non-null entries." },
                        { value: "nunique", label: "Distinct Count", tooltip: "Returns the number of distinct elements." },
                        { value: "first", label: "First", tooltip: "Returns the first value in the group." },
                        { value: "last", label: "Last", tooltip: "Returns the last value in the group." },
                        { value: "median", label: "Median", tooltip: "Returns the median value in the group." },
                        { value: "std", label: "Standard Deviation", tooltip: "Returns the standard deviation of the group." },
                        { value: "var", label: "Variance", tooltip: "Returns the variance of the group." },
                        { value: "prod", label: "Product", tooltip: "Returns the product of all values in the group." }
                    ],
                }
            ],
        };
        const description = "Use Aggregate to perform various summary calculations such as sum, count, min/max, average, mean/median, count and more.";
        super("Aggregate Rows", "aggregate", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.aggregateIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return [];
    }
    generateComponentCode({ config, inputName, outputName }) {
        const groupColumns = config.groupByColumns.map(col => col.value);
        // Start constructing the aggregation arguments dynamically
        let aggArgs = "";
        if (config.columnsOperations && config.columnsOperations.length > 0) {
            config.columnsOperations.forEach((op, index) => {
                // Determine how to reference the column based on 'named'
                const columnReference = op.key.named ? `'${op.key.value}'` : op.key.value;
                const operation = op.value.value;
                const columnName = op.key.named ? op.key.value : `col${op.key.value}`;
                const operationName = `${columnName}_${operation}`;
                const sanitizeColumnName = (name) => name.replace(/[^a-zA-Z0-9_]/g, '_');
                const operationNameReference = sanitizeColumnName(operationName);
                // Construct each aggregation argument
                aggArgs += `${operationNameReference}=(${columnReference}, '${operation}')`;
                if (index < config.columnsOperations.length - 1) {
                    aggArgs += ", ";
                }
            });
        }
        // Generate groupby code
        let code = `
${outputName} = ${inputName}.groupby([`;
        // Add group columns
        groupColumns.forEach((col, index) => {
            code += `"${col}"`;
            if (index < groupColumns.length - 1) { // Avoid trailing comma
                code += ",";
            }
        });
        // Complete the aggregation function call
        code += `]).agg(${aggArgs}).reset_index()\n`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/DataCleansing.js":
/*!****************************************************!*\
  !*** ./lib/components/transforms/DataCleansing.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DataCleansing: () => (/* binding */ DataCleansing)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");
 // Define this icon in your icons file

class DataCleansing extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { method: "value", value: 0, forward: false, backward: false };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "boolean",
                    label: "Drop rows with NULL values",
                    id: "removeNullRows",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Drop rows if",
                    id: "removeRowsHow",
                    options: [
                        { value: "all", label: "All values are NULL" },
                        { value: "any", label: "Any values are NULL (at least one)" }
                    ],
                    condition: { removeNullRows: true },
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Drop columns with NULL values",
                    id: "removeNullColumns",
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Drop rows if",
                    id: "removeColumnsHow",
                    options: [
                        { value: "all", label: "All values are NULL" },
                        { value: "any", label: "Any values are NULL (at least one)" }
                    ],
                    condition: { removeNullColumns: true },
                    advanced: true
                },
                {
                    type: "columns",
                    label: "Apply cleansing to columns",
                    id: "columns",
                    tooltip: "Select the columns to apply the cleansing rules. If left blank, all columns will be selected by default.",
                    placeholder: "Default: All columns",
                    advanced: true
                },
                {
                    type: "select",
                    label: "Replace missing values with",
                    id: "replaceMethod",
                    options: [
                        { value: "blanks", label: "Replace with blanks (for string fields)" },
                        { value: "0", label: "Replace with 0 (for numeric fields)" },
                        { value: "custom", label: "Replace with custom value" },
                        { value: "median", label: "Fill with median (for numeric fields)" },
                        { value: "ffill", label: "Forward fill" },
                        { value: "bfill", label: "Backward fill" },
                    ],
                },
                {
                    type: "input",
                    label: "Value",
                    id: "value",
                    condition: { replaceMethod: "custom" },
                    placeholder: "Enter value"
                },
                {
                    type: "selectMultipleCustomizable",
                    label: "Remove Unwanted Characters",
                    id: "removeUnwantedCharacters",
                    options: [
                        { value: "whitespace", label: "Leading and Trailing Whitespace" },
                        { value: "tabs", label: "Tabs" },
                        { value: "Line breaks", label: "Line Breaks" },
                        { value: "allwhitespace", label: "All Whitespace" },
                        { value: "letters", label: "All Letters" },
                        { value: "numbers", label: "All Numbers" },
                        { value: "punctuation", label: "Punctuation" }
                    ],
                },
                {
                    type: "select",
                    label: "Modify Case",
                    id: "case",
                    options: [
                        { value: "lower", label: "Lower Case", tooltip: "Convert all characters to lowercase." },
                        { value: "upper", label: "Upper Case", tooltip: "Convert all characters to uppercase." },
                        { value: "capitalize", label: "Capitalize", tooltip: "Capitalize the first letter of the string and lowercase the rest." },
                        { value: "swapcase", label: "Swap Case", tooltip: "Swap uppercase characters to lowercase and vice versa." },
                        { value: "camelcase", label: "Camel Case", tooltip: "Convert to camel case, where the first letter is lowercase and subsequent words are capitalized without spaces." },
                        { value: "snakecase", label: "Snake Case", tooltip: "Replace spaces with underscores and convert all characters to lowercase." },
                    ]
                },
            ],
        };
        const description = "Use Data Cleansing to clean and preprocess your data. It provides options to handle missing values, drop null rows or columns, modify string cases, and remove unwanted characters. You can apply these transformations to specific columns or the entire dataset.";
        super("Data Cleansing", "cleanDataCLeansing", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.checkDiamondIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        const imports = [];
        // Import 're' only if unwanted characters are specified
        if (config.removeUnwantedCharacters && config.removeUnwantedCharacters.length > 0) {
            imports.push("import re");
        }
        return imports;
    }
    generateComponentCode({ config, inputName, outputName }) {
        const code = [];
        const columns = config.columns;
        function getColumnReference(column) {
            return column.named ? `'${column.value}'` : `${column.value}`;
        }
        // Determine if specific columns are provided
        const columnsArray = columns && columns.length > 0 ? columns.map(getColumnReference) : null;
        const columnsList = columnsArray ? `[${columnsArray.join(', ')}]` : null;
        code.push(`${outputName} = ${inputName}.copy()`);
        // Handle missing value replacement
        if (config.replaceMethod) {
            let value;
            if (config.replaceMethod === 'blanks') {
                value = "''";
            }
            else if (config.replaceMethod === '0') {
                value = '0';
            }
            else if (config.replaceMethod === 'custom') {
                value = isNaN(Number(config.value)) ? `'${config.value}'` : config.value;
            }
            if (['blanks', '0', 'custom'].includes(config.replaceMethod)) {
                if (columnsList) {
                    code.push(`${outputName}[${columnsList}] = ${outputName}[${columnsList}].fillna(${value})`);
                }
                else {
                    code.push(`${outputName} = ${outputName}.fillna(${value})`);
                }
            }
            else if (config.replaceMethod === 'median') {
                if (columnsList) {
                    code.push(`${outputName}[${columnsList}] = ${outputName}[${columnsList}].fillna(${outputName}[${columnsList}].median())`);
                }
                else {
                    code.push(`${outputName} = ${outputName}.fillna(${outputName}.median())`);
                }
            }
            else if (['ffill', 'bfill'].includes(config.replaceMethod)) {
                if (columnsList) {
                    code.push(`${outputName}[${columnsList}] = ${outputName}[${columnsList}].fillna(method='${config.replaceMethod}')`);
                }
                else {
                    code.push(`${outputName} = ${outputName}.fillna(method='${config.replaceMethod}')`);
                }
            }
        }
        // Handle removal of unwanted characters and case modifications
        const unwantedCharacterMapping = {
            'whitespace': { '^\\s+|\\s+$': '' },
            'tabs': { '\\t': '' },
            'Line breaks': { '\\n': '', '\\r': '' },
            'allwhitespace': { '\\s+': '' },
            'letters': { '[A-Za-z]+': '' },
            'numbers': { '\\d+': '' },
            'punctuation': { '[^\\w\\s]+': '' }
        };
        const removeUnwantedChars = config.removeUnwantedCharacters || [];
        let replaceDict = {};
        removeUnwantedChars.forEach(char => {
            const mappings = unwantedCharacterMapping[char];
            if (mappings) {
                replaceDict = { ...replaceDict, ...mappings };
            }
        });
        const caseMapping = {
            'lower': '.lower()',
            'upper': '.upper()',
            'capitalize': '.capitalize()',
            'swapcase': '.swapcase()',
            'camelcase': ".title().replace(' ', '')",
            'snakecase': ".replace(' ', '_').lower()"
        };
        // Determine case transformation
        const caseOption = config.case;
        const caseTransform = caseOption ? caseMapping[caseOption] : null;
        if (Object.keys(replaceDict).length > 0 || caseTransform) {
            if (columnsList) {
                code.push(`${outputName}[${columnsList}] = ${outputName}[${columnsList}].astype(str)`);
            }
            else {
                code.push(`${outputName} = ${outputName}.astype(str)`);
            }
            if (Object.keys(replaceDict).length > 0) {
                const regexFlag = 'regex=True';
                const replaceStr = JSON.stringify(replaceDict).replace(/"/g, '\'');
                if (columnsList) {
                    code.push(`${outputName}[${columnsList}] = ${outputName}[${columnsList}].replace(${replaceStr}, ${regexFlag})`);
                }
                else {
                    code.push(`${outputName} = ${outputName}.replace(${replaceStr}, ${regexFlag})`);
                }
            }
            if (caseTransform) {
                if (columnsArray) {
                    if (columnsArray.length === 1) {
                        const col = columnsArray[0];
                        code.push(`${outputName}[${col}] = ${outputName}[${col}].str${caseTransform}`);
                    }
                    else {
                        code.push(`for col in ${columnsList}:`);
                        code.push(`    ${outputName}[col] = ${outputName}[col].str${caseTransform}`);
                    }
                }
                else {
                    code.push(`for col in ${outputName}.columns:`);
                    code.push(`    ${outputName}[col] = ${outputName}[col].str${caseTransform}`);
                }
            }
        }
        // Handle removal of null rows
        if (config.removeNullRows) {
            if (columnsList) {
                code.push(`${outputName} = ${outputName}.dropna(axis=0, how='${config.removeRowsHow}', subset=${columnsList})`);
            }
            else {
                code.push(`${outputName} = ${outputName}.dropna(axis=0, how='${config.removeRowsHow}')`);
            }
        }
        // Handle removal of null columns
        if (config.removeNullColumns) {
            if (columnsList) {
                code.push(`${outputName} = ${outputName}.dropna(axis=1, how='${config.removeColumnsHow}', subset=${columnsList})`);
            }
            else {
                code.push(`${outputName} = ${outputName}.dropna(axis=1, how='${config.removeColumnsHow}')`);
            }
        }
        return code.join('\n');
    }
}


/***/ }),

/***/ "./lib/components/transforms/DateTimeConverter.js":
/*!********************************************************!*\
  !*** ./lib/components/transforms/DateTimeConverter.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DateTimeConverter: () => (/* binding */ DateTimeConverter)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class DateTimeConverter extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { conversionType: "stringToDate", language: "en_US.UTF-8", dateTimeFormat: "%d-%m-%Y" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "Conversion Type",
                    id: "conversionType",
                    options: [
                        { value: "dateToString", label: "Date/Time to string" },
                        { value: "stringToDate", label: "String to Date/Time" }
                    ]
                },
                {
                    type: "column",
                    label: "Select column",
                    id: "dateTimeField",
                    placeholder: "Select column(s)"
                },
                {
                    type: "selectCustomizable",
                    label: "DateTime Language",
                    id: "language",
                    tooltip: "Select language or provide custom locale for your system, POSIX-style locale identifier (Linux/Mac) or Windows locale names (Windows)",
                    options: [
                        { value: "en_US.UTF-8", label: "English (US)" },
                        { value: "en_GB.UTF-8", label: "English (UK)" },
                        { value: "fr_FR.UTF-8", label: "French (France)" },
                        { value: "de_DE.UTF-8", label: "German (Germany)" },
                        { value: "es_ES.UTF-8", label: "Spanish (Spain)" },
                        { value: "it_IT.UTF-8", label: "Italian (Italy)" },
                        { value: "pt_PT.UTF-8", label: "Portuguese (Portugal)" },
                        { value: "pt_BR.UTF-8", label: "Portuguese (Brazil)" },
                        { value: "ja_JP.UTF-8", label: "Japanese" },
                        { value: "ko_KR.UTF-8", label: "Korean" },
                        { value: "zh_CN.UTF-8", label: "Chinese (Simplified, China)" },
                        { value: "zh_TW.UTF-8", label: "Chinese (Traditional, Taiwan)" },
                        { value: "nl_NL.UTF-8", label: "Dutch (Netherlands)" },
                        { value: "ru_RU.UTF-8", label: "Russian" },
                        { value: "sv_SE.UTF-8", label: "Swedish (Sweden)" },
                        { value: "da_DK.UTF-8", label: "Danish (Denmark)" },
                        { value: "fi_FI.UTF-8", label: "Finnish (Finland)" },
                        { value: "nb_NO.UTF-8", label: "Norwegian (Norway)" },
                        { value: "pl_PL.UTF-8", label: "Polish (Poland)" },
                        { value: "tr_TR.UTF-8", label: "Turkish (Turkey)" },
                        { value: "cs_CZ.UTF-8", label: "Czech (Czech Republic)" },
                        { value: "hu_HU.UTF-8", label: "Hungarian (Hungary)" },
                        { value: "el_GR.UTF-8", label: "Greek (Greece)" }
                    ],
                    advanced: true
                },
                {
                    type: "selectCustomizable",
                    label: "Select the format",
                    id: "dateTimeFormat",
                    tooltip: "Select pre-defined format or provide a custom strftime format used for the conversion (in both order)",
                    options: [
                        { value: "%A, %B %d, %Y", label: "day, dd Month, yyyy" },
                        { value: "%d-%m-%Y", label: "dd-MM-yyyy" },
                        { value: "%d/%m/%Y", label: "dd/MM/yyyy" },
                        { value: "%Y-%m-%d", label: "yyyy-MM-dd" },
                        { value: "%Y/%m/%d", label: "yyyy/MM/dd" },
                        { value: "%B %d, %Y", label: "Month dd, yyyy" },
                        { value: "%m/%d/%Y", label: "MM/dd/yyyy" },
                        { value: "%m-%d-%Y", label: "MM-dd-yyyy" },
                        { value: "%d %b %Y", label: "dd Mon yyyy" },
                        { value: "%d %B %Y", label: "dd Month yyyy" },
                        { value: "%d.%m.%Y", label: "dd.MM.yyyy" },
                        { value: "%Y.%m.%d", label: "yyyy.MM.dd" },
                        { value: "%b %d, %Y", label: "Mon dd, yyyy" },
                        { value: "%a, %d %b %Y", label: "day, dd Mon yyyy" },
                        { value: "%A, %d %B %Y", label: "day, dd Month yyyy" },
                        { value: "%Y-%m-%d %H:%M:%S", label: "yyyy-MM-dd HH:mm:ss" },
                        { value: "%d/%m/%Y %H:%M", label: "dd/MM/yyyy HH:mm" },
                        { value: "%B %d, %Y %H:%M", label: "Month dd, yyyy HH:mm" } // September 19, 2024 14:30
                    ]
                },
                {
                    type: "boolean",
                    label: "New Column",
                    id: "newColumn",
                    advanced: true
                },
                {
                    type: "input",
                    label: "New column name",
                    id: "newColumnName",
                    placeholder: "Type new column name",
                    condition: { newColumn: true },
                    advanced: true
                }
            ],
        };
        const description = "Use DateTime to convert between date/time formats and strings, allowing for custom formatting and language options.";
        super("DateTime Converter", "datetimeConverter", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.calendarIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["from datetime import datetime", "import locale"];
    }
    generateComponentCode({ config, inputName, outputName }) {
        var _a, _b;
        const prefix = (_b = (_a = config === null || config === void 0 ? void 0 : config.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
        const { conversionType, dateTimeField, language, dateTimeFormat, newColumn } = config;
        // Extract column details
        const columnName = dateTimeField.value;
        const columnType = dateTimeField.type;
        const columnIsNamed = dateTimeField.named;
        const inputColumnReference = columnIsNamed ? `'${columnName}'` : columnName;
        // Determine the output column reference
        let outputColumnReference = inputColumnReference;
        if (newColumn) {
            const newColumnName = config.newColumnName && config.newColumnName.trim() ? config.newColumnName : `${columnName}_converted`;
            outputColumnReference = `'${newColumnName}'`;
        }
        // The locale depends on the OS
        // Use user agent for best guess, otherwise fall back to Linux/Mac
        const isWindows = navigator.userAgent.includes('Windows');
        // Equivalence table between Linux/macOS and Windows locales
        const localeMap = {
            'en_US.UTF-8': 'English_United States',
            'en_GB.UTF-8': 'English_United Kingdom',
            'fr_FR.UTF-8': 'French_France',
            'de_DE.UTF-8': 'German_Germany',
            'es_ES.UTF-8': 'Spanish_Spain',
            'it_IT.UTF-8': 'Italian_Italy',
            'pt_PT.UTF-8': 'Portuguese_Portugal',
            'pt_BR.UTF-8': 'Portuguese_Brazil',
            'ja_JP.UTF-8': 'Japanese_Japan',
            'ko_KR.UTF-8': 'Korean_Korea',
            'zh_CN.UTF-8': 'Chinese_People\'s Republic of China',
            'zh_TW.UTF-8': 'Chinese_Taiwan',
            'nl_NL.UTF-8': 'Dutch_Netherlands',
            'ru_RU.UTF-8': 'Russian_Russia',
            'sv_SE.UTF-8': 'Swedish_Sweden',
            'da_DK.UTF-8': 'Danish_Denmark',
            'fi_FI.UTF-8': 'Finnish_Finland',
            'nb_NO.UTF-8': 'Norwegian_Norway',
            'pl_PL.UTF-8': 'Polish_Poland',
            'tr_TR.UTF-8': 'Turkish_Turkey',
            'cs_CZ.UTF-8': 'Czech_Czech Republic',
            'hu_HU.UTF-8': 'Hungarian_Hungary',
            'el_GR.UTF-8': 'Greek_Greece'
        };
        let code = '';
        // Only set locale if language is specified
        if (language) {
            let locale = language;
            // If Windows is detected, map the Linux locale to the equivalent Windows locale
            if (isWindows && localeMap[language]) {
                locale = localeMap[language];
            }
            code += `
# Set the locale for date parsing/formatting
locale.setlocale(locale.LC_TIME, '${locale}')
        `;
        }
        code += `
${outputName} = ${inputName}.copy()
`;
        if (conversionType === 'dateToString') {
            code += `
# Convert date/time column to string with specified format
${outputName}[${outputColumnReference}] = ${outputName}[${inputColumnReference}].dt.strftime('${dateTimeFormat}').astype('string')
`;
        }
        else if (conversionType === 'stringToDate') {
            code += `
# Convert string column to datetime with specified format
${outputName}[${outputColumnReference}] = ${prefix}.to_datetime(${outputName}[${inputColumnReference}], format='${dateTimeFormat}')
`;
        }
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Deduplicate.js":
/*!**************************************************!*\
  !*** ./lib/components/transforms/Deduplicate.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Deduplicate: () => (/* binding */ Deduplicate)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Deduplicate extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { keep: "first" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "select",
                    label: "Keep (survivorship)",
                    id: "keep",
                    options: [
                        { value: "first", label: "First occurrence", tooltip: "Drop duplicates except for the first occurrence" },
                        { value: "last", label: "Last occurrence", tooltip: "Drop duplicates except for the last occurrence" },
                        { value: "False", label: "Drop all", tooltip: "Drop all duplicates" }
                    ],
                },
                {
                    type: "columns",
                    label: "Columns",
                    id: "subset",
                    placeholder: "All columns",
                    tooltip: "Columns considered for identifying duplicates. Leave empty to consider all columns."
                }
            ],
        };
        const description = "Use Deduplicate to remove duplicate rows based on values on one or more columns.";
        super("Deduplicate Rows", "deduplicateData", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.dedupIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return [];
    }
    generateComponentCode({ config, inputName, outputName }) {
        // Initializing code string
        let code = `
  # Deduplicate rows\n`;
        // Ensuring config.subset is defined and has a length property
        const subset = config.subset && Array.isArray(config.subset) ? config.subset : [];
        const columns = subset.length > 0 ? `subset=[${subset.map(column => column.named ? `"${column.value.trim()}"` : column.value).join(', ')}]` : '';
        // Adjusting keep parameter based on config.keep value
        let keep;
        if (typeof config.keep === 'boolean') {
            keep = config.keep ? `"first"` : "False";
        }
        else {
            keep = config.keep === "False" ? "False" : `"${config.keep}"`;
        }
        // Generating the code for deduplication
        code += `${outputName} = ${inputName}.drop_duplicates(${columns}${columns && keep ? `, keep=${keep}` : !columns && keep ? `keep=${keep}` : ''})\n`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Extract.js":
/*!**********************************************!*\
  !*** ./lib/components/transforms/Extract.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Extract: () => (/* binding */ Extract)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Extract extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {};
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "column",
                    label: "Column name",
                    id: "column",
                    placeholder: "Column name",
                },
                {
                    type: "selectCustomizable",
                    label: "Regular Expression",
                    id: "regex",
                    tooltip: "Select a type of data or add a custom regex",
                    placeholder: "Select type or type regex",
                    options: [
                        { value: "(\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b)", label: "Email" },
                        { value: "(https?://(?:www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b(?:[-a-zA-Z0-9@:%_\\+.~#?&//=]*))", label: "URL" },
                        { value: "(\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\b)", label: "IPv4 Address" },
                        { value: "(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4})", label: "IPv6 Address" },
                        { value: "(\\b\\d{4}[- ]?\\d{4}[- ]?\\d{4}[- ]?\\d{4}\\b)", label: "Credit Card" },
                        { value: "(\\b\\d{3}-\\d{2}-\\d{4}\\b)", label: "SSN" },
                        { value: "(\\b\\d{1,3}(\\.\\d{1,2})?%\\b)", label: "Percentage" },
                        { value: "(\"([^\"\\\\]*(\\\\.[^\"\\\\]*)*))", label: "JSON String" },
                        { value: "(\\b\\d{3}-\\d{10}\\b)", label: "ISBN" }
                    ]
                },
                {
                    type: "select",
                    label: "Flags",
                    id: "flags",
                    placeholder: "Type or select",
                    options: [
                        { value: "IGNORECASE", label: "Makes the match case-insensitive. For example, it will match both 'abc' and 'ABC'." },
                        { value: "MULTILINE", label: "Changes the behavior of ^ and $ to match the start and end of each line, not just the start and end of the whole string." },
                        { value: "DOTALL", label: "Makes the . match any character at all, including a newline; without this flag, . will match anything except a newline." },
                        { value: "UNICODE", label: "Makes \\w, \\W, \\b, \\B, \\d, \\D, \\s, and \\S sequences dependent on the Unicode character properties database. This is the default behavior in Python 3 for strings." },
                        { value: "ASCII", label: "Makes \\w, \\W, \\b, \\B, \\d, \\D, \\s, and \\S perform ASCII-only matching instead of full Unicode matching." },
                        { value: "VERBOSE", label: "Allows you to write regular expressions that are more readable by permitting whitespace and comments within the pattern string." }
                    ],
                    advanced: true
                }
            ],
        };
        const description = "Use Parse & Extract to parse data from columns based on a pattern (pre-defined RegEx or custom).";
        super("Parse & Extract", "extract", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.extractIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import re"];
    }
    generateComponentCode({ config, inputName, outputName }) {
        const columnName = config.column.value; // name of the column
        const columnType = config.column.type; // current type of the column (e.g., 'int', 'string')
        const columnNamed = config.column.named; // boolean, true if column is named, false if index is used
        const columnAccess = columnNamed ? `'${columnName}'` : `${columnName}`;
        const regex = config.regex;
        let flagsCode = '';
        // Check if flags are not empty before formatting
        if (config.falgs && config.flags.trim() !== '') {
            const flags = config.flags.split(',')
                .filter(flag => flag.trim() !== '')
                .map(flag => `re.${flag}`)
                .join(' | ');
            flagsCode = `, flags=${flags}`;
        }
        // Count the number of capturing groups in the regex
        const groupCount = (new RegExp(regex + '|')).exec('').length - 1;
        const columnNames = Array.from({ length: groupCount }, (_, i) => `"${outputName}_${i + 1}"`).join(', ');
        // Use outputName to create unique names for the extracted data
        const extractedVarName = `${outputName}_extracted`;
        // Generate the final code string
        const code = `
# Extract data using regex
${extractedVarName} = ${inputName}[${columnAccess}].str.extract(r"${regex}"${flagsCode})
${extractedVarName}.columns = [${columnNames}]
${outputName} = ${inputName}.join(${extractedVarName}, rsuffix="_extracted")
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Filter.js":
/*!*********************************************!*\
  !*** ./lib/components/transforms/Filter.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Filter: () => (/* binding */ Filter)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Filter extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { condition: "==" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "column",
                    label: "Column name",
                    id: "column",
                    placeholder: "Select column",
                },
                {
                    type: "select",
                    label: "Condition",
                    id: "condition",
                    placeholder: "Select condition",
                    options: [
                        { value: "==", label: "==" },
                        { value: "!=", label: "!=" },
                        { value: ">", label: ">" },
                        { value: "<", label: "<" },
                        { value: ">=", label: ">=" },
                        { value: "<=", label: "<=" },
                        { value: "notnull", label: "Not Null" },
                        { value: "isnull", label: "Is Null" },
                        { value: "notempty", label: "Not Empty" },
                        { value: "isempty", label: "Is Empty" },
                        { value: "contains", label: "Contains (string)" },
                        { value: "not contains", label: "Not contains (string)" },
                        { value: "startswith", label: "Starts With (string)" },
                        { value: "endswith", label: "Ends With (string)" }
                    ],
                },
                {
                    type: "input",
                    label: "Value",
                    id: "conditionValue",
                    placeholder: "Any string of characters (enforce numbers if needed)"
                },
                {
                    type: "boolean",
                    label: "Enforce value as string",
                    id: "enforceString",
                    advanced: true
                }
            ],
        };
        const description = "Use Filter Rows to select and output data that meets a specified condition.";
        super("Filter Rows", "filter", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.filterIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return [];
    }
    generateComponentCode({ config, inputName, outputName }) {
        const columnName = config.column.value;
        const columnType = config.column.type;
        const columnIsNamed = config.column.named;
        const condition = config.condition;
        const conditionValue = config.conditionValue;
        const enforceString = config.enforceString;
        let code = `
# Filter rows based on condition
`;
        let queryExpression;
        let conditionValueReference;
        let columnReference;
        switch (condition) {
            case "==":
            case "!=":
            case ">":
            case "<":
            case ">=":
            case "<=":
                columnReference = `'${columnName}'`;
                // If columnType is not a string or category, don't wrap into quotes
                if (enforceString) {
                    conditionValueReference = `'${conditionValue}'`;
                }
                else if (columnType === 'string' || columnType === 'category' || columnType === 'object') {
                    conditionValueReference = `'${conditionValue}'`;
                }
                else {
                    conditionValueReference = `${conditionValue}`;
                }
                // Use boolean indexing instead of query
                switch (condition) {
                    case "==":
                        code += `${outputName} = ${inputName}[${inputName}[${columnReference}] == ${conditionValueReference}]`;
                        break;
                    case "!=":
                        code += `${outputName} = ${inputName}[${inputName}[${columnReference}] != ${conditionValueReference}]`;
                        break;
                    case ">":
                        code += `${outputName} = ${inputName}[${inputName}[${columnReference}] > ${conditionValueReference}]`;
                        break;
                    case "<":
                        code += `${outputName} = ${inputName}[${inputName}[${columnReference}] < ${conditionValueReference}]`;
                        break;
                    case ">=":
                        code += `${outputName} = ${inputName}[${inputName}[${columnReference}] >= ${conditionValueReference}]`;
                        break;
                    case "<=":
                        code += `${outputName} = ${inputName}[${inputName}[${columnReference}] <= ${conditionValueReference}]`;
                        break;
                }
                break;
            case "contains":
            case "not contains":
                columnReference = columnIsNamed ? `'${columnName}'` : columnName;
                if (['string', 'Object', 'category'].includes(columnType)) {
                    const negation = condition === "not contains" ? "~" : "";
                    queryExpression = `${inputName}[${negation}${inputName}[${columnReference}].str.contains("${conditionValue}", na=False)]`;
                    code += `${outputName} = ${queryExpression}`;
                }
                else {
                    throw new Error('Invalid operation for the data type');
                }
                break;
            case "startswith":
            case "endswith":
                columnReference = columnIsNamed ? `'${columnName}'` : columnName;
                if (['string', 'Object', 'category'].includes(columnType)) {
                    queryExpression = `${inputName}[${inputName}[${columnReference}].str.${condition}("${conditionValue}", na=False)]`;
                    code += `${outputName} = ${queryExpression}`;
                }
                else {
                    throw new Error('Invalid operation for the data type');
                }
                break;
            case "notnull":
                columnReference = columnIsNamed ? `'${columnName}'` : columnName;
                queryExpression = `${inputName}.dropna(subset=[${columnReference}])`;
                code += `${outputName} = ${queryExpression}`;
                break;
            case "isnull":
                columnReference = columnIsNamed ? `'${columnName}'` : columnName;
                queryExpression = `${inputName}[${inputName}[${columnReference}].isna()]`;
                code += `${outputName} = ${queryExpression}`;
                break;
            default:
                columnReference = /[^a-zA-Z0-9_]/.test(columnName) ? `\`${columnName}\`` : columnName;
                queryExpression = `${columnReference} ${condition} '${conditionValue}'`;
                code += `${outputName} = ${inputName}.query("${queryExpression}")`;
                break;
        }
        return code + '\n';
    }
}


/***/ }),

/***/ "./lib/components/transforms/FilterColumns.js":
/*!****************************************************!*\
  !*** ./lib/components/transforms/FilterColumns.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FilterColumns: () => (/* binding */ FilterColumns)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class FilterColumns extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { columns: { sourceData: [], targetKeys: [] } };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "transferData",
                    label: "Filter columns",
                    id: "columns",
                    advanced: true
                }
            ],
        };
        const description = "Use Select Columns to select and reorder columns.";
        super("Select Columns", "filterColumn", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.crosshairIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return [];
    }
    generateComponentCode({ config, inputName, outputName }) {
        const allColumns = config.columns.sourceData;
        const targetKeys = config.columns.targetKeys;
        // Prepare column references, handling named and unnamed columns
        const columnsToKeep = targetKeys.map(key => {
            const column = allColumns.find(c => c.value === key);
            return column && column.named ? `"${key.trim()}"` : `${key.trim()}`;
        }).join(', ');
        // Python code generation for DataFrame operation
        const code = `
# Filter and order columns
${outputName} = ${inputName}[[${columnsToKeep}]]
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/FormulaRow.js":
/*!*************************************************!*\
  !*** ./lib/components/transforms/FormulaRow.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormulaRow: () => (/* binding */ FormulaRow)
/* harmony export */ });
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @amphi/pipeline-components-manager */ "webpack/sharing/consume/default/@amphi/pipeline-components-manager");
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/CloseOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! reactflow */ "webpack/sharing/consume/default/reactflow/reactflow");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(reactflow__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");






class FormulaRow extends (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.PipelineComponent)() {
    constructor() {
        super(...arguments);
        this._name = "Formula Row";
        this._id = "formulaRow";
        this._type = "pandas_df_processor";
        this._category = "transforms";
        this._description = "Use Formula Row to update existing columns or create new columns using expressions and functions.";
        this._icon = _icons__WEBPACK_IMPORTED_MODULE_4__.sumIcon;
        this._default = {};
        this._form = {};
    }
    UIComponent({ id, data, context, componentService, manager, commands, settings }) {
        const { setNodes, deleteElements, setViewport } = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useReactFlow)();
        const store = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStoreApi)();
        const deleteNode = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
            deleteElements({ nodes: [{ id }] });
        }, [id, deleteElements]);
        const zoomSelector = (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.createZoomSelector)();
        const showContent = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)(zoomSelector);
        const selector = (s) => ({
            nodeInternals: s.nodeInternals,
            edges: s.edges,
        });
        const { nodeInternals, edges } = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)(selector);
        const nodeId = id;
        const internals = { nodeInternals, edges, nodeId, componentService };
        // Create the handle element
        const handleElement = react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.renderHandle, {
            type: FormulaRow.Type,
            Handle: reactflow__WEBPACK_IMPORTED_MODULE_3__.Handle,
            Position: reactflow__WEBPACK_IMPORTED_MODULE_3__.Position,
            internals: internals
        });
        const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((evtTargetValue, field) => {
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.onChange)({ evtTargetValue, field, nodeId, store, setNodes });
        }, [nodeId, store, setNodes]);
        // Selector to determine if the node is selected
        const isSelected = (0,reactflow__WEBPACK_IMPORTED_MODULE_3__.useStore)((state) => { var _a; return !!((_a = state.nodeInternals.get(id)) === null || _a === void 0 ? void 0 : _a.selected); });
        const executeUntilComponent = () => {
            commands.execute('pipeline-editor:run-pipeline-until', { nodeId: nodeId, context: context });
            handleChange(Date.now(), 'lastExecuted');
        };
        const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
        let enableExecution = settings.get('enableExecution').composite;
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
            (0,_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.renderComponentUI)({
                id: id,
                data: data,
                context: context,
                manager: manager,
                commands: commands,
                name: FormulaRow.Name,
                ConfigForm: FormulaRow.ConfigForm,
                configFormProps: {
                    nodeId: id,
                    data,
                    context,
                    componentService,
                    manager,
                    commands,
                    store,
                    setNodes,
                    handleChange,
                    modalOpen,
                    setModalOpen
                },
                Icon: FormulaRow.Icon,
                showContent: showContent,
                handle: handleElement,
                deleteNode: deleteNode,
                setViewport: setViewport,
                handleChange,
                isSelected
            }),
            (showContent || isSelected) && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(reactflow__WEBPACK_IMPORTED_MODULE_3__.NodeToolbar, { isVisible: true, position: reactflow__WEBPACK_IMPORTED_MODULE_3__.Position.Bottom },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { onClick: () => setModalOpen(true) },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_4__.settingsIcon.react, null)),
                (FormulaRow.Type.includes('input') || FormulaRow.Type.includes('processor') || FormulaRow.Type.includes('output')) && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", { onClick: () => executeUntilComponent(), disabled: !enableExecution, style: { opacity: enableExecution ? 1 : 0.5, cursor: enableExecution ? 'pointer' : 'not-allowed' } },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_4__.playCircleIcon.react, null)))))));
    }
    provideImports({ config }) {
        return [];
    }
    provideFunctions({ config }) {
        let functions = [];
        config.formulas.forEach((formula, index) => {
            const functionName = `formula_${index + 1}`;
            const formulaCode = formula.formula.trim();
            const formulaType = formula.type;
            let code = '';
            if (formulaType === 'function') {
                // Python function, add it as is
                code = `
${formulaCode}
`;
            }
            functions.push(code);
        });
        return functions;
    }
    generateComponentCode({ config, inputName, outputName }) {
        let code = `${outputName} = ${inputName}.copy()\n`;
        config.formulas.forEach((formula, index) => {
            const columns = formula.columns.map(column => {
                const columnName = column.value;
                const columnIsNamed = column.named;
                return columnIsNamed ? `'${columnName}'` : columnName;
            });
            const columnsStr = columns.join(', ');
            let applyFunction = '';
            if (formula.type === 'function') {
                // Extract function name using a regex
                const functionNameMatch = formula.formula.match(/def\s+(\w+)\s*\(/);
                const extractedFunctionName = functionNameMatch ? functionNameMatch[1] : `formula_${index + 1}`;
                applyFunction = extractedFunctionName;
            }
            else if (formula.type === 'lambda') {
                // Use lambda expression directly
                applyFunction = formula.formula.trim();
            }
            else if (formula.type === 'expr') {
                // Use Python expression directly inline
                applyFunction = `(lambda row: ${formula.formula.trim()})`;
            }
            if (columns.length > 1) {
                // Use .loc with applymap if more than one column is present
                code += `${outputName}.loc[:, [${columnsStr}]] = ${outputName}.loc[:, [${columnsStr}]].applymap(${applyFunction})\n`;
            }
            else {
                // Use apply if only one column
                code += `${outputName}[${columnsStr}] = ${outputName}.apply(${applyFunction}, axis=1)\n`;
            }
        });
        return code;
    }
}
FormulaRow.ConfigForm = ({ nodeId, data, context, componentService, manager, commands, store, setNodes, handleChange, modalOpen, setModalOpen }) => {
    const [formulas, setFormulas] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data.formulas || [{ columns: [], formula: '', type: 'expr' }]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    }, [formulas]);
    const handleAddFormula = () => {
        setFormulas([...formulas, { columns: [], formula: '', type: 'expr' }]);
        handleChange(formulas, 'formulas');
    };
    const handleRemoveFormula = (index) => {
        const updatedFormulas = formulas.filter((_, i) => i !== index);
        setFormulas(updatedFormulas);
        handleChange(updatedFormulas, 'formulas');
    };
    const handleFormulaChange = (value, index, field) => {
        const updatedFormulas = [...formulas];
        updatedFormulas[index] = {
            ...updatedFormulas[index],
            [field]: value
        };
        setFormulas(updatedFormulas);
        handleChange(updatedFormulas, 'formulas');
    };
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.ConfigProvider, { theme: {
            token: {
                colorPrimary: '#5F9B97',
            },
        } },
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Modal, { title: "Formula Row", open: modalOpen, onOk: () => setModalOpen(false), onCancel: () => setModalOpen(false), width: 900, footer: (_, { OkBtn }) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(OkBtn, null))) },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form, { labelCol: { span: 6 }, wrapperCol: { span: 18 }, name: "dynamic_form_complex", autoComplete: "off", initialValues: { items: formulas } },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form.List, { name: "items" }, (fields, { add, remove }) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: { display: 'flex', rowGap: 16, flexDirection: 'column' } },
                    formulas.map((formula, index) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Card, { size: "small", title: `Formula ${index + 1}`, key: `formula-${index}`, extra: react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["default"], { onClick: () => handleRemoveFormula(index) }) },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, { label: "Columns", name: [index, 'columns'], key: `formula-columns-${index}` },
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.SelectColumns, { field: {
                                    type: 'columns',
                                    id: 'columns',
                                    label: "Columns (Existing or new)",
                                    placeholder: "Select columns",
                                }, handleChange: (value) => handleFormulaChange(value, index, 'columns'), defaultValues: formula.columns, context: context, commands: commands, componentService: componentService, nodeId: nodeId, advanced: true })),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, { label: "Formula Type", name: [index, 'type'], key: `formula-type-${index}` },
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.SelectRegular, { field: {
                                    type: 'select',
                                    id: 'type',
                                    label: "Formula Type",
                                    placeholder: "Select columns",
                                    options: [
                                        { value: "expr", label: "Python Expression", tooltip: "Combine variables and operators to compute a value for the selected column(s).\nExample: row['column1'].upper()" },
                                        { value: "function", label: "Python Function", tooltip: "Apply a Python function to the selected column(s), with the row passed as a parameter." },
                                        { value: "lambda", label: "Lambda Expression", tooltip: "Use a Python lambda expression, an anonymous function, to process the row and apply it to the selected column(s)." }
                                    ],
                                }, handleChange: (value) => handleFormulaChange(value, index, 'type'), defaultValue: formula.type, advanced: true })),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, { label: "Python Code", name: [index, 'formula'], key: `formula-code-${index}` },
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.CodeTextarea, { field: {
                                    type: "codeTextarea",
                                    id: 'formula',
                                    label: "Python Formula",
                                    placeholder: "row['column1'] + row['column2']",
                                    height: "80px",
                                    mode: 'python'
                                }, handleChange: (value) => handleFormulaChange(value, index, 'formula'), value: formula.formula, advanced: true }))))),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Button, { type: "dashed", onClick: handleAddFormula, block: true }, "+ Add formula"))))))));
};



/***/ }),

/***/ "./lib/components/transforms/FrequencyAnalysis.js":
/*!********************************************************!*\
  !*** ./lib/components/transforms/FrequencyAnalysis.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FrequencyAnalysis: () => (/* binding */ FrequencyAnalysis)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class FrequencyAnalysis extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            columns: [],
        };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "columns",
                    label: "Select Columns",
                    id: "columns",
                    placeholder: "Default: all columns",
                }
            ],
        };
        const description = "Use Frequency Analysis to generate frequency tables on columns.";
        super("Frequency Analysis", "frequencyAnalysis", description, "pandas_df_processor", [], "Data Exploration", _icons__WEBPACK_IMPORTED_MODULE_1__.activityIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    provideFunctions({ config }) {
        var _a, _b;
        const prefix = (_b = (_a = config === null || config === void 0 ? void 0 : config.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
        // Function to perform frequency analysis
        const frequencyAnalysisFunction = `
# Function to perform frequency analysis
def frequency_analysis(df, column_name):
    # Frequency counts
    frequency = df[column_name].value_counts(dropna=False)
    percentage = df[column_name].value_counts(normalize=True, dropna=False) * 100
    
    # Cumulative frequency and percentage
    cumulative_frequency = frequency.cumsum()
    cumulative_percent = percentage.cumsum()

    # Combine all into a DataFrame
    result = ${prefix}.DataFrame({
        'Field Name': column_name,
        'Field Value': frequency.index,
        'Frequency': frequency.values,
        'Percent': percentage.values,
        'Cumulative Frequency': cumulative_frequency.values,
        'Cumulative Percent': cumulative_percent.values
    })
    return result
    `;
        return [frequencyAnalysisFunction];
    }
    generateComponentCode({ config, inputName, outputName }) {
        var _a, _b;
        const prefix = (_b = (_a = config === null || config === void 0 ? void 0 : config.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
        const selectedColumns = config.columns;
        let code = `
# Perform frequency analysis on selected columns
${outputName}_results = []
`;
        // Helper function to get the correct column reference
        const getColumnReference = (column) => {
            return column.named ? `'${column.value}'` : column.value;
        };
        // Check if columns are selected; if not, analyze all columns
        if (selectedColumns && selectedColumns.length > 0) {
            code += selectedColumns.map((col) => {
                const columnRef = getColumnReference(col);
                return `
${outputName}_result_${col.value} = frequency_analysis(${inputName}, ${columnRef})
${outputName}_result_${col.value}['Field Name'] = '${col.value}'
${outputName}_results.append(${outputName}_result_${col.value})
`;
            }).join('');
            code += `${outputName} = ${prefix}.concat(${outputName}_results, ignore_index=True)\n`;
        }
        else {
            // If no columns are selected, analyze all columns
            code += `
for col in ${inputName}.columns:
    result = frequency_analysis(${inputName}, col)
    ${outputName}_results.append(result)
${outputName} = ${prefix}.concat(${outputName}_results, ignore_index=True)\n`;
        }
        return code + '\n';
    }
}


/***/ }),

/***/ "./lib/components/transforms/GenerateIDColumn.js":
/*!*******************************************************!*\
  !*** ./lib/components/transforms/GenerateIDColumn.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GenerateIDColumn: () => (/* binding */ GenerateIDColumn)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class GenerateIDColumn extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { columnType: 'int64', insertPosition: 'first' };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "inputNumber",
                    label: "Starting Value",
                    id: "startingValue",
                    placeholder: "0",
                    min: 0
                },
                {
                    type: "selectCustomizable",
                    label: "Column Type",
                    id: "columnType",
                    options: [
                        { value: "int64", label: "Integer (int64)" },
                        { value: "float64", label: "Float (float64)" }
                    ],
                    advanced: true
                },
                {
                    type: "radio",
                    label: "Insert Position",
                    id: "insertPosition",
                    options: [
                        { value: "first", label: "First" },
                        { value: "last", label: "Last" }
                    ]
                }
            ],
        };
        const description = "Use Row ID to assign a unique identifier to each row in a dataset.";
        super("Row ID", "generate_id_column", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.hashIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    generateComponentCode({ config, inputName, outputName }) {
        var _a, _b;
        const prefix = (_b = (_a = config === null || config === void 0 ? void 0 : config.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
        const startingValue = config.startingValue || 0;
        const columnType = config.columnType || "int64";
        const insertPosition = config.insertPosition || "last";
        const idColumn = `range(${startingValue}, ${startingValue} + len(${inputName}))`;
        const idColumnFirst = `['ID'] + ${inputName}.columns.tolist()`;
        const idColumnLast = `${inputName}.columns.tolist() + ['ID']`;
        const code = `
# Generate ID column
${outputName} = ${inputName}.copy()
${outputName}['ID'] = ${prefix}.Series(${idColumn}, dtype='${columnType}')
${outputName} = ${outputName}.reindex(columns=${insertPosition === "first" ? idColumnFirst : idColumnLast})
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/JSON/ExpandList.js":
/*!******************************************************!*\
  !*** ./lib/components/transforms/JSON/ExpandList.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExpandList: () => (/* binding */ ExpandList)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class ExpandList extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {};
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "column",
                    label: "Column",
                    id: "column",
                    placeholder: "Select column",
                }
            ]
        };
        const description = "Use Expand JSON List on columns containing JSON list into multiple columns.";
        super("Expand JSON List", "expandList", description, "pandas_df_processor", [], "transforms.JSON", _icons__WEBPACK_IMPORTED_MODULE_1__.expandJsonIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    generateComponentCode({ config, inputName, outputName }) {
        // Start generating the code string
        const columnName = config.column.value;
        const columnType = config.column.type;
        const columnIsNamed = config.column.named;
        let columnReference;
        columnReference = columnIsNamed ? `'${columnName}'` : columnName;
        let code = `# Expand the list in the specified column\n`;
        code += `${outputName} = ${inputName}[${columnReference}].apply(pd.Series)\n`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/JSON/FlattenJSON.js":
/*!*******************************************************!*\
  !*** ./lib/components/transforms/JSON/FlattenJSON.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FlattenJSON: () => (/* binding */ FlattenJSON)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class FlattenJSON extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {};
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "column",
                    label: "Column",
                    id: "column",
                    placeholder: "Select column",
                }
            ]
        };
        const description = "Flatten JSON data in a specified column for easier export to CSV.";
        super("Flatten JSON", "flattenJSON", description, "pandas_df_processor", [], "transforms.JSON", _icons__WEBPACK_IMPORTED_MODULE_1__.expandIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return [
            "import pandas as pd",
            "from pandas import json_normalize"
        ];
    }
    generateComponentCode({ config, inputName, outputName }) {
        // Retrieve the column details from the config
        const columnName = config.column.value;
        const columnType = config.column.type;
        const columnIsNamed = config.column.named;
        let columnReference;
        columnReference = columnIsNamed ? `'${columnName}'` : columnName;
        let code = `# Flatten the JSON data in the specified column\n`;
        code += `${outputName} = pd.json_normalize(${inputName}[${columnReference}])\n`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Join.js":
/*!*******************************************!*\
  !*** ./lib/components/transforms/Join.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Join: () => (/* binding */ Join)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Join extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { how: "left" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "columns",
                    label: "Left Input Column(s)",
                    id: "leftKeyColumn",
                    placeholder: "Column name",
                    tooltip: "If you're joining by multiple columns, make sure the column lists are ordered to match the corresponding columns in the right dataset.",
                    inputNb: 1
                },
                {
                    type: "columns",
                    label: "Right Input Column(s)",
                    id: "rightKeyColumn",
                    placeholder: "Column name",
                    tooltip: "If you're joining by multiple columns, make sure the column lists are ordered to match the corresponding columns in the left dataset.",
                    inputNb: 2
                },
                {
                    type: "select",
                    label: "Join type",
                    id: "how",
                    placeholder: "Default: Inner",
                    options: [
                        { value: "inner", label: "Inner", tooltip: "Return only the rows with matching keys in both datasets (intersection)." },
                        { value: "left", label: "Left", tooltip: "Return all rows from the left dataset and matched rows from the right dataset (including NaN for no match)." },
                        { value: "right", label: "Right", tooltip: "Return all rows from the right dataset and matched rows from the left dataset (including NaN for no match)." },
                        { value: "outer", label: "Outer", tooltip: "Return all rows from both datasets, with matches where available and NaN for no match (union)." },
                        { value: "cross", label: "Cross", tooltip: "Creates the cartesian product from both datasets, preserves the order of the left keys." },
                        { value: "anti-left", label: "Anti Left", tooltip: "Return rows from the left dataset that do not have matching rows in the right dataset." },
                        { value: "anti-right", label: "Anti Right", tooltip: "Return rows from the right dataset that do not have matching rows in the left dataset." }
                    ],
                    advanced: true
                }
            ],
        };
        const description = "Use Join Datasets to combine two datasets by one or more columns.";
        super("Join Datasets", "join", description, "pandas_df_double_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.mergeIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    generateComponentCode({ config, inputName1, inputName2, outputName }) {
        var _a, _b;
        const prefix = (_b = (_a = config === null || config === void 0 ? void 0 : config.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
        // Extract and map leftKeyColumn and rightKeyColumn arrays
        const leftKeys = config.leftKeyColumn.map(column => column.named ? `"${column.value}"` : column.value);
        const rightKeys = config.rightKeyColumn.map(column => column.named ? `"${column.value}"` : column.value);
        // Join the keys into a string for the Python code
        const leftKeysStr = `[${leftKeys.join(', ')}]`;
        const rightKeysStr = `[${rightKeys.join(', ')}]`;
        let code = `# Join ${inputName1} and ${inputName2}\n`;
        if (config.how === "anti-left") {
            code += `${outputName} = ${prefix}.merge(${inputName1}, ${inputName2}, left_on=${leftKeysStr}, right_on=${rightKeysStr}, how="left", indicator=True)\n`;
            code += `${outputName} = ${outputName}[${outputName}["_merge"] == "left_only"].drop(columns=["_merge"])\n`;
        }
        else if (config.how === "anti-right") {
            code += `${outputName} = ${prefix}.merge(${inputName1}, ${inputName2}, left_on=${leftKeysStr}, right_on=${rightKeysStr}, how="right", indicator=True)\n`;
            code += `${outputName} = ${outputName}[${outputName}["_merge"] == "right_only"].drop(columns=["_merge"])\n`;
        }
        else {
            const joinType = config.how ? `, how="${config.how}"` : '';
            code += `${outputName} = ${prefix}.merge(${inputName1}, ${inputName2}, left_on=${leftKeysStr}, right_on=${rightKeysStr}${joinType})\n`;
        }
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Pivot.js":
/*!********************************************!*\
  !*** ./lib/components/transforms/Pivot.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Pivot: () => (/* binding */ Pivot)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");

 // Adjust the import path
class Pivot extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { aggfunc: "none", fillValue: 0 };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "columns",
                    label: "Index Columns",
                    id: "indexColumns",
                    tooltip: "List of columns used as index for the pivot.",
                    placeholder: "Select columns"
                },
                {
                    type: "columns",
                    label: "Columns to pivot",
                    id: "columnsToPivot",
                    tooltip: "List of columns that are pivoted.",
                    placeholder: "Select columns"
                },
                {
                    type: "columns",
                    label: "Values",
                    id: "values",
                    tooltip: "Values used to fill in the pivot table.",
                    placeholder: "Select columns"
                },
                {
                    type: "select",
                    label: "Aggregation Function",
                    id: "aggfunc",
                    tooltip: "Aggregation used on the values to fill in the pivot table.",
                    options: [
                        { value: "none", label: "None (use pivot without aggregation)" },
                        { value: "sum", label: "Sum" },
                        { value: "mean", label: "Mean" },
                        { value: "min", label: "Min" },
                        { value: "max", label: "Max" }
                    ],
                    advanced: true
                },
                {
                    type: "inputNumber",
                    label: "Fill missing values",
                    id: "fillValue",
                    placeholder: "0",
                    min: 0,
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Drop rows with missing values",
                    id: "dropna",
                    advanced: true
                }
            ],
        };
        const description = "Use Pivot Dataset to rearrange and aggregate data in a dataset. It allows you to organize your data into a new table by defining rows, columns, and the values to populate the table. If you're looking to simply swap rows and columns without aggregation, check out the Transpose Dataset component.";
        super("Pivot Dataset", "pivot", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.pivotIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return [];
    }
    generateComponentCode({ config, inputName, outputName }) {
        const formatColumns = (cols) => cols.length === 1 ? `"${cols[0].value}"` : `[${cols.map(col => `"${col.value}"`).join(', ')}]`;
        const indexColumns = formatColumns(config.indexColumns);
        const columnsToPivot = formatColumns(config.columnsToPivot);
        const values = formatColumns(config.values);
        if (config.aggfunc === "none") {
            let code = `
${outputName} = ${inputName}.pivot(
    index=${indexColumns},
    columns=${columnsToPivot},
    values=${values}
).reset_index()\n`;
            if (config.fillValue !== null && config.fillValue !== undefined && config.fillValue !== '') {
                code += `
${outputName} = ${outputName}.fillna(${config.fillValue})\n`;
            }
            return code;
        }
        else {
            const aggfunc = `"${config.aggfunc}"`;
            const fillValue = config.fillValue !== null && config.fillValue !== undefined && config.fillValue !== '' ? config.fillValue : 0;
            const dropna = config.dropna ? 'True' : 'False';
            let code = `
${outputName} = ${inputName}.pivot_table(
    index=${indexColumns},
    columns=${columnsToPivot},
    values=${values},
    aggfunc=${aggfunc},
    fill_value=${fillValue},
    dropna=${dropna}
).reset_index()\n`;
            return code;
        }
    }
}


/***/ }),

/***/ "./lib/components/transforms/RenameColumns.js":
/*!****************************************************!*\
  !*** ./lib/components/transforms/RenameColumns.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RenameColumns: () => (/* binding */ RenameColumns)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class RenameColumns extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {};
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "keyvalueColumns",
                    label: "Columns",
                    id: "columns",
                    placeholders: { key: "column name", value: "new column name" },
                    advanced: true
                }
            ],
        };
        const description = "Use Rename Columns to rename one or more columns.";
        super("Rename Columns", "rename", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.editIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return [];
    }
    generateComponentCode({ config, inputName, outputName }) {
        let columnsParam = "{";
        if (config.columns && config.columns.length > 0) {
            columnsParam += config.columns.map(column => {
                if (column.key.named) {
                    // Handle named columns as strings
                    return `"${column.key.value}": "${column.value}"`;
                }
                else {
                    // Handle unnamed (numeric index) columns, converting them to strings
                    return `${column.key.value}: "${column.value}"`;
                }
            }).join(", ");
            columnsParam += "}";
        }
        else {
            columnsParam = "{}"; // Ensure columnsParam is always initialized
        }
        // Template for the pandas rename columns code, explicitly setting axis='columns'
        const code = `
# Rename columns
${outputName} = ${inputName}.rename(columns=${columnsParam})
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Sample.js":
/*!*********************************************!*\
  !*** ./lib/components/transforms/Sample.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Sample: () => (/* binding */ Sample)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Sample extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { numberType: "number", rows: 1, percentage: 1, mode: "random", groupBy: [] };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "Type",
                    id: "numberType",
                    options: [
                        { value: "number", label: "Fixed Number" },
                        { value: "percentage", label: "Percentage" }
                    ],
                    advanced: true
                },
                {
                    type: "inputNumber",
                    label: "Rows number",
                    id: "rows",
                    placeholder: "0",
                    min: 0,
                    condition: { numberType: "number" }
                },
                {
                    type: "inputNumber",
                    label: "Percentage",
                    id: "percentage",
                    placeholder: "0",
                    min: 0,
                    max: 100,
                    condition: { numberType: "percentage" }
                },
                {
                    type: "radio",
                    label: "Mode",
                    id: "mode",
                    options: [
                        { value: "random", label: "Random" },
                        { value: "head", label: "First" },
                        { value: "tail", label: "Last" }
                    ],
                    advanced: true
                },
                {
                    type: "columns",
                    label: "Group By Columns",
                    id: "groupBy",
                    selectAll: true,
                    advanced: true
                }
            ],
        };
        const description = "Use the Sample component to limit data by selecting a specified number of rows or percentage, either randomly, from the start, or from the end of the dataset. You can also group the sampling by one or more columns.";
        super("Sample Datasets", "sample", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.randomIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    formatGroupByColumns(groupBy) {
        return groupBy.map(col => (col.named ? `"${col.value}"` : col.value)).join(', ');
    }
    generateComponentCode({ config, inputName, outputName }) {
        let sampleCode = "";
        const groupByColumns = config.groupBy && config.groupBy.length > 0
            ? `[${this.formatGroupByColumns(config.groupBy)}]`
            : null;
        if (config.numberType === "number") {
            if (config.mode === "random") {
                if (groupByColumns) {
                    sampleCode = `${outputName} = ${inputName}.groupby(${groupByColumns}).sample(n=${config.rows})`;
                }
                else {
                    sampleCode = `${outputName} = ${inputName}.sample(n=${config.rows})`;
                }
            }
            else if (config.mode === "tail") {
                if (groupByColumns) {
                    sampleCode = `${outputName} = ${inputName}.groupby(${groupByColumns}).tail(${config.rows})`;
                }
                else {
                    sampleCode = `${outputName} = ${inputName}.tail(${config.rows})`;
                }
            }
            else if (config.mode === "head") {
                if (groupByColumns) {
                    sampleCode = `${outputName} = ${inputName}.groupby(${groupByColumns}).head(${config.rows})`;
                }
                else {
                    sampleCode = `${outputName} = ${inputName}.head(${config.rows})`;
                }
            }
        }
        else if (config.numberType === "percentage") {
            const frac = config.percentage / 100;
            if (config.mode === "random") {
                if (groupByColumns) {
                    sampleCode = `${outputName} = ${inputName}.groupby(${groupByColumns}).sample(frac=${frac})`;
                }
                else {
                    sampleCode = `${outputName} = ${inputName}.sample(frac=${frac})`;
                }
            }
            else if (config.mode === "tail") {
                if (groupByColumns) {
                    sampleCode = `${outputName} = ${inputName}.groupby(${groupByColumns}).apply(lambda x: x.tail(int(len(x) * ${frac}))).reset_index(drop=True)`;
                }
                else {
                    sampleCode = `${outputName} = ${inputName}.iloc[-int(len(${inputName}) * ${frac}):]`;
                }
            }
            else if (config.mode === "head") {
                if (groupByColumns) {
                    sampleCode = `${outputName} = ${inputName}.groupby(${groupByColumns}).apply(lambda x: x.head(int(len(x) * ${frac}))).reset_index(drop=True)`;
                }
                else {
                    sampleCode = `${outputName} = ${inputName}.iloc[:int(len(${inputName}) * ${frac})]`;
                }
            }
        }
        // Template for the pandas query code
        const code = `
${sampleCode}
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Sort.js":
/*!*******************************************!*\
  !*** ./lib/components/transforms/Sort.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Sort: () => (/* binding */ Sort)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Sort extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { columnAndOrder: [] };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "keyvalueColumnsRadio",
                    label: "Columns Sorting Order",
                    id: "columnAndOrder",
                    options: [
                        { value: "True", label: "Asc." },
                        { value: "False", label: "Desc." }
                    ],
                },
                {
                    type: "boolean",
                    label: "Ignore Index",
                    id: "ignoreIndex",
                    advanced: true
                }
            ],
        };
        const description = "Use Sort Rows to sort based on the values in columns. Values will be sorted by lexicographical order.";
        super("Sort Rows", "sort", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.sortIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return [];
    }
    generateComponentCode({ config, inputName, outputName }) {
        const byColumns = `by=[${config.columnAndOrder.map(item => item.key.named ? `"${item.key.value}"` : item.key.value).join(", ")}]`;
        const ascending = `ascending=[${config.columnAndOrder.map(item => item.value === "True" ? "True" : "False").join(", ")}]`;
        const ignoreIndex = config.ignoreIndex ? `, ignore_index=${config.ignoreIndex}` : "";
        const code = `
# Sort rows 
${outputName} = ${inputName}.sort_values(${byColumns}, ${ascending}${ignoreIndex})
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/SplitColumn.js":
/*!**************************************************!*\
  !*** ./lib/components/transforms/SplitColumn.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SplitColumn: () => (/* binding */ SplitColumn)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class SplitColumn extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { splitType: "columns", regex: false, keepOriginalColumn: false };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "Split Type",
                    id: "splitType",
                    options: [
                        { value: "columns", label: "Split to columns" },
                        { value: "rows", label: "Split to rows" }
                    ],
                    advanced: true
                },
                {
                    type: "column",
                    label: "Column",
                    id: "column",
                    placeholder: "Type column name",
                },
                {
                    type: "selectCustomizable",
                    label: "Delimiter",
                    id: "delimiter",
                    placeholder: "Select or type delimiter",
                    options: [
                        { value: ",", label: "comma (,)" },
                        { value: ";", label: "semicolon (;)" },
                        { value: " ", label: "space" },
                        { value: "  ", label: "tab" },
                        { value: "|", label: "pipe (|)" }
                    ],
                },
                {
                    type: "boolean",
                    label: "Is delimiter a regex?",
                    id: "regex",
                    advanced: true
                },
                {
                    type: "inputNumber",
                    label: "Number of columns",
                    id: "numberColumns",
                    placeholder: "auto",
                    min: 1,
                    condition: { splitType: "columns" }
                },
                {
                    type: "boolean",
                    label: "Keep original column",
                    id: "keepOriginalColumn",
                    advanced: true
                }
            ],
        };
        const description = "Use Split Column to split the text from one column into multiple columns.";
        super("Split Column", "splitColumn", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.splitIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    generateComponentCode({ config, inputName, outputName }) {
        var _a, _b;
        const prefix = (_b = (_a = config === null || config === void 0 ? void 0 : config.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
        const columnName = config.column.value; // name of the column
        const columnType = config.column.type; // current type of the column (e.g., 'int', 'string')
        const columnNamed = config.column.named; // boolean, true if column is named, false if index is used
        // Ensure unique variable names for intermediate dataframes
        const uniqueSplitVar = `${outputName}_split`;
        const uniqueCombinedVar = `${outputName}_combined`;
        // Start generating the code string
        let code = `\n# Create a new DataFrame from the split operation\n`;
        // Handling column access based on whether it's named or indexed
        const columnAccess = columnNamed ? `"${columnName}"` : columnName;
        // Convert column to string if it's not already
        if (columnType !== "string") {
            code += `${inputName}[${columnAccess}] = ${inputName}[${columnAccess}].astype("string")\n`;
        }
        // Determine whether to use regex in the split
        const regexOption = config.regex ? ", regex=True" : "";
        // Add the split logic based on splitType
        if (config.splitType === "columns") {
            // Split to columns
            code += `${uniqueSplitVar} = ${inputName}[${columnAccess}].str.split("${config.delimiter}"${regexOption}, expand=True)\n`;
            // Rename the new columns to avoid any potential overlap
            code += `${uniqueSplitVar}.columns  = [f"${columnName}_{i}" for i in range(${uniqueSplitVar}.shape[1])]\n`;
            // If numberColumns is specified, keep only the desired number of columns
            if (config.numberColumns > 0) {
                code += `${uniqueSplitVar} = ${uniqueSplitVar}.iloc[:, :${config.numberColumns}]\n`;
            }
            // Combine the original DataFrame with the new columns
            code += `${outputName} = ${prefix}.concat([${inputName}, ${uniqueSplitVar}], axis=1)\n`;
            // Check if the original column should be kept
            if (!config.keepOriginalColumn) {
                code += `\n# Remove the original column used for split\n`;
                code += `${outputName}.drop(columns=[${columnAccess}], inplace=True)\n`;
            }
        }
        else if (config.splitType === "rows") {
            // Split to rows
            code += `${uniqueSplitVar} = ${inputName}.assign(${columnAccess}=${inputName}[${columnAccess}].str.split("${config.delimiter}"${regexOption}))\n`;
            code += `${uniqueSplitVar} = ${uniqueSplitVar}.explode(${columnAccess})\n`;
            code += `${outputName} = ${uniqueSplitVar}\n`;
        }
        // Return the generated code
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Summary.js":
/*!**********************************************!*\
  !*** ./lib/components/transforms/Summary.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Summary: () => (/* binding */ Summary)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Summary extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = {
            statisticsType: "all",
            pivot: "rows" // Set default pivot to 'columns'
        };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "select",
                    label: "Apply to column types",
                    id: "statisticsType",
                    placeholder: "Select statistics type",
                    options: [
                        { value: "all", label: "All types" },
                        { value: "numerical", label: "Numerical only", tooltip: "Limit the result to numeric types" },
                        { value: "categorical", label: "Categorical only", tooltip: "Limit the result to categorical types" }, // Fixed 'toolip' to 'tooltip'
                    ],
                },
                {
                    type: "radio",
                    label: "Resulting Table Columns",
                    id: "pivot",
                    placeholder: "Select how should the resulting table be formatted",
                    options: [
                        { value: "rows", label: "As rows" },
                        { value: "columns", label: "As columns" }
                    ],
                }
            ],
        };
        const description = "Use Summary Component to provide a statistical summary of the incoming data.";
        super("Summary", "summary", description, "pandas_df_processor", [], "Data Exploration", _icons__WEBPACK_IMPORTED_MODULE_1__.eyeIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    generateComponentCode({ config, inputName, outputName }) {
        const statisticsType = config.statisticsType;
        const pivot = config.pivot;
        let code = `
# Generate summary statistics
`;
        switch (statisticsType) {
            case "all":
                code += `${outputName} = ${inputName}.describe(include='all')\n`;
                break;
            case "numerical":
                code += `${outputName} = ${inputName}.describe()\n`;
                break;
            case "categorical":
                code += `${outputName} = ${inputName}.describe(include=['object', 'category'])\n`;
                break;
            default:
                code += `${outputName} = ${inputName}.describe()\n`;
                break;
        }
        // Apply pivot if specified
        if (pivot === "rows") {
            code += `${outputName} = ${outputName}.transpose()\n`;
        }
        return code + '\n';
    }
}


/***/ }),

/***/ "./lib/components/transforms/Transpose.js":
/*!************************************************!*\
  !*** ./lib/components/transforms/Transpose.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Transpose: () => (/* binding */ Transpose)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Transpose extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { order: "True" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "info",
                    label: "Information",
                    id: "information",
                    text: "Switches the rows and columns of the input."
                },
                {
                    type: "columns",
                    label: "Key Columns",
                    id: "key",
                    selectAll: true,
                    advanced: true
                },
                {
                    type: "columns",
                    label: "Columns to transpose",
                    id: "columns",
                    selectAll: true,
                    advanced: true
                }
            ],
        };
        const description = "Use Transpose Dataset to swap the rows and the columns of a dataset. It simply repositions the data without aggregation. If you're looking for rearranging and aggregating the data, check out the Pivot Dataset component.";
        super("Transpose Dataset", "transpose", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.transposeIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    generateComponentCode({ config, inputName, outputName }) {
        const keyColumns = this.formatColumns(config.key);
        const dataColumns = this.formatColumns(config.columns);
        // Determine if key columns are provided
        const hasKey = config.key && config.key.length > 0;
        const idVars = hasKey ? `[${keyColumns}]` : '';
        // Determine if specific data columns are provided
        const hasDataColumns = config.columns && config.columns.length > 0;
        const valueVars = hasDataColumns ? `[${dataColumns}]` : '';
        // Create the melt function parameters
        const meltParams = [
            hasKey ? `id_vars=${idVars},` : '',
            hasDataColumns ? `value_vars=${valueVars},` : '',
            `var_name='Variable',`,
            `value_name='Value'`
        ]
            .filter(param => param) // Remove empty strings
            .map(param => `    ${param}`) // Indent each parameter
            .join('\n');
        // Construct the Python code using template literals
        const code = `
# Transpose Dataset Component
${hasKey ? `# Preserving key columns: ${keyColumns}` : `# No key columns provided; transposing entire DataFrame`}

# Melting the DataFrame to unpivot selected columns
melted = ${inputName}.melt(
${meltParams}
)

# Assign the melted DataFrame to the output
${outputName} = melted
`.trim(); // Trim to remove leading/trailing whitespace
        return code;
    }
    formatColumns(columns) {
        return columns.map(col => (col.named ? `"${col.value}"` : col.value)).join(', ');
    }
}


/***/ }),

/***/ "./lib/components/transforms/TypeConverter.js":
/*!****************************************************!*\
  !*** ./lib/components/transforms/TypeConverter.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TypeConverter: () => (/* binding */ TypeConverter)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class TypeConverter extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { dataType: "string" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "column",
                    label: "Column name",
                    id: "column",
                    placeholder: "Column name",
                },
                {
                    type: "cascader",
                    label: "Data Type to convert to",
                    id: "dataType",
                    placeholder: "Select ...",
                    onlyLastValue: true,
                    options: [
                        {
                            value: "numeric",
                            label: "Numeric",
                            children: [
                                {
                                    value: "int",
                                    label: "Integer",
                                    children: [
                                        { value: "int64", label: "int64: Standard integer type." },
                                        { value: "int32", label: "int32: For optimized memory usage." },
                                        { value: "int16", label: "int16: For more optimized memory usage." },
                                        { value: "int8", label: "int8: For more optimized memory usage." },
                                        { value: "uint64", label: "uint64: Unsigned integer (can only hold non-negative values)" },
                                        { value: "uint32", label: "uint32: For more optimized memory usage." },
                                        { value: "uint16", label: "uint16: For more optimized memory usage." },
                                        { value: "uint8", label: "uint8: For more optimized memory usage." }
                                    ]
                                },
                                {
                                    value: "float",
                                    label: "Float",
                                    children: [
                                        { value: "float64", label: "float64: Standard floating-point type." },
                                        { value: "float32", label: "float32: For optimized memory usage." },
                                        { value: "float16", label: "float16: For optimized memory usage." }
                                    ]
                                }
                            ]
                        },
                        {
                            value: "text",
                            label: "Text",
                            children: [
                                { value: "string", label: "string: For string data. (recommended)" },
                                { value: "object", label: "object: For generic objects (strings, timestamps, mixed types)." },
                                { value: "category", label: "category: For categorical variables." }
                            ]
                        },
                        {
                            value: "datetime",
                            label: "Date & Time",
                            children: [
                                { value: "datetime64[ns]", label: "datetime64[ns]: For datetime values." },
                                { value: "datetime64[ms]", label: "datetime64[ms]: For datetime values in milliseconds." },
                                { value: "datetime64[s]", label: "datetime64[s]: For datetime values in seconds." },
                                { value: "datetime32[ns]", label: "datetime32[ns]: For compact datetime storage in nanoseconds." },
                                { value: "datetime32[ms]", label: "datetime32[ms]: For compact datetime storage in milliseconds." },
                                { value: "timedelta[ns]", label: "timedelta[ns]: For differences between two datetimes." }
                            ]
                        },
                        {
                            value: "boolean",
                            label: "Boolean",
                            children: [
                                { value: "bool", label: "bool: For boolean values (True or False)." }
                            ]
                        }
                    ]
                },
                {
                    type: "select",
                    label: "If fails",
                    id: "errorManagement",
                    placeholder: "Select behavior",
                    options: [
                        { value: "stop", label: "Stop", tooltip: "Stops the conversion process immediately if a value can't be converted." },
                        { value: "warning", label: "Warning and Continue", tooltip: "Issues a warning, continues the conversion, and assigns null to unconverted values. The original value will be displayed in the console." },
                    ],
                    advanced: true
                }
            ],
        };
        const description = "Use Type Converter to change the data type of a column to the specified type.";
        super("Type Converter", "typeConverter", description, "pandas_df_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.typeIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        const imports = ["import pandas as pd"];
        return imports;
    }
    generateComponentCode({ config, inputName, outputName }) {
        var _a, _b;
        const prefix = (_b = (_a = config === null || config === void 0 ? void 0 : config.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
        const columnName = config.column.value;
        const columnType = config.column.type;
        const columnNamed = config.column.named;
        const dataType = config.dataType[config.dataType.length - 1];
        const errorManagement = config.errorManagement ? config.errorManagement : 'stop';
        let code = `\n\n# Initialize the output DataFrame\n`;
        code += `${outputName} = ${inputName}.copy()\n`;
        code += `# Convert ${columnName} from ${columnType} to ${dataType}\n`;
        code += this.generateConversionCode(inputName, outputName, columnName, columnType, dataType, columnNamed, errorManagement, prefix);
        return code;
    }
    generateConversionCode(inputName, outputName, columnName, columnType, dataType, columnNamed, errorManagement, prefix) {
        let code = '';
        let conversionFunction;
        let additionalParams = "";
        let errorsParam = 'raise';
        if (errorManagement === 'warning') {
            // Use 'coerce' where applicable, 'ignore' for astype
            if (['int', 'float', 'uint'].some(type => dataType.startsWith(type)) || dataType.startsWith("datetime")) {
                errorsParam = 'coerce';
            }
            else {
                errorsParam = 'ignore';
            }
        }
        if (dataType.startsWith("datetime")) {
            if (dataType.includes("[")) {
                const unit = dataType.split("[")[1].split("]")[0];
                additionalParams = `, unit="${unit}"`;
            }
            conversionFunction = `${prefix}.to_datetime(${inputName}["${columnName}"]${additionalParams}, errors='${errorsParam}')`;
            if (columnNamed) {
                code += `${outputName}["${columnName}"] = ${conversionFunction}\n`;
            }
            else {
                code += `${outputName}.iloc[:, ${columnName}] = ${conversionFunction}\n`;
            }
        }
        else if (dataType.startsWith('int') || dataType.startsWith('float') || dataType.startsWith('uint')) {
            // Use ${prefix}.to_numeric for numeric types
            conversionFunction = `${prefix}.to_numeric(${inputName}["${columnName}"], errors='${errorsParam}')`;
            if (columnNamed) {
                code += `${outputName}["${columnName}"] = ${conversionFunction}\n`;
            }
            else {
                code += `${outputName}.iloc[:, ${columnName}] = ${conversionFunction}\n`;
            }
            // Then convert to the specified data type
            code += `${outputName}["${columnName}"] = ${outputName}["${columnName}"].astype("${dataType}", errors='${errorsParam}')\n`;
        }
        else {
            // For other types, use astype with errors parameter
            conversionFunction = `astype("${dataType}", errors='${errorsParam}')`;
            if (columnNamed) {
                code += `${outputName}["${columnName}"] = ${inputName}["${columnName}"].${conversionFunction}\n`;
            }
            else {
                code += `${outputName}.iloc[:, ${columnName}] = ${inputName}.iloc[:, ${columnName}].${conversionFunction}\n`;
            }
        }
        return code;
    }
}


/***/ }),

/***/ "./lib/components/transforms/Unite.js":
/*!********************************************!*\
  !*** ./lib/components/transforms/Unite.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Unite: () => (/* binding */ Unite)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../icons */ "./lib/icons.js");
/* harmony import */ var _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../BaseCoreComponent */ "./lib/components/BaseCoreComponent.js");


class Unite extends _BaseCoreComponent__WEBPACK_IMPORTED_MODULE_0__.BaseCoreComponent {
    constructor() {
        const defaultConfig = { ignoreIndex: true, sort: false, concatDirection: "horizontal" };
        const form = {
            idPrefix: "component__form",
            fields: [
                {
                    type: "radio",
                    label: "Concatenation direction",
                    id: "concatDirection",
                    tooltip: "Select whether you want to concatenate the datasets vertically (stacking rows) or horizontally (side-by-side columns).",
                    options: [
                        { value: "horizontal", label: "Along columns (horizontal)" },
                        { value: "vertical", label: "Along rows (vertical)" }
                    ],
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Ignore Index",
                    tooltip: "Enable this option to reindex the combined dataset.",
                    id: "ignoreIndex",
                    advanced: true
                },
                {
                    type: "boolean",
                    label: "Sort",
                    tooltip: "Disable this option to prevent automatic sorting of columns.",
                    id: "sort",
                    advanced: true
                }
            ],
        };
        const description = "Use Concatenate to combine two or more datasets vertically (stacking rows) or horizontally (side-by-side columns).";
        super("Concatenate", "concat", description, "pandas_df_multi_processor", [], "transforms", _icons__WEBPACK_IMPORTED_MODULE_1__.plusCircleIcon, defaultConfig, form);
    }
    provideImports({ config }) {
        return ["import pandas as pd"];
    }
    generateComponentCode({ config, inputNames, outputName }) {
        var _a, _b;
        const prefix = (_b = (_a = config === null || config === void 0 ? void 0 : config.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
        const ignoreIndex = config.ignoreIndex !== undefined ? `, ignore_index=${config.ignoreIndex ? 'True' : 'False'}` : '';
        const sort = config.sort !== undefined ? `, sort=${config.sort ? 'True' : 'False'}` : '';
        const concatDirection = config.concatDirection === "horizontal"
            ? ", axis=1"
            : config.concatDirection === "vertical"
                ? ", axis=0"
                : "";
        const dataframesList = inputNames.join(', ');
        const code = `
# Concatenate dataframes
${outputName} = ${prefix}.concat([${dataframesList}]${ignoreIndex}${sort}${concatDirection})
`;
        return code;
    }
}


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   activityIcon: () => (/* binding */ activityIcon),
/* harmony export */   aggregateIcon: () => (/* binding */ aggregateIcon),
/* harmony export */   annotationIcon: () => (/* binding */ annotationIcon),
/* harmony export */   apiIcon: () => (/* binding */ apiIcon),
/* harmony export */   azureServicesIcon: () => (/* binding */ azureServicesIcon),
/* harmony export */   bigQueryIcon: () => (/* binding */ bigQueryIcon),
/* harmony export */   boxIcon: () => (/* binding */ boxIcon),
/* harmony export */   bracesIcon: () => (/* binding */ bracesIcon),
/* harmony export */   calendarIcon: () => (/* binding */ calendarIcon),
/* harmony export */   changeCircleIcon: () => (/* binding */ changeCircleIcon),
/* harmony export */   checkDiamondIcon: () => (/* binding */ checkDiamondIcon),
/* harmony export */   chromaIcon: () => (/* binding */ chromaIcon),
/* harmony export */   codeIcon: () => (/* binding */ codeIcon),
/* harmony export */   crosshairIcon: () => (/* binding */ crosshairIcon),
/* harmony export */   databaseIcon: () => (/* binding */ databaseIcon),
/* harmony export */   dedupIcon: () => (/* binding */ dedupIcon),
/* harmony export */   editIcon: () => (/* binding */ editIcon),
/* harmony export */   engineIcon: () => (/* binding */ engineIcon),
/* harmony export */   expandIcon: () => (/* binding */ expandIcon),
/* harmony export */   expandJsonIcon: () => (/* binding */ expandJsonIcon),
/* harmony export */   extractIcon: () => (/* binding */ extractIcon),
/* harmony export */   eyeIcon: () => (/* binding */ eyeIcon),
/* harmony export */   fileCsvIcon: () => (/* binding */ fileCsvIcon),
/* harmony export */   fileExcelIcon: () => (/* binding */ fileExcelIcon),
/* harmony export */   fileJsonIcon: () => (/* binding */ fileJsonIcon),
/* harmony export */   fileParquetIcon: () => (/* binding */ fileParquetIcon),
/* harmony export */   filePdfIcon: () => (/* binding */ filePdfIcon),
/* harmony export */   filePlusIcon: () => (/* binding */ filePlusIcon),
/* harmony export */   fileTextIcon: () => (/* binding */ fileTextIcon),
/* harmony export */   filterIcon: () => (/* binding */ filterIcon),
/* harmony export */   formexampletypescriptIcon: () => (/* binding */ formexampletypescriptIcon),
/* harmony export */   globeIcon: () => (/* binding */ globeIcon),
/* harmony export */   googleSheetsIcon: () => (/* binding */ googleSheetsIcon),
/* harmony export */   hashIcon: () => (/* binding */ hashIcon),
/* harmony export */   htmlIcon: () => (/* binding */ htmlIcon),
/* harmony export */   htmlLineIcon: () => (/* binding */ htmlLineIcon),
/* harmony export */   keyIcon: () => (/* binding */ keyIcon),
/* harmony export */   lockIcon: () => (/* binding */ lockIcon),
/* harmony export */   markdownIcon: () => (/* binding */ markdownIcon),
/* harmony export */   mergeIcon: () => (/* binding */ mergeIcon),
/* harmony export */   monitorIcon: () => (/* binding */ monitorIcon),
/* harmony export */   mySQLIcon: () => (/* binding */ mySQLIcon),
/* harmony export */   openAiIcon: () => (/* binding */ openAiIcon),
/* harmony export */   oracleIcon: () => (/* binding */ oracleIcon),
/* harmony export */   pineconeIcon: () => (/* binding */ pineconeIcon),
/* harmony export */   pivotIcon: () => (/* binding */ pivotIcon),
/* harmony export */   playCircleIcon: () => (/* binding */ playCircleIcon),
/* harmony export */   plusCircleIcon: () => (/* binding */ plusCircleIcon),
/* harmony export */   postgresIcon: () => (/* binding */ postgresIcon),
/* harmony export */   randomIcon: () => (/* binding */ randomIcon),
/* harmony export */   redditIcon: () => (/* binding */ redditIcon),
/* harmony export */   s3Icon: () => (/* binding */ s3Icon),
/* harmony export */   settingsIcon: () => (/* binding */ settingsIcon),
/* harmony export */   snowflakeIcon: () => (/* binding */ snowflakeIcon),
/* harmony export */   sortIcon: () => (/* binding */ sortIcon),
/* harmony export */   splitIcon: () => (/* binding */ splitIcon),
/* harmony export */   sqlServerIcon: () => (/* binding */ sqlServerIcon),
/* harmony export */   sumIcon: () => (/* binding */ sumIcon),
/* harmony export */   transposeIcon: () => (/* binding */ transposeIcon),
/* harmony export */   trinoIcon: () => (/* binding */ trinoIcon),
/* harmony export */   typeIcon: () => (/* binding */ typeIcon),
/* harmony export */   unlockIcon: () => (/* binding */ unlockIcon),
/* harmony export */   xIcon: () => (/* binding */ xIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_Azure_services_svg__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! ../style/icons/Azure-services.svg */ "./style/icons/Azure-services.svg");
/* harmony import */ var _style_icons_file_text_24_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../style/icons/file-text-24.svg */ "./style/icons/file-text-24.svg");
/* harmony import */ var _style_icons_file_plus_24_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/icons/file-plus-24.svg */ "./style/icons/file-plus-24.svg");
/* harmony import */ var _style_icons_monitor_24_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/icons/monitor-24.svg */ "./style/icons/monitor-24.svg");
/* harmony import */ var _style_icons_outline_24_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../style/icons/outline-24.svg */ "./style/icons/outline-24.svg");
/* harmony import */ var _style_icons_api_24_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../style/icons/api-24.svg */ "./style/icons/api-24.svg");
/* harmony import */ var _style_icons_code_24_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../style/icons/code-24.svg */ "./style/icons/code-24.svg");
/* harmony import */ var _style_icons_filter_24_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../style/icons/filter-24.svg */ "./style/icons/filter-24.svg");
/* harmony import */ var _style_icons_collections_24_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../style/icons/collections-24.svg */ "./style/icons/collections-24.svg");
/* harmony import */ var _style_icons_network_alt_24_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../style/icons/network-alt-24.svg */ "./style/icons/network-alt-24.svg");
/* harmony import */ var _style_icons_duplicate_24_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../style/icons/duplicate-24.svg */ "./style/icons/duplicate-24.svg");
/* harmony import */ var _style_icons_crop_24_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../style/icons/crop-24.svg */ "./style/icons/crop-24.svg");
/* harmony import */ var _style_icons_globe_24_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../style/icons/globe-24.svg */ "./style/icons/globe-24.svg");
/* harmony import */ var _style_icons_sort_desc_24_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../style/icons/sort-desc-24.svg */ "./style/icons/sort-desc-24.svg");
/* harmony import */ var _style_icons_edit_24_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../style/icons/edit-24.svg */ "./style/icons/edit-24.svg");
/* harmony import */ var _style_icons_type_24_svg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../style/icons/type-24.svg */ "./style/icons/type-24.svg");
/* harmony import */ var _style_icons_scissors_24_svg__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../style/icons/scissors-24.svg */ "./style/icons/scissors-24.svg");
/* harmony import */ var _style_icons_google_sheets_color_24_svg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../style/icons/google-sheets-color-24.svg */ "./style/icons/google-sheets-color-24.svg");
/* harmony import */ var _style_icons_mysql_svg__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../style/icons/mysql.svg */ "./style/icons/mysql.svg");
/* harmony import */ var _style_icons_box_16_svg__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../style/icons/box-16.svg */ "./style/icons/box-16.svg");
/* harmony import */ var _style_icons_reddit_svg__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../style/icons/reddit.svg */ "./style/icons/reddit.svg");
/* harmony import */ var _style_icons_git_merge_24_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../style/icons/git-merge-24.svg */ "./style/icons/git-merge-24.svg");
/* harmony import */ var _style_icons_crosshair_24_svg__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../style/icons/crosshair-24.svg */ "./style/icons/crosshair-24.svg");
/* harmony import */ var _style_icons_random_24_svg__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../style/icons/random-24.svg */ "./style/icons/random-24.svg");
/* harmony import */ var _style_icons_openai_svg__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../style/icons/openai.svg */ "./style/icons/openai.svg");
/* harmony import */ var _style_icons_postgres_svg__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../style/icons/postgres.svg */ "./style/icons/postgres.svg");
/* harmony import */ var _style_icons_pinecone_svg__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ../style/icons/pinecone.svg */ "./style/icons/pinecone.svg");
/* harmony import */ var _style_icons_change_circle_24_svg__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../style/icons/change-circle-24.svg */ "./style/icons/change-circle-24.svg");
/* harmony import */ var _style_icons_braces_svg__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ../style/icons/braces.svg */ "./style/icons/braces.svg");
/* harmony import */ var _style_icons_html_svg__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ../style/icons/html.svg */ "./style/icons/html.svg");
/* harmony import */ var _style_icons_markdown_fill_svg__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../style/icons/markdown-fill.svg */ "./style/icons/markdown-fill.svg");
/* harmony import */ var _style_icons_html_line_svg__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../style/icons/html-line.svg */ "./style/icons/html-line.svg");
/* harmony import */ var _style_icons_chroma_svg__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ../style/icons/chroma.svg */ "./style/icons/chroma.svg");
/* harmony import */ var _style_icons_check_diamond_24_svg__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ../style/icons/check-diamond-24.svg */ "./style/icons/check-diamond-24.svg");
/* harmony import */ var _style_icons_plus_circle_24_svg__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ../style/icons/plus-circle-24.svg */ "./style/icons/plus-circle-24.svg");
/* harmony import */ var _style_icons_hash_24_svg__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ../style/icons/hash-24.svg */ "./style/icons/hash-24.svg");
/* harmony import */ var _style_icons_oracle_svg__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ../style/icons/oracle.svg */ "./style/icons/oracle.svg");
/* harmony import */ var _style_icons_sql_server_svg__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ../style/icons/sql-server.svg */ "./style/icons/sql-server.svg");
/* harmony import */ var _style_icons_play_circle_16_svg__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ../style/icons/play-circle-16.svg */ "./style/icons/play-circle-16.svg");
/* harmony import */ var _style_icons_settings_16_svg__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../style/icons/settings-16.svg */ "./style/icons/settings-16.svg");
/* harmony import */ var _style_icons_key_24_svg__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ../style/icons/key-24.svg */ "./style/icons/key-24.svg");
/* harmony import */ var _style_icons_snowflake_svg__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ../style/icons/snowflake.svg */ "./style/icons/snowflake.svg");
/* harmony import */ var _style_icons_trino_svg__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ../style/icons/trino.svg */ "./style/icons/trino.svg");
/* harmony import */ var _style_icons_sum_svg__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ../style/icons/sum.svg */ "./style/icons/sum.svg");
/* harmony import */ var _style_icons_service_16_svg__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ../style/icons/service-16.svg */ "./style/icons/service-16.svg");
/* harmony import */ var _style_icons_s3_svg__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ../style/icons/s3.svg */ "./style/icons/s3.svg");
/* harmony import */ var _style_icons_bigquery_svg__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ../style/icons/bigquery.svg */ "./style/icons/bigquery.svg");
/* harmony import */ var _style_icons_database_24_svg__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ../style/icons/database-24.svg */ "./style/icons/database-24.svg");
/* harmony import */ var _style_icons_x_16_svg__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ../style/icons/x-16.svg */ "./style/icons/x-16.svg");
/* harmony import */ var _style_icons_calendar_24_svg__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ../style/icons/calendar-24.svg */ "./style/icons/calendar-24.svg");
/* harmony import */ var _style_icons_corner_up_right_24_svg__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ../style/icons/corner-up-right-24.svg */ "./style/icons/corner-up-right-24.svg");
/* harmony import */ var _style_icons_corner_right_down_24_svg__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ../style/icons/corner-right-down-24.svg */ "./style/icons/corner-right-down-24.svg");
/* harmony import */ var _style_icons_eye_24_svg__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ../style/icons/eye-24.svg */ "./style/icons/eye-24.svg");
/* harmony import */ var _style_icons_lock_16_svg__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ../style/icons/lock-16.svg */ "./style/icons/lock-16.svg");
/* harmony import */ var _style_icons_unlock_16_svg__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ../style/icons/unlock-16.svg */ "./style/icons/unlock-16.svg");
/* harmony import */ var _style_icons_sidebar_show_24_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../style/icons/sidebar-show-24.svg */ "./style/icons/sidebar-show-24.svg");
/* harmony import */ var _style_icons_file_csv_24_svg__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! ../style/icons/file-csv-24.svg */ "./style/icons/file-csv-24.svg");
/* harmony import */ var _style_icons_file_pdf_24_svg__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! ../style/icons/file-pdf-24.svg */ "./style/icons/file-pdf-24.svg");
/* harmony import */ var _style_icons_file_excel_24_svg__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! ../style/icons/file-excel-24.svg */ "./style/icons/file-excel-24.svg");
/* harmony import */ var _style_icons_file_parquet_24_svg__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! ../style/icons/file-parquet-24.svg */ "./style/icons/file-parquet-24.svg");
/* harmony import */ var _style_icons_file_json_24_svg__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! ../style/icons/file-json-24.svg */ "./style/icons/file-json-24.svg");
/* harmony import */ var _style_icons_activity_24_svg__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! ../style/icons/activity-24.svg */ "./style/icons/activity-24.svg");
/* harmony import */ var _style_icons_form_example_typescript_24_svg__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! ../style/icons/form-example-typescript-24.svg */ "./style/icons/form-example-typescript-24.svg");
































































const expandJsonIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:expand-icon',
    svgstr: _style_icons_sidebar_show_24_svg__WEBPACK_IMPORTED_MODULE_1__
});
const fileTextIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:file-text-icon',
    svgstr: _style_icons_file_text_24_svg__WEBPACK_IMPORTED_MODULE_2__
});
const filePlusIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:file-plus-icon',
    svgstr: _style_icons_file_plus_24_svg__WEBPACK_IMPORTED_MODULE_3__
});
const monitorIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:monitor-icon',
    svgstr: _style_icons_monitor_24_svg__WEBPACK_IMPORTED_MODULE_4__
});
const annotationIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:annotation-icon',
    svgstr: _style_icons_outline_24_svg__WEBPACK_IMPORTED_MODULE_5__
});
const apiIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:api-icon',
    svgstr: _style_icons_api_24_svg__WEBPACK_IMPORTED_MODULE_6__
});
const codeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:code-icon',
    svgstr: _style_icons_code_24_svg__WEBPACK_IMPORTED_MODULE_7__
});
const filterIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:filter-icon',
    svgstr: _style_icons_filter_24_svg__WEBPACK_IMPORTED_MODULE_8__
});
const aggregateIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:aggregateIcon',
    svgstr: _style_icons_collections_24_svg__WEBPACK_IMPORTED_MODULE_9__
});
const mergeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:mergeIcon',
    svgstr: _style_icons_git_merge_24_svg__WEBPACK_IMPORTED_MODULE_10__
});
const expandIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:expandIcon',
    svgstr: _style_icons_network_alt_24_svg__WEBPACK_IMPORTED_MODULE_11__
});
const dedupIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:dedupIcon',
    svgstr: _style_icons_duplicate_24_svg__WEBPACK_IMPORTED_MODULE_12__
});
const globeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:globeIcon',
    svgstr: _style_icons_globe_24_svg__WEBPACK_IMPORTED_MODULE_13__
});
const sortIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:sortIcon',
    svgstr: _style_icons_sort_desc_24_svg__WEBPACK_IMPORTED_MODULE_14__
});
const editIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:editIcon',
    svgstr: _style_icons_edit_24_svg__WEBPACK_IMPORTED_MODULE_15__
});
const typeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:typeIcon',
    svgstr: _style_icons_type_24_svg__WEBPACK_IMPORTED_MODULE_16__
});
const extractIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:extractIcon',
    svgstr: _style_icons_crop_24_svg__WEBPACK_IMPORTED_MODULE_17__
});
const splitIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:splitIcon',
    svgstr: _style_icons_scissors_24_svg__WEBPACK_IMPORTED_MODULE_18__
});
const googleSheetsIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:googleSheetsIcon',
    svgstr: _style_icons_google_sheets_color_24_svg__WEBPACK_IMPORTED_MODULE_19__
});
const mySQLIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:mySQLIcon',
    svgstr: _style_icons_mysql_svg__WEBPACK_IMPORTED_MODULE_20__
});
const boxIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:box-icon',
    svgstr: _style_icons_box_16_svg__WEBPACK_IMPORTED_MODULE_21__
});
const redditIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:redditIcon',
    svgstr: _style_icons_reddit_svg__WEBPACK_IMPORTED_MODULE_22__
});
const crosshairIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:crosshairIcon',
    svgstr: _style_icons_crosshair_24_svg__WEBPACK_IMPORTED_MODULE_23__
});
const randomIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:randomIcon',
    svgstr: _style_icons_random_24_svg__WEBPACK_IMPORTED_MODULE_24__
});
const openAiIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:openAiIcon',
    svgstr: _style_icons_openai_svg__WEBPACK_IMPORTED_MODULE_25__
});
const settingsIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:settings-config-icon',
    svgstr: _style_icons_settings_16_svg__WEBPACK_IMPORTED_MODULE_26__
});
const postgresIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:postgres-icon',
    svgstr: _style_icons_postgres_svg__WEBPACK_IMPORTED_MODULE_27__
});
const pineconeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:pinecone-icon',
    svgstr: _style_icons_pinecone_svg__WEBPACK_IMPORTED_MODULE_28__
});
const changeCircleIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:changeCircle-icon',
    svgstr: _style_icons_change_circle_24_svg__WEBPACK_IMPORTED_MODULE_29__
});
const bracesIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:braces-icon',
    svgstr: _style_icons_braces_svg__WEBPACK_IMPORTED_MODULE_30__
});
const htmlIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:html-icon',
    svgstr: _style_icons_html_svg__WEBPACK_IMPORTED_MODULE_31__
});
const markdownIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:markdown-icon',
    svgstr: _style_icons_markdown_fill_svg__WEBPACK_IMPORTED_MODULE_32__
});
const htmlLineIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:htmlLine-icon',
    svgstr: _style_icons_html_line_svg__WEBPACK_IMPORTED_MODULE_33__
});
const chromaIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:chroma-icon',
    svgstr: _style_icons_chroma_svg__WEBPACK_IMPORTED_MODULE_34__
});
const transposeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:transpose-icon',
    svgstr: _style_icons_corner_right_down_24_svg__WEBPACK_IMPORTED_MODULE_35__
});
const pivotIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:pivot-icon',
    svgstr: _style_icons_corner_up_right_24_svg__WEBPACK_IMPORTED_MODULE_36__
});
const checkDiamondIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:check-diamond-icon',
    svgstr: _style_icons_check_diamond_24_svg__WEBPACK_IMPORTED_MODULE_37__
});
const plusCircleIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:plus-circle-icon',
    svgstr: _style_icons_plus_circle_24_svg__WEBPACK_IMPORTED_MODULE_38__
});
const hashIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:hash-icon',
    svgstr: _style_icons_hash_24_svg__WEBPACK_IMPORTED_MODULE_39__
});
const oracleIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:oracle-icon',
    svgstr: _style_icons_oracle_svg__WEBPACK_IMPORTED_MODULE_40__
});
const sqlServerIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:sqlServer-icon',
    svgstr: _style_icons_sql_server_svg__WEBPACK_IMPORTED_MODULE_41__
});
const playCircleIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:play-circle-icon',
    svgstr: _style_icons_play_circle_16_svg__WEBPACK_IMPORTED_MODULE_42__
});
const keyIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:key-icon',
    svgstr: _style_icons_key_24_svg__WEBPACK_IMPORTED_MODULE_43__
});
const snowflakeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:snowflake-icon',
    svgstr: _style_icons_snowflake_svg__WEBPACK_IMPORTED_MODULE_44__
});
const trinoIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:trino-icon',
    svgstr: _style_icons_trino_svg__WEBPACK_IMPORTED_MODULE_45__
});
const sumIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:sum-icon',
    svgstr: _style_icons_sum_svg__WEBPACK_IMPORTED_MODULE_46__
});
const engineIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:engine-icon',
    svgstr: _style_icons_service_16_svg__WEBPACK_IMPORTED_MODULE_47__
});
const s3Icon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:s3-icon',
    svgstr: _style_icons_s3_svg__WEBPACK_IMPORTED_MODULE_48__
});
const bigQueryIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:bigQuery-icon',
    svgstr: _style_icons_bigquery_svg__WEBPACK_IMPORTED_MODULE_49__
});
const databaseIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:database-icon',
    svgstr: _style_icons_database_24_svg__WEBPACK_IMPORTED_MODULE_50__
});
const xIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:cog-icon',
    svgstr: _style_icons_x_16_svg__WEBPACK_IMPORTED_MODULE_51__
});
const calendarIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:calendar-icon',
    svgstr: _style_icons_calendar_24_svg__WEBPACK_IMPORTED_MODULE_52__
});
const eyeIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:eye-icon',
    svgstr: _style_icons_eye_24_svg__WEBPACK_IMPORTED_MODULE_53__
});
const lockIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:lock-icon',
    svgstr: _style_icons_lock_16_svg__WEBPACK_IMPORTED_MODULE_54__
});
const unlockIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:unlock-icon',
    svgstr: _style_icons_unlock_16_svg__WEBPACK_IMPORTED_MODULE_55__
});
// Files
const fileCsvIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:file-csv-icon',
    svgstr: _style_icons_file_csv_24_svg__WEBPACK_IMPORTED_MODULE_56__
});
const filePdfIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:file-pdf-icon',
    svgstr: _style_icons_file_pdf_24_svg__WEBPACK_IMPORTED_MODULE_57__
});
const fileJsonIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:file-json-icon',
    svgstr: _style_icons_file_json_24_svg__WEBPACK_IMPORTED_MODULE_58__
});
const fileExcelIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:file-excel-icon',
    svgstr: _style_icons_file_excel_24_svg__WEBPACK_IMPORTED_MODULE_59__
});
const fileParquetIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:file-parquet-icon',
    svgstr: _style_icons_file_parquet_24_svg__WEBPACK_IMPORTED_MODULE_60__
});
const activityIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:activity-icon',
    svgstr: _style_icons_activity_24_svg__WEBPACK_IMPORTED_MODULE_61__
});
const formexampletypescriptIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:form-example-typescript-icon',
    svgstr: _style_icons_form_example_typescript_24_svg__WEBPACK_IMPORTED_MODULE_62__
});
const azureServicesIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:Azure-services-icon',
    svgstr: _style_icons_Azure_services_svg__WEBPACK_IMPORTED_MODULE_63__
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Aggregate: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_1__.Aggregate),
/* harmony export */   Annotation: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_38__.Annotation),
/* harmony export */   AzureBlobFileInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_54__.AzureBlobFileInput),
/* harmony export */   AzureBlobFileOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_55__.AzureBlobFileOutput),
/* harmony export */   Connection: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_48__.Connection),
/* harmony export */   Console: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_2__.Console),
/* harmony export */   CsvFileInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_4__.CsvFileInput),
/* harmony export */   CsvFileOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_8__.CsvFileOutput),
/* harmony export */   CustomInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_59__.CustomInput),
/* harmony export */   CustomOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_60__.CustomOutput),
/* harmony export */   CustomTransformations: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_9__.CustomTransformations),
/* harmony export */   DataCleansing: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_44__.DataCleansing),
/* harmony export */   DateTimeConverter: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_32__.DateTimeConverter),
/* harmony export */   Deduplicate: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_13__.Deduplicate),
/* harmony export */   EnvFile: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_34__.EnvFile),
/* harmony export */   EnvVariables: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_33__.EnvVariables),
/* harmony export */   ExcelFileInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_7__.ExcelFileInput),
/* harmony export */   ExcelFileOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_3__.ExcelFileOutput),
/* harmony export */   ExpandList: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_14__.ExpandList),
/* harmony export */   Extract: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_19__.Extract),
/* harmony export */   FileUtils: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_61__.FileUtils),
/* harmony export */   Filter: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_10__.Filter),
/* harmony export */   FilterColumns: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_22__.FilterColumns),
/* harmony export */   FlattenJSON: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_43__.FlattenJSON),
/* harmony export */   FormExample: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_63__.FormExample),
/* harmony export */   FormulaRow: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_50__.FormulaRow),
/* harmony export */   FrequencyAnalysis: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_62__.FrequencyAnalysis),
/* harmony export */   GenerateIDColumn: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_45__.GenerateIDColumn),
/* harmony export */   GoogleSheetsInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_20__.GoogleSheetsInput),
/* harmony export */   GoogleSheetsOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_21__.GoogleSheetsOutput),
/* harmony export */   InlineInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_51__.InlineInput),
/* harmony export */   Join: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_23__.Join),
/* harmony export */   JsonFileInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_5__.JsonFileInput),
/* harmony export */   JsonFileOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_6__.JsonFileOutput),
/* harmony export */   LocalFileInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_42__.LocalFileInput),
/* harmony export */   MySQLInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_28__.MySQLInput),
/* harmony export */   MySQLOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_29__.MySQLOutput),
/* harmony export */   ODBCInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_39__.ODBCInput),
/* harmony export */   OracleInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_47__.OracleInput),
/* harmony export */   OracleOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_58__.OracleOutput),
/* harmony export */   ParquetFileInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_24__.ParquetFileInput),
/* harmony export */   ParquetFileOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_25__.ParquetFileOutput),
/* harmony export */   PdfTablesInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_40__.PdfTablesInput),
/* harmony export */   Pivot: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_37__.Pivot),
/* harmony export */   PostgresInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_26__.PostgresInput),
/* harmony export */   PostgresOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_27__.PostgresOutput),
/* harmony export */   RenameColumns: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_17__.RenameColumns),
/* harmony export */   RestInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_11__.RestInput),
/* harmony export */   S3FileInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_53__.S3FileInput),
/* harmony export */   S3FileOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_52__.S3FileOutput),
/* harmony export */   Sample: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_15__.Sample),
/* harmony export */   SnowflakeInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_49__.SnowflakeInput),
/* harmony export */   SnowflakeOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_56__.SnowflakeOutput),
/* harmony export */   Sort: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_16__.Sort),
/* harmony export */   SplitColumn: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_12__.SplitColumn),
/* harmony export */   SqlServerInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_46__.SqlServerInput),
/* harmony export */   SqlServerOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_57__.SqlServerOutput),
/* harmony export */   Summary: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_41__.Summary),
/* harmony export */   Transpose: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_35__.Transpose),
/* harmony export */   TypeConverter: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_18__.TypeConverter),
/* harmony export */   Unite: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_36__.Unite),
/* harmony export */   XmlFileInput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_30__.XmlFileInput),
/* harmony export */   XmlFileOutput: () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_31__.XmlFileOutput),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @amphi/pipeline-components-manager */ "webpack/sharing/consume/default/@amphi/pipeline-components-manager");
/* harmony import */ var _amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Aggregate.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/Console.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/files/ExcelFileOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/CsvFileInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/JsonFileInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/files/JsonFileOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/ExcelFileInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/files/CsvFileOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components */ "./lib/components/custom/CustomTransformations.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Filter.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/cloud/RestInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/SplitColumn.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Deduplicate.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/JSON/ExpandList.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Sample.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Sort.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/RenameColumns.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/TypeConverter.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Extract.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/cloud/GoogleSheetsInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/cloud/GoogleSheetsOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/FilterColumns.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Join.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/ParquetFileInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/files/ParquetFileOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/databases/PostgresInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/databases/PostgresOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/databases/MySQLInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/databases/MySQLOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/XmlFileInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/files/XmlFileOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/DateTimeConverter.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./components */ "./lib/components/settings/EnvVariables.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./components */ "./lib/components/settings/EnvFile.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Transpose.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Unite.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Pivot.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./components */ "./lib/components/annotations/Annotation.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/databases/ODBCInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/PdfTablesInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/Summary.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/LocalFileInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/JSON/FlattenJSON.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/DataCleansing.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/GenerateIDColumn.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/databases/SqlServerInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/databases/OracleInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./components */ "./lib/components/settings/Connection.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/databases/SnowflakeInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/FormulaRow.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/InlineInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/files/S3FileOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/S3FileInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ./components */ "./lib/components/inputs/files/AzureBlobFileInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/files/AzureBlobFileOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/databases/SnowflakeOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/databases/SqlServerOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! ./components */ "./lib/components/outputs/databases/OracleOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! ./components */ "./lib/components/custom/CustomInput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! ./components */ "./lib/components/custom/CustomOutput.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! ./components */ "./lib/components/common/FileUtils.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! ./components */ "./lib/components/transforms/FrequencyAnalysis.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! ./components */ "./lib/components/developer/FormExample.js");

// Import allow to add the component to the palette

// Export allow the component to be used as a base component in different packages

const plugin = {
    id: '@amphi/pipeline-components-core',
    description: 'Add components to Amphi',
    autoStart: true,
    requires: [_amphi_pipeline_components_manager__WEBPACK_IMPORTED_MODULE_0__.ComponentManager],
    activate: (app, componentService) => {
        console.log('Amphi extension pipeline-components-core is activated!');
        // Settings
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_33__.EnvVariables.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_34__.EnvFile.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_48__.Connection.getInstance());
        // Input
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_51__.InlineInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_4__.CsvFileInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_7__.ExcelFileInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_24__.ParquetFileInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_5__.JsonFileInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_30__.XmlFileInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_40__.PdfTablesInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_53__.S3FileInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_54__.AzureBlobFileInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_11__.RestInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_20__.GoogleSheetsInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_28__.MySQLInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_26__.PostgresInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_47__.OracleInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_46__.SqlServerInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_49__.SnowflakeInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_39__.ODBCInput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_59__.CustomInput.getInstance());
        // componentService.addComponent(PyGWalker.getInstance())
        // componentService.addComponent(Slider.getInstance())
        // Processors
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_17__.RenameColumns.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_22__.FilterColumns.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_10__.Filter.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_16__.Sort.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_12__.SplitColumn.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_19__.Extract.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_14__.ExpandList.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_43__.FlattenJSON.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_50__.FormulaRow.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_23__.Join.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_36__.Unite.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_1__.Aggregate.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_37__.Pivot.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_35__.Transpose.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_13__.Deduplicate.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_18__.TypeConverter.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_32__.DateTimeConverter.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_44__.DataCleansing.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_15__.Sample.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_9__.CustomTransformations.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_45__.GenerateIDColumn.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_41__.Summary.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_62__.FrequencyAnalysis.getInstance());
        // Outputs
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_8__.CsvFileOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_6__.JsonFileOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_3__.ExcelFileOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_25__.ParquetFileOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_31__.XmlFileOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_21__.GoogleSheetsOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_52__.S3FileOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_55__.AzureBlobFileOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_29__.MySQLOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_27__.PostgresOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_2__.Console.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_56__.SnowflakeOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_57__.SqlServerOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_58__.OracleOutput.getInstance());
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_60__.CustomOutput.getInstance());
        // Documentation
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_38__.Annotation.getInstance());
        // Developer
        componentService.addComponent(_components__WEBPACK_IMPORTED_MODULE_63__.FormExample.getInstance());
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./style/icons/Azure-services.svg":
/*!****************************************!*\
  !*** ./style/icons/Azure-services.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M5.33492 1.37491C5.44717 1.04229 5.75909 0.818359 6.11014 0.818359H11.25L5.91513 16.6255C5.80287 16.9581 5.49095 17.182 5.13991 17.182H1.13968C0.579936 17.182 0.185466 16.6325 0.364461 16.1022L5.33492 1.37491Z\" fill=\"url(#paint0_linear_6102_134469)\" /><path d=\"M13.5517 11.4546H5.45126C5.1109 11.4546 4.94657 11.8715 5.19539 12.1037L10.4005 16.9618C10.552 17.1032 10.7515 17.1819 10.9587 17.1819H15.5453L13.5517 11.4546Z\" fill=\"#0078D4\" /><path d=\"M6.11014 0.818359C5.75909 0.818359 5.44717 1.04229 5.33492 1.37491L0.364461 16.1022C0.185466 16.6325 0.579936 17.182 1.13968 17.182H5.13991C5.49095 17.182 5.80287 16.9581 5.91513 16.6255L6.90327 13.6976L10.4005 16.9617C10.552 17.1032 10.7515 17.1818 10.9588 17.1818H15.5454L13.5517 11.4545H7.66032L11.25 0.818359H6.11014Z\" fill=\"url(#paint1_linear_6102_134469)\" /><path d=\"M12.665 1.37478C12.5528 1.04217 12.2409 0.818237 11.8898 0.818237H6.13629H6.16254C6.51358 0.818237 6.82551 1.04217 6.93776 1.37478L11.9082 16.1021C12.0872 16.6324 11.6927 17.1819 11.133 17.1819H11.0454H16.8603C17.42 17.1819 17.8145 16.6324 17.6355 16.1021L12.665 1.37478Z\" fill=\"url(#paint2_linear_6102_134469)\" /><defs><linearGradient id=\"paint0_linear_6102_134469\" x1=\"6.07512\" y1=\"1.38476\" x2=\"0.738178\" y2=\"17.1514\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#114A8B\" /><stop offset=\"1\" stop-color=\"#0669BC\" /></linearGradient><linearGradient id=\"paint1_linear_6102_134469\" x1=\"10.3402\" y1=\"11.4564\" x2=\"9.107\" y2=\"11.8734\" gradientUnits=\"userSpaceOnUse\"><stop stop-opacity=\"0.3\" /><stop offset=\"0.0711768\" stop-opacity=\"0.2\" /><stop offset=\"0.321031\" stop-opacity=\"0.1\" /><stop offset=\"0.623053\" stop-opacity=\"0.05\" /><stop offset=\"1\" stop-opacity=\"0\" /></linearGradient><linearGradient id=\"paint2_linear_6102_134469\" x1=\"9.45858\" y1=\"1.38467\" x2=\"15.3168\" y2=\"16.9926\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#3CCBF4\" /><stop offset=\"1\" stop-color=\"#2892DF\" /></linearGradient></defs></svg>";

/***/ }),

/***/ "./style/icons/activity-24.svg":
/*!*************************************!*\
  !*** ./style/icons/activity-24.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M9.003 2a.75.75 0 01.71.519l5.278 16.27 2.294-7.265A.75.75 0 0118 11h4a.75.75 0 010 1.5h-3.45l-2.835 8.976a.75.75 0 01-1.428.005L8.99 5.151l-2.278 6.836A.75.75 0 016 12.5H2A.75.75 0 012 11h3.46l2.828-8.487A.75.75 0 019.003 2z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/api-24.svg":
/*!********************************!*\
  !*** ./style/icons/api-24.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M2 5a3 3 0 115.585 1.524l1.79 1.79.68-.68a2.75 2.75 0 013.89 0l.68.68 1.79-1.79a3 3 0 111.06 1.06l-1.79 1.791.681.68a2.75 2.75 0 010 3.89l-.68.68 1.79 1.79a3 3 0 11-1.06 1.06l-1.791-1.79-.68.681a2.75 2.75 0 01-3.89 0l-.68-.68-1.79 1.79a3 3 0 11-1.06-1.06l1.79-1.791-.681-.68a2.75 2.75 0 010-3.89l.68-.68-1.79-1.79A3 3 0 012 5zm3-1.5a1.5 1.5 0 100 3 1.5 1.5 0 000-3zm0 14a1.5 1.5 0 100 3 1.5 1.5 0 000-3zM17.5 19a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM19 3.5a1.5 1.5 0 100 3 1.5 1.5 0 000-3zm-7.884 5.195a1.25 1.25 0 011.768 0l2.421 2.421a1.25 1.25 0 010 1.768l-2.421 2.421a1.25 1.25 0 01-1.768 0l-2.421-2.421a1.25 1.25 0 010-1.768l2.421-2.421z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/bigquery.svg":
/*!**********************************!*\
  !*** ./style/icons/bigquery.svg ***!
  \**********************************/
/***/ ((module) => {

module.exports = "<svg height=\"2500\" width=\"2500\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"-1.633235433328256 7.0326093303156565 131.26574682416876 114.63439066968435\"><linearGradient id=\"a\" gradientUnits=\"userSpaceOnUse\" x1=\"64\" x2=\"64\" y1=\"7.034\" y2=\"120.789\"><stop offset=\"0\" stop-color=\"#4387fd\"/><stop offset=\"1\" stop-color=\"#4683ea\"/></linearGradient><path d=\"M27.79 115.217L1.54 69.749a11.499 11.499 0 0 1 0-11.499l26.25-45.467a11.5 11.5 0 0 1 9.96-5.75h52.5a11.5 11.5 0 0 1 9.959 5.75l26.25 45.467a11.499 11.499 0 0 1 0 11.5l-26.25 45.467a11.5 11.5 0 0 1-9.959 5.749h-52.5a11.499 11.499 0 0 1-9.96-5.75z\" fill=\"url(#a)\"/><path clip-path=\"url(#b)\" d=\"M119.229 86.48L80.625 47.874 64 43.425l-14.933 5.55L43.3 64l4.637 16.729 40.938 40.938 8.687-.386z\" opacity=\".07\"/><g fill=\"#fff\"><path d=\"M64 40.804c-12.81 0-23.195 10.385-23.195 23.196 0 12.81 10.385 23.195 23.195 23.195S87.194 76.81 87.194 64c0-12.811-10.385-23.196-23.194-23.196m0 40.795c-9.72 0-17.6-7.88-17.6-17.6S54.28 46.4 64 46.4 81.6 54.28 81.6 64 73.72 81.6 64 81.6\"/><path d=\"M52.99 63.104v7.21a12.794 12.794 0 0 0 4.38 4.475V63.104zM61.675 57.026v19.411c.745.137 1.507.22 2.29.22.714 0 1.41-.075 2.093-.189V57.026zM70.766 66.1v8.562a12.786 12.786 0 0 0 4.382-4.7v-3.861zM80.691 78.287l-2.403 2.405a1.088 1.088 0 0 0 0 1.537l9.115 9.112a1.088 1.088 0 0 0 1.537 0l2.403-2.402a1.092 1.092 0 0 0 0-1.536l-9.116-9.116a1.09 1.09 0 0 0-1.536 0\"/></g></svg>";

/***/ }),

/***/ "./style/icons/box-16.svg":
/*!********************************!*\
  !*** ./style/icons/box-16.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M6.98.678a2.25 2.25 0 012.04 0l5.297 2.696c.42.214.683.644.683 1.114v6.717c0 .658-.37 1.261-.956 1.56L9.02 15.322a2.25 2.25 0 01-2.042 0l-5.023-2.557A1.75 1.75 0 011 11.205V4.488c0-.47.264-.9.683-1.114L6.979.678zm1.36 1.337a.75.75 0 00-.68 0L3.224 4.273 8 6.661l4.776-2.388L8.34 2.015zm-5.84 9.19V5.588l4.75 2.375v5.814l-4.613-2.35a.25.25 0 01-.137-.222zm6.25 2.572l4.613-2.35a.25.25 0 00.137-.222V5.588L8.75 7.963v5.814z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/braces.svg":
/*!********************************!*\
  !*** ./style/icons/braces.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M4 18V14.3C4 13.4716 3.32843 12.8 2.5 12.8H2V11.2H2.5C3.32843 11.2 4 10.5284 4 9.7V6C4 4.34315 5.34315 3 7 3H8V5H7C6.44772 5 6 5.44772 6 6V10.1C6 10.9858 5.42408 11.7372 4.62623 12C5.42408 12.2628 6 13.0142 6 13.9V18C6 18.5523 6.44772 19 7 19H8V21H7C5.34315 21 4 19.6569 4 18ZM20 14.3V18C20 19.6569 18.6569 21 17 21H16V19H17C17.5523 19 18 18.5523 18 18V13.9C18 13.0142 18.5759 12.2628 19.3738 12C18.5759 11.7372 18 10.9858 18 10.1V6C18 5.44772 17.5523 5 17 5H16V3H17C18.6569 3 20 4.34315 20 6V9.7C20 10.5284 20.6716 11.2 21.5 11.2H22V12.8H21.5C20.6716 12.8 20 13.4716 20 14.3Z\"></path></svg>";

/***/ }),

/***/ "./style/icons/calendar-24.svg":
/*!*************************************!*\
  !*** ./style/icons/calendar-24.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M17 1a.75.75 0 00-1.5 0v1h-7V1A.75.75 0 007 1v1H4.75A2.75 2.75 0 002 4.75v14.5A2.75 2.75 0 004.75 22h14.5A2.75 2.75 0 0022 19.25V4.75A2.75 2.75 0 0019.25 2H17V1zm3.5 7V4.75c0-.69-.56-1.25-1.25-1.25H17V5a.75.75 0 01-1.5 0V3.5h-7V5A.75.75 0 017 5V3.5H4.75c-.69 0-1.25.56-1.25 1.25V8h17zm-17 1.5h17v9.75c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25V9.5z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/change-circle-24.svg":
/*!******************************************!*\
  !*** ./style/icons/change-circle-24.svg ***!
  \******************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M7.071 12.486c.056-.065.116-.143.182-.229.284-.366.677-.874 1.264-1.128a1.5 1.5 0 011.117-.041c.46.152 1.064.539 1.795 1.398.84.988 1.66 1.583 2.465 1.85a2.998 2.998 0 002.185-.089c1.012-.438 1.715-1.388 1.933-1.682.028-.038.048-.066.06-.08a.75.75 0 00-1.143-.97 6.64 6.64 0 00-.182.227c-.284.367-.677.875-1.264 1.129a1.5 1.5 0 01-1.117.041c-.46-.152-1.064-.539-1.795-1.398-.84-.988-1.66-1.584-2.465-1.85a2.998 2.998 0 00-2.185.089c-1.012.438-1.715 1.388-1.933 1.682-.028.038-.048.066-.06.08a.75.75 0 101.143.97z\"/><path fill-rule=\"evenodd\" d=\"M12 1C5.925 1 1 5.925 1 12s4.925 11 11 11 11-4.925 11-11S18.075 1 12 1zM2.5 12a9.5 9.5 0 1119 0 9.5 9.5 0 01-19 0z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/check-diamond-24.svg":
/*!******************************************!*\
  !*** ./style/icons/check-diamond-24.svg ***!
  \******************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M16.28 8.72a.75.75 0 010 1.06l-5.5 5.5a.75.75 0 01-1.06 0l-2.5-2.5a.75.75 0 011.06-1.06l1.97 1.97 4.97-4.97a.75.75 0 011.06 0z\"/><path fill-rule=\"evenodd\" d=\"M1.884 10.056l8.171-8.172a2.75 2.75 0 013.89 0l8.171 8.172a2.75 2.75 0 010 3.889l-8.171 8.171a2.75 2.75 0 01-3.89 0l-8.171-8.171a2.75 2.75 0 010-3.89zm9.232-7.111l-8.172 8.171a1.25 1.25 0 000 1.768l8.172 8.172a1.25 1.25 0 001.768 0l8.171-8.172a1.25 1.25 0 000-1.768l-8.171-8.171a1.25 1.25 0 00-1.768 0z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/chroma.svg":
/*!********************************!*\
  !*** ./style/icons/chroma.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<svg width=\"256px\" height=\"164px\" viewBox=\"0 0 256 164\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"  preserveAspectRatio=\"xMidYMid\">\n    <title>Chroma</title>\n    <g>\n        <ellipse fill=\"#FFDE2D\" cx=\"170.666795\" cy=\"81.9198362\" rx=\"85.3332053\" ry=\"81.9198362\"></ellipse>\n        <ellipse fill=\"#327EFF\" cx=\"85.3332053\" cy=\"81.9198362\" rx=\"85.3332053\" ry=\"81.9198362\"></ellipse>\n        <path d=\"M170.666795,81.9199642 C170.666795,127.163394 132.461431,163.83916 85.3330773,163.83916 L85.3330773,81.9199642 L170.666795,81.9199642 Z M85.3332053,81.9198362 C85.3332053,36.6767906 123.538185,8.95998209e-05 170.666795,8.95998209e-05 L170.666795,81.9198362 L85.3332053,81.9198362 Z\" fill=\"#FF6446\"></path>\n    </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/code-24.svg":
/*!*********************************!*\
  !*** ./style/icons/code-24.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M14.447 3.026a.75.75 0 00-.92.527l-4.5 16.5a.75.75 0 001.447.394l4.5-16.5a.75.75 0 00-.527-.92zM16.207 6.232a.75.75 0 011.06-.025l5.5 5.25a.75.75 0 010 1.085l-5.5 5.25a.75.75 0 01-1.035-1.085L21.164 12l-4.932-4.707a.75.75 0 01-.024-1.06zM7.768 7.293a.75.75 0 00-1.036-1.086l-5.5 5.25a.75.75 0 000 1.085l5.5 5.25a.75.75 0 101.036-1.085L2.836 12l4.932-4.707z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/collections-24.svg":
/*!****************************************!*\
  !*** ./style/icons/collections-24.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M5 6.75A.75.75 0 015.75 6h6.5a.75.75 0 010 1.5h-6.5A.75.75 0 015 6.75zM5.75 9a.75.75 0 000 1.5h4.5a.75.75 0 000-1.5h-4.5z\"/><path fill-rule=\"evenodd\" d=\"M1 4.75A2.75 2.75 0 013.75 2h10.5c.854 0 1.617.39 2.121 1h.879c.854 0 1.617.39 2.121 1h.879A2.75 2.75 0 0123 6.75v10.5A2.75 2.75 0 0120.25 20h-.879c-.504.61-1.267 1-2.121 1h-.879c-.504.61-1.267 1-2.121 1H3.75A2.75 2.75 0 011 19.25V4.75zM19.989 18.5h.261c.69 0 1.25-.56 1.25-1.25V6.75c0-.69-.56-1.25-1.25-1.25h-.261c.007.082.011.166.011.25v12.5c0 .084-.004.168-.011.25zM17 4.75c0-.084-.004-.168-.011-.25h.261c.69 0 1.25.56 1.25 1.25v12.5c0 .69-.56 1.25-1.25 1.25h-.261c.007-.082.011-.166.011-.25V4.75zM3.75 3.5c-.69 0-1.25.56-1.25 1.25v14.5c0 .69.56 1.25 1.25 1.25h10.5c.69 0 1.25-.56 1.25-1.25V4.75c0-.69-.56-1.25-1.25-1.25H3.75z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/corner-right-down-24.svg":
/*!**********************************************!*\
  !*** ./style/icons/corner-right-down-24.svg ***!
  \**********************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"M3.75 2.5a.75.75 0 000 1.5h7c.847 0 1.669.357 2.282 1.009.615.653.968 1.549.968 2.491v10.878l-3.957-4.146a.75.75 0 00-1.086 1.036l5.25 5.5a.75.75 0 001.085 0l5.25-5.5a.75.75 0 00-1.085-1.036L15.5 18.378V7.5c0-1.312-.49-2.579-1.375-3.52A4.634 4.634 0 0010.75 2.5h-7z\"/></svg>";

/***/ }),

/***/ "./style/icons/corner-up-right-24.svg":
/*!********************************************!*\
  !*** ./style/icons/corner-up-right-24.svg ***!
  \********************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"M14.232 13.957a.75.75 0 001.036 1.085l5.5-5.25a.75.75 0 000-1.085l-5.5-5.25a.75.75 0 00-1.036 1.086L18.378 8.5H7.5c-1.312 0-2.579.49-3.52 1.375A4.634 4.634 0 002.5 13.25v7a.75.75 0 001.5 0v-7c0-.847.357-1.669 1.009-2.282A3.639 3.639 0 017.5 10h10.878l-4.146 3.957z\"/></svg>";

/***/ }),

/***/ "./style/icons/crop-24.svg":
/*!*********************************!*\
  !*** ./style/icons/crop-24.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M6.5 1.25a.75.75 0 00-1.5 0V5H1.25a.75.75 0 000 1.5H5v9.75A2.75 2.75 0 007.75 19h9.75v3.75a.75.75 0 001.5 0V19h3.75a.75.75 0 000-1.5H19V7.75A2.75 2.75 0 0016.25 5H6.5V1.25zm0 5.25v9.75a1.25 1.25 0 001.25 1.25h9.75V7.75a1.25 1.25 0 00-1.25-1.25H6.5z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/crosshair-24.svg":
/*!**************************************!*\
  !*** ./style/icons/crosshair-24.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M1 12C1 5.925 5.925 1 12 1s11 4.925 11 11-4.925 11-11 11S1 18.075 1 12zm11.75 9.47v-2.72a.75.75 0 00-1.5 0v2.72a9.502 9.502 0 01-8.72-8.72h2.72a.75.75 0 000-1.5H2.53a9.502 9.502 0 018.72-8.72v2.72a.75.75 0 001.5 0V2.53a9.502 9.502 0 018.72 8.72h-2.72a.75.75 0 000 1.5h2.72a9.502 9.502 0 01-8.72 8.72z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/database-24.svg":
/*!*************************************!*\
  !*** ./style/icons/database-24.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M22 5.75c0-.751-.47-1.34-1.02-1.763-.563-.43-1.329-.787-2.208-1.072C17.005 2.342 14.611 2 12 2c-2.61 0-5.005.342-6.772.915-.88.285-1.646.641-2.207 1.072C2.469 4.41 2 5 2 5.75v12.412c0 .752.454 1.352 1.006 1.79.56.445 1.325.812 2.204 1.106 1.766.59 4.163.942 6.79.942s5.024-.352 6.79-.942c.88-.294 1.644-.66 2.204-1.105.552-.439 1.006-1.039 1.006-1.791V5.75zM3.933 5.177c-.385.296-.433.496-.433.573 0 .077.048.277.433.573.374.286.963.577 1.758.835C7.27 7.67 9.502 8 12 8s4.729-.33 6.31-.842c.794-.258 1.383-.549 1.757-.835.385-.296.433-.496.433-.573 0-.077-.048-.277-.433-.573-.375-.286-.963-.577-1.758-.835C16.73 3.83 14.498 3.5 12 3.5s-4.729.33-6.31.842c-.794.258-1.383.549-1.757.835zM20.5 7.835c-.49.29-1.078.539-1.728.75-1.767.573-4.161.915-6.772.915-2.61 0-5.005-.342-6.772-.915-.65-.211-1.238-.46-1.728-.75v3.915c0 .08.05.281.43.575.372.287.957.577 1.75.834C7.256 13.671 9.486 14 12 14c2.514 0 4.744-.329 6.32-.84.793-.258 1.378-.549 1.75-.835.38-.294.43-.495.43-.575V7.835zm0 6.005c-.486.288-1.07.536-1.716.746-1.764.573-4.159.914-6.784.914s-5.02-.341-6.784-.914c-.646-.21-1.23-.458-1.716-.746v4.322c0 .102.06.315.439.616.371.295.956.593 1.747.857 1.574.527 3.802.865 6.314.865s4.74-.338 6.314-.865c.791-.264 1.376-.563 1.747-.857.379-.3.439-.514.439-.616V13.84z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/duplicate-24.svg":
/*!**************************************!*\
  !*** ./style/icons/duplicate-24.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M3.75 1A2.75 2.75 0 001 3.75v10.5A2.75 2.75 0 003.75 17h1a.75.75 0 000-1.5h-1c-.69 0-1.25-.56-1.25-1.25V3.75c0-.69.56-1.25 1.25-1.25h10.5c.69 0 1.25.56 1.25 1.25v1a.75.75 0 001.5 0v-1A2.75 2.75 0 0014.25 1H3.75z\"/><path fill-rule=\"evenodd\" d=\"M9.75 7A2.75 2.75 0 007 9.75v10.5A2.75 2.75 0 009.75 23h10.5A2.75 2.75 0 0023 20.25V9.75A2.75 2.75 0 0020.25 7H9.75zM8.5 9.75c0-.69.56-1.25 1.25-1.25h10.5c.69 0 1.25.56 1.25 1.25v10.5c0 .69-.56 1.25-1.25 1.25H9.75c-.69 0-1.25-.56-1.25-1.25V9.75z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/edit-24.svg":
/*!*********************************!*\
  !*** ./style/icons/edit-24.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path fill-rule=\"evenodd\" d=\"M17.055 2.884a2.75 2.75 0 013.89 0l.171.171a2.75 2.75 0 010 3.89l-9.005 9.005A4.75 4.75 0 0110.516 17L6.28 18.696a.75.75 0 01-.975-.975l1.695-4.237a4.749 4.749 0 011.051-1.595l9.005-9.005zm2.829 1.06a1.25 1.25 0 00-1.768 0l-.555.556L19.5 6.44l.555-.556a1.25 1.25 0 000-1.768l-.171-.172zM18.439 7.5L16.5 5.56l-7.39 7.39a3.25 3.25 0 00-.719 1.09l-1.045 2.614 2.613-1.046a3.25 3.25 0 001.091-.719L18.44 7.5z\" clip-rule=\"evenodd\"/><path d=\"M3.75 4.5c-.69 0-1.25.56-1.25 1.25v14.5c0 .69.56 1.25 1.25 1.25h14.5c.69 0 1.25-.56 1.25-1.25V13a.75.75 0 011.5 0v7.25A2.75 2.75 0 0118.25 23H3.75A2.75 2.75 0 011 20.25V5.75A2.75 2.75 0 013.75 3H11a.75.75 0 010 1.5H3.75z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/eye-24.svg":
/*!********************************!*\
  !*** ./style/icons/eye-24.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\" fill-rule=\"evenodd\" clip-rule=\"evenodd\"><path d=\"M12 8a4 4 0 100 8 4 4 0 000-8zm-2.5 4a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0z\"/><path d=\"M12 3C8.135 3 5.14 5.088 3.15 7.162c-1.001 1.043-1.767 2.1-2.286 2.936-.26.417-.46.785-.6 1.074-.069.143-.127.275-.169.388a1.952 1.952 0 00-.058.177A1.024 1.024 0 000 12c0 .116.025.216.037.263.017.06.037.12.058.177.042.113.1.245.17.388.138.289.34.657.599 1.074a18.14 18.14 0 002.285 2.936C5.14 18.912 8.135 21 12 21c3.864 0 6.86-2.088 8.85-4.162 1.001-1.043 1.767-2.1 2.286-2.936.26-.417.46-.785.6-1.074.069-.143.127-.275.169-.388a1.98 1.98 0 00.058-.177c.012-.047.037-.147.037-.263 0-.116-.025-.216-.037-.263a1.98 1.98 0 00-.058-.177 4.709 4.709 0 00-.17-.388c-.139-.289-.34-.657-.599-1.074a18.146 18.146 0 00-2.285-2.936C18.86 5.088 15.865 3 12 3zM1.615 12.177a4.225 4.225 0 01-.08-.177c.02-.048.047-.107.08-.177.113-.233.287-.554.523-.934a16.641 16.641 0 012.093-2.688C6.076 6.28 8.705 4.5 12 4.5c3.294 0 5.924 1.78 7.768 3.701a16.639 16.639 0 012.094 2.688c.236.38.41.701.523.934.033.07.06.129.08.177a4.03 4.03 0 01-.08.177c-.113.233-.287.554-.523.934a16.639 16.639 0 01-2.093 2.688C17.924 17.72 15.294 19.5 12 19.5s-5.925-1.78-7.769-3.701a16.641 16.641 0 01-2.093-2.688c-.236-.38-.41-.701-.523-.934z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/file-csv-24.svg":
/*!*************************************!*\
  !*** ./style/icons/file-csv-24.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"24\"\n   height=\"24\"\n   fill=\"none\"\n   viewBox=\"0 0 24 24\"\n   version=\"1.1\"\n   id=\"svg2\"\n   sodipodi:docname=\"file-csv-24.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <defs\n     id=\"defs2\" />\n  <sodipodi:namedview\n     id=\"namedview2\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"8.0003289\"\n     inkscape:cx=\"15.124378\"\n     inkscape:cy=\"22.936557\"\n     inkscape:window-width=\"2560\"\n     inkscape:window-height=\"1412\"\n     inkscape:window-x=\"1512\"\n     inkscape:window-y=\"149\"\n     inkscape:window-maximized=\"1\"\n     inkscape:current-layer=\"svg2\" />\n  <g\n     fill=\"currentColor\"\n     id=\"g2\">\n    <path\n       fill-rule=\"evenodd\"\n       d=\"M5.75 1A2.75 2.75 0 003 3.75v16.5A2.75 2.75 0 005.75 23h12.5A2.75 2.75 0 0021 20.25V8.664c0-.464-.184-.909-.513-1.237l-5.914-5.914A1.75 1.75 0 0013.336 1H5.75zM4.5 3.75c0-.69.56-1.25 1.25-1.25H13v5.75c0 .414.336.75.75.75h5.75v11.25c0 .69-.56 1.25-1.25 1.25H5.75c-.69 0-1.25-.56-1.25-1.25V3.75zM18.44 7.5L14.5 3.56V7.5h3.94z\"\n       clip-rule=\"evenodd\"\n       id=\"path2\" />\n  </g>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:48px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#f9f9f9;stroke:#7d6ec2;stroke-width:0\"\n     x=\"18.610168\"\n     y=\"19.525423\"\n     id=\"text2\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan2\"></tspan></text>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:6.04823px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#008000;stroke:#7d6ec2;stroke-width:0\"\n     x=\"5.5070834\"\n     y=\"19.640993\"\n     id=\"text3\"\n     transform=\"scale(1.0124776,0.98767617)\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan3\"\n       x=\"5.5070834\"\n       y=\"19.640993\"\n       style=\"font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-family:Arial;-inkscape-font-specification:Arial;fill:#008000;stroke-width:0\">CSV</tspan></text>\n</svg>\n";

/***/ }),

/***/ "./style/icons/file-excel-24.svg":
/*!***************************************!*\
  !*** ./style/icons/file-excel-24.svg ***!
  \***************************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"24\"\n   height=\"24\"\n   fill=\"none\"\n   viewBox=\"0 0 24 24\"\n   version=\"1.1\"\n   id=\"svg2\"\n   sodipodi:docname=\"file-excel-24.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <defs\n     id=\"defs2\" />\n  <sodipodi:namedview\n     id=\"namedview2\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"8.0003289\"\n     inkscape:cx=\"15.124378\"\n     inkscape:cy=\"22.936557\"\n     inkscape:window-width=\"1312\"\n     inkscape:window-height=\"670\"\n     inkscape:window-x=\"118\"\n     inkscape:window-y=\"799\"\n     inkscape:window-maximized=\"0\"\n     inkscape:current-layer=\"svg2\" />\n  <g\n     fill=\"currentColor\"\n     id=\"g2\">\n    <path\n       fill-rule=\"evenodd\"\n       d=\"M 5.75,1 A 2.75,2.75 0 0 0 3,3.75 v 16.5 A 2.75,2.75 0 0 0 5.75,23 h 12.5 A 2.75,2.75 0 0 0 21,20.25 V 8.664 C 21,8.2 20.816,7.755 20.487,7.427 L 14.573,1.513 A 1.75,1.75 0 0 0 13.336,1 Z M 4.5,3.75 C 4.5,3.06 5.06,2.5 5.75,2.5 H 13 V 8.25 C 13,8.664 13.336,9 13.75,9 h 5.75 v 11.25 c 0,0.69 -0.56,1.25 -1.25,1.25 H 5.75 C 5.06,21.5 4.5,20.94 4.5,20.25 Z M 18.44,7.5 14.5,3.56 V 7.5 Z\"\n       clip-rule=\"evenodd\"\n       id=\"path2\" />\n  </g>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:48px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#f9f9f9;stroke:#7d6ec2;stroke-width:0\"\n     x=\"18.610168\"\n     y=\"19.525423\"\n     id=\"text2\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan2\"></tspan></text>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:4.95567px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#0f7a41;stroke:#7d6ec2;stroke-width:0;fill-opacity:1\"\n     x=\"7.4485302\"\n     y=\"19.389633\"\n     id=\"text3\"\n     transform=\"scale(0.99888384,1.0011174)\"\n     inkscape:transform-center-x=\"-0.74996916\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan3\"\n       x=\"7.4485302\"\n       y=\"19.389633\"\n       style=\"font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-family:Arial;-inkscape-font-specification:Arial;fill:#0f7a41;stroke-width:0;fill-opacity:1\">XLS</tspan></text>\n</svg>\n";

/***/ }),

/***/ "./style/icons/file-json-24.svg":
/*!**************************************!*\
  !*** ./style/icons/file-json-24.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"24\"\n   height=\"24\"\n   fill=\"none\"\n   viewBox=\"0 0 24 24\"\n   version=\"1.1\"\n   id=\"svg2\"\n   sodipodi:docname=\"file-json-24.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <defs\n     id=\"defs2\" />\n  <sodipodi:namedview\n     id=\"namedview2\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"8.0003289\"\n     inkscape:cx=\"15.124378\"\n     inkscape:cy=\"22.936557\"\n     inkscape:window-width=\"2560\"\n     inkscape:window-height=\"1412\"\n     inkscape:window-x=\"1512\"\n     inkscape:window-y=\"149\"\n     inkscape:window-maximized=\"1\"\n     inkscape:current-layer=\"svg2\" />\n  <g\n     fill=\"currentColor\"\n     id=\"g2\">\n    <path\n       fill-rule=\"evenodd\"\n       d=\"M 5.75,1 A 2.75,2.75 0 0 0 3,3.75 v 16.5 A 2.75,2.75 0 0 0 5.75,23 h 12.5 A 2.75,2.75 0 0 0 21,20.25 V 8.664 C 21,8.2 20.816,7.755 20.487,7.427 L 14.573,1.513 A 1.75,1.75 0 0 0 13.336,1 Z M 4.5,3.75 C 4.5,3.06 5.06,2.5 5.75,2.5 H 13 V 8.25 C 13,8.664 13.336,9 13.75,9 h 5.75 v 11.25 c 0,0.69 -0.56,1.25 -1.25,1.25 H 5.75 C 5.06,21.5 4.5,20.94 4.5,20.25 Z M 18.44,7.5 14.5,3.56 V 7.5 Z\"\n       clip-rule=\"evenodd\"\n       id=\"path2\" />\n  </g>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:48px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#f9f9f9;stroke:#7d6ec2;stroke-width:0\"\n     x=\"18.610168\"\n     y=\"19.525423\"\n     id=\"text2\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan2\"></tspan></text>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:4.95567px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#aa8800;stroke:#7d6ec2;stroke-width:0\"\n     x=\"5.5371022\"\n     y=\"19.389633\"\n     id=\"text3\"\n     transform=\"scale(0.99888384,1.0011174)\"\n     inkscape:transform-center-x=\"-0.74996916\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan3\"\n       x=\"5.5371022\"\n       y=\"19.389633\"\n       style=\"font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-family:Arial;-inkscape-font-specification:Arial;fill:#aa8800;stroke-width:0\">JSON</tspan></text>\n</svg>\n";

/***/ }),

/***/ "./style/icons/file-parquet-24.svg":
/*!*****************************************!*\
  !*** ./style/icons/file-parquet-24.svg ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"24\"\n   height=\"24\"\n   fill=\"none\"\n   viewBox=\"0 0 24 24\"\n   version=\"1.1\"\n   id=\"svg2\"\n   sodipodi:docname=\"file-parquet-24.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <defs\n     id=\"defs2\" />\n  <sodipodi:namedview\n     id=\"namedview2\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"8.0003289\"\n     inkscape:cx=\"15.124378\"\n     inkscape:cy=\"22.936557\"\n     inkscape:window-width=\"1312\"\n     inkscape:window-height=\"670\"\n     inkscape:window-x=\"118\"\n     inkscape:window-y=\"798\"\n     inkscape:window-maximized=\"0\"\n     inkscape:current-layer=\"svg2\" />\n  <g\n     fill=\"currentColor\"\n     id=\"g2\">\n    <path\n       fill-rule=\"evenodd\"\n       d=\"M 5.75,1 A 2.75,2.75 0 0 0 3,3.75 v 16.5 A 2.75,2.75 0 0 0 5.75,23 h 12.5 A 2.75,2.75 0 0 0 21,20.25 V 8.664 C 21,8.2 20.816,7.755 20.487,7.427 L 14.573,1.513 A 1.75,1.75 0 0 0 13.336,1 Z M 4.5,3.75 C 4.5,3.06 5.06,2.5 5.75,2.5 H 13 V 8.25 C 13,8.664 13.336,9 13.75,9 h 5.75 v 11.25 c 0,0.69 -0.56,1.25 -1.25,1.25 H 5.75 C 5.06,21.5 4.5,20.94 4.5,20.25 Z M 18.44,7.5 14.5,3.56 V 7.5 Z\"\n       clip-rule=\"evenodd\"\n       id=\"path2\" />\n  </g>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:48px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#f9f9f9;stroke:#7d6ec2;stroke-width:0\"\n     x=\"18.610168\"\n     y=\"19.525423\"\n     id=\"text2\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan2\"></tspan></text>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:4.13333px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#51acf1;fill-opacity:1;stroke:#7d6ec2;stroke-width:0\"\n     x=\"4.8830051\"\n     y=\"19.389633\"\n     id=\"text3\"\n     transform=\"scale(0.99888384,1.0011174)\"\n     inkscape:transform-center-x=\"-0.74996916\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan3\"\n       x=\"4.8830051\"\n       y=\"19.389633\"\n       style=\"font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:4.13333px;font-family:Arial;-inkscape-font-specification:Arial;fill:#51acf1;fill-opacity:1;stroke-width:0\">parquet</tspan></text>\n</svg>\n";

/***/ }),

/***/ "./style/icons/file-pdf-24.svg":
/*!*************************************!*\
  !*** ./style/icons/file-pdf-24.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"24\"\n   height=\"24\"\n   fill=\"none\"\n   viewBox=\"0 0 24 24\"\n   version=\"1.1\"\n   id=\"svg2\"\n   sodipodi:docname=\"file-pdf-24.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <defs\n     id=\"defs2\" />\n  <sodipodi:namedview\n     id=\"namedview2\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"8.0003289\"\n     inkscape:cx=\"15.124378\"\n     inkscape:cy=\"22.87406\"\n     inkscape:window-width=\"1512\"\n     inkscape:window-height=\"853\"\n     inkscape:window-x=\"0\"\n     inkscape:window-y=\"639\"\n     inkscape:window-maximized=\"1\"\n     inkscape:current-layer=\"svg2\" />\n  <g\n     fill=\"currentColor\"\n     id=\"g2\">\n    <path\n       fill-rule=\"evenodd\"\n       d=\"M5.75 1A2.75 2.75 0 003 3.75v16.5A2.75 2.75 0 005.75 23h12.5A2.75 2.75 0 0021 20.25V8.664c0-.464-.184-.909-.513-1.237l-5.914-5.914A1.75 1.75 0 0013.336 1H5.75zM4.5 3.75c0-.69.56-1.25 1.25-1.25H13v5.75c0 .414.336.75.75.75h5.75v11.25c0 .69-.56 1.25-1.25 1.25H5.75c-.69 0-1.25-.56-1.25-1.25V3.75zM18.44 7.5L14.5 3.56V7.5h3.94z\"\n       clip-rule=\"evenodd\"\n       id=\"path2\" />\n  </g>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:48px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#f9f9f9;stroke:#7d6ec2;stroke-width:0\"\n     x=\"18.610168\"\n     y=\"19.525423\"\n     id=\"text2\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan2\" /></text>\n  <text\n     xml:space=\"preserve\"\n     style=\"font-size:6.04823px;line-height:0;font-family:'Heiti SC';-inkscape-font-specification:'Heiti SC, Normal';fill:#d40000;stroke:#7d6ec2;stroke-width:0\"\n     x=\"5.7093801\"\n     y=\"19.640993\"\n     id=\"text3\"\n     transform=\"scale(1.0124776,0.98767617)\"><tspan\n       sodipodi:role=\"line\"\n       id=\"tspan3\"\n       x=\"5.7093801\"\n       y=\"19.640993\"\n       style=\"font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-family:Arial;-inkscape-font-specification:Arial;fill:#d40000;stroke-width:0\">PDF</tspan></text>\n</svg>\n";

/***/ }),

/***/ "./style/icons/file-plus-24.svg":
/*!**************************************!*\
  !*** ./style/icons/file-plus-24.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M11.75 10.75a.75.75 0 01.75.75V14H15a.75.75 0 010 1.5h-2.5V18a.75.75 0 01-1.5 0v-2.5H8.5a.75.75 0 010-1.5H11v-2.5a.75.75 0 01.75-.75z\"/><path fill-rule=\"evenodd\" d=\"M5.75 1A2.75 2.75 0 003 3.75v16.5A2.75 2.75 0 005.75 23h12.5A2.75 2.75 0 0021 20.25V8.664c0-.464-.184-.909-.513-1.237l-5.914-5.914A1.75 1.75 0 0013.336 1H5.75zM4.5 3.75c0-.69.56-1.25 1.25-1.25H13v5.75c0 .414.336.75.75.75h5.75v11.25c0 .69-.56 1.25-1.25 1.25H5.75c-.69 0-1.25-.56-1.25-1.25V3.75zM18.44 7.5L14.5 3.56V7.5h3.94z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/file-text-24.svg":
/*!**************************************!*\
  !*** ./style/icons/file-text-24.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M7.75 12a.75.75 0 000 1.5h8a.75.75 0 000-1.5h-8zM7 16.75a.75.75 0 01.75-.75h6a.75.75 0 010 1.5h-6a.75.75 0 01-.75-.75zM7.75 8a.75.75 0 000 1.5h2a.75.75 0 000-1.5h-2z\"/><path fill-rule=\"evenodd\" d=\"M3 3.75A2.75 2.75 0 015.75 1h7.586c.464 0 .909.184 1.237.513l5.914 5.914c.329.328.513.773.513 1.237V20.25A2.75 2.75 0 0118.25 23H5.75A2.75 2.75 0 013 20.25V3.75zM5.75 2.5c-.69 0-1.25.56-1.25 1.25v16.5c0 .69.56 1.25 1.25 1.25h12.5c.69 0 1.25-.56 1.25-1.25V9h-5.75a.75.75 0 01-.75-.75V2.5H5.75zm8.75 1.06l3.94 3.94H14.5V3.56z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/filter-24.svg":
/*!***********************************!*\
  !*** ./style/icons/filter-24.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M3 6.75A.75.75 0 013.75 6h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 6.75zM6 11.75a.75.75 0 01.75-.75h10.5a.75.75 0 010 1.5H6.75a.75.75 0 01-.75-.75zM9.75 16a.75.75 0 000 1.5h4.5a.75.75 0 000-1.5h-4.5z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/form-example-typescript-24.svg":
/*!****************************************************!*\
  !*** ./style/icons/form-example-typescript-24.svg ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\"  viewBox=\"0 0 50 50\" width=\"24px\" height=\"24px\"><path d=\"M 5 4 A 1.0001 1.0001 0 0 0 4 5 L 4 45 A 1.0001 1.0001 0 0 0 5 46 L 45 46 A 1.0001 1.0001 0 0 0 46 45 L 46 5 A 1.0001 1.0001 0 0 0 45 4 L 5 4 z M 6 6 L 44 6 L 44 44 L 6 44 L 6 6 z M 15 23 L 15 26.445312 L 20 26.445312 L 20 42 L 24 42 L 24 26.445312 L 29 26.445312 L 29 23 L 15 23 z M 36.691406 23.009766 C 33.576782 22.997369 30.017578 23.941219 30.017578 28.324219 C 30.017578 34.054219 37.738281 34.055625 37.738281 36.640625 C 37.738281 36.885625 37.842187 38.666016 35.117188 38.666016 C 32.392187 38.666016 30.121094 36.953125 30.121094 36.953125 L 30.121094 41.111328 C 30.121094 41.111328 42.001953 44.954062 42.001953 36.289062 C 42.000953 30.664063 34.208984 30.945391 34.208984 28.150391 C 34.208984 27.067391 34.978375 26.054687 37.109375 26.054688 C 39.240375 26.054688 41.126953 27.3125 41.126953 27.3125 L 41.267578 23.607422 C 41.267578 23.607422 39.113892 23.019408 36.691406 23.009766 z\"/></svg>";

/***/ }),

/***/ "./style/icons/git-merge-24.svg":
/*!**************************************!*\
  !*** ./style/icons/git-merge-24.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M3.5 6.5a3.5 3.5 0 114.096 3.45c.102.41.284.886.551 1.406a11.743 11.743 0 001.81 2.54c1.35 1.456 3.014 2.56 4.635 2.804a3.502 3.502 0 016.908.8 3.5 3.5 0 01-6.928.71c-2.178-.252-4.217-1.677-5.716-3.294A13.885 13.885 0 017.5 13.202v7.548a.75.75 0 01-1.5 0V9.855A3.502 3.502 0 013.5 6.5zm3.5-2a2 2 0 100 4 2 2 0 000-4zm9 13a2 2 0 104 0 2 2 0 00-4 0z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/globe-24.svg":
/*!**********************************!*\
  !*** ./style/icons/globe-24.svg ***!
  \**********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M12 1C5.925 1 1 5.925 1 12s4.925 11 11 11 11-4.925 11-11S18.075 1 12 1zm-1.673 1.647A9.506 9.506 0 002.552 11h4.747a16.673 16.673 0 013.028-8.353zm3.346 0A16.673 16.673 0 0116.701 11h4.747a9.506 9.506 0 00-7.775-8.353zM15.196 11A15.149 15.149 0 0012 2.916 15.149 15.149 0 008.804 11h6.392zm-6.427 1.5h6.462A15.16 15.16 0 0112 21.084 15.16 15.16 0 018.769 12.5zm-1.502 0H2.513c.23 4.45 3.525 8.091 7.814 8.853a16.683 16.683 0 01-3.06-8.853zm6.406 8.853a16.683 16.683 0 003.06-8.853h4.754c-.23 4.45-3.525 8.091-7.814 8.853z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/google-sheets-color-24.svg":
/*!************************************************!*\
  !*** ./style/icons/google-sheets-color-24.svg ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"#188038\" d=\"M14.266 2l4.984 5h-4.984V2z\"/><path fill=\"#34A853\" d=\"M14.266 7V2H6.109c-.75 0-1.359.61-1.359 1.364v17.272c0 .754.608 1.364 1.36 1.364h11.78c.752 0 1.36-.61 1.36-1.364V7h-4.984z\"/><path fill=\"#FDFFFF\" d=\"M7.469 9.727v6.591h9.062v-6.59H7.47zm3.965 5.455H8.602V13.59h2.832v1.59zm0-2.727H8.602v-1.591h2.832v1.59zm3.964 2.727h-2.832V13.59h2.832v1.59zm0-2.727h-2.832v-1.591h2.832v1.59z\"/></svg>";

/***/ }),

/***/ "./style/icons/hash-24.svg":
/*!*********************************!*\
  !*** ./style/icons/hash-24.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M10.363 3.009a.75.75 0 01.629.853L10.365 8h4.483l.66-4.362a.75.75 0 111.484.224L16.365 8h2.885a.75.75 0 010 1.5h-3.113l-.681 4.5h3.794a.75.75 0 010 1.5h-4.022l-.736 4.863a.75.75 0 11-1.483-.225l.702-4.638H9.228l-.736 4.863a.75.75 0 11-1.483-.225L7.71 15.5H4.75a.75.75 0 010-1.5h3.189l.681-4.5H4.75a.75.75 0 010-1.5h4.098l.66-4.362a.75.75 0 01.855-.63zM13.938 14l.682-4.5h-4.482L9.455 14h4.482z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/html-line.svg":
/*!***********************************!*\
  !*** ./style/icons/html-line.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 18.1778L7.38083 16.9222L7.0517 13.3778H9.32156L9.48045 15.2222L12 15.8889L14.5195 15.2222L14.7806 12.3556H6.96091L6.32535 5.67778H17.6747L17.4477 7.88889H8.82219L9.02648 10.1444H17.2434L16.6192 16.9222L12 18.1778ZM3 2H21L19.377 20L12 22L4.62295 20L3 2ZM5.18844 4L6.48986 18.4339L12 19.9278L17.5101 18.4339L18.8116 4H5.18844Z\"></path></svg>";

/***/ }),

/***/ "./style/icons/html.svg":
/*!******************************!*\
  !*** ./style/icons/html.svg ***!
  \******************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\">\r\n  <title>HTML5 Logo Badge</title>\r\n  <path fill=\"#E34F26\" d=\"M71,460 L30,0 481,0 440,460 255,512\"/>\r\n  <path fill=\"#EF652A\" d=\"M256,472 L405,431 440,37 256,37\"/>\r\n  <path fill=\"#EBEBEB\" d=\"M256,208 L181,208 176,150 256,150 256,94 255,94 114,94 115,109 129,265 256,265zM256,355 L255,355 192,338 188,293 158,293 132,293 139,382 255,414 256,414z\"/>\r\n  <path fill=\"#FFF\" d=\"M255,208 L255,265 325,265 318,338 255,355 255,414 371,382 372,372 385,223 387,208 371,208zM255,94 L255,129 255,150 255,150 392,150 392,150 392,150 393,138 396,109 397,94z\"/>\r\n</svg>\r\n";

/***/ }),

/***/ "./style/icons/key-24.svg":
/*!********************************!*\
  !*** ./style/icons/key-24.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\" fill-rule=\"evenodd\" clip-rule=\"evenodd\"><path d=\"M13.88 5.877A2.978 2.978 0 0116.001 5a2.999 2.999 0 11-2.772 4.148v-.002a2.992 2.992 0 01.651-3.27zm1.06 1.06a1.479 1.479 0 011.062-.437 1.499 1.499 0 11-1.387 2.072 1.492 1.492 0 01.324-1.633l.002-.001z\"/><path d=\"M14.307 1.068c.34-.047.684-.068 1.021-.068 2.049 0 3.98.799 5.429 2.247a7.72 7.72 0 012.176 6.444v.001a7.725 7.725 0 01-3.8 5.642 7.697 7.697 0 01-3.811 1.012 7.653 7.653 0 01-2.553-.437l-1.04 1.04c-.225.236-.54.37-.863.37H9.6v1.089c-.008.35-.146.675-.383.926l-.007.007a1.356 1.356 0 01-.97.408H7.155v1.22c.011.323-.11.63-.331.867l-.011.012-.007.006-.926.926a.75.75 0 01-.53.22H1.75a.75.75 0 01-.75-.75v-3.616a.75.75 0 01.22-.53l6.869-6.868a7.719 7.719 0 01.572-6.369 7.72 7.72 0 015.646-3.799zm.203 1.486c.267-.037.543-.054.818-.054 1.651 0 3.2.641 4.368 1.807a6.22 6.22 0 011.75 5.185 6.225 6.225 0 01-3.057 4.54 6.173 6.173 0 01-5.464.33.833.833 0 00-.904.175l-1.282 1.281H9.135c-.578 0-1.034.47-1.034 1.034v1.397H6.69c-.578 0-1.035.47-1.035 1.034v1.6l-.616.617H2.5v-2.555l6.955-6.954a.831.831 0 00.18-.915 6.217 6.217 0 01.328-5.464 6.22 6.22 0 014.544-3.057h.003z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/lock-16.svg":
/*!*********************************!*\
  !*** ./style/icons/lock-16.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><g fill=\"currentColor\"><path d=\"M8 9.25a.75.75 0 01.75.75v1a.75.75 0 01-1.5 0v-1A.75.75 0 018 9.25z\"/><path fill-rule=\"evenodd\" d=\"M4 5.014v-.93c0-1.078.417-2.114 1.165-2.881A3.96 3.96 0 018 0a3.96 3.96 0 012.835 1.203A4.127 4.127 0 0112 4.083v.93a2.25 2.25 0 012 2.237v5.5A2.25 2.25 0 0111.75 15h-7.5A2.25 2.25 0 012 12.75v-5.5a2.25 2.25 0 012-2.236zM6.239 2.25A2.46 2.46 0 018 1.5c.657 0 1.29.267 1.761.75.471.483.739 1.142.739 1.833V5h-5v-.917c0-.69.268-1.35.739-1.833zM11.75 6.5a.75.75 0 01.75.75v5.5a.75.75 0 01-.75.75h-7.5a.75.75 0 01-.75-.75v-5.5a.75.75 0 01.75-.75h7.5z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/markdown-fill.svg":
/*!***************************************!*\
  !*** ./style/icons/markdown-fill.svg ***!
  \***************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M3 3H21C21.5523 3 22 3.44772 22 4V20C22 20.5523 21.5523 21 21 21H3C2.44772 21 2 20.5523 2 20V4C2 3.44772 2.44772 3 3 3ZM7 15.5V11.5L9 13.5L11 11.5V15.5H13V8.5H11L9 10.5L7 8.5H5V15.5H7ZM18 12.5V8.5H16V12.5H14L17 15.5L20 12.5H18Z\"></path></svg>";

/***/ }),

/***/ "./style/icons/monitor-24.svg":
/*!************************************!*\
  !*** ./style/icons/monitor-24.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M1 4.75A2.75 2.75 0 013.75 2h16.5A2.75 2.75 0 0123 4.75v10.5A2.75 2.75 0 0120.25 18H12.5v2.5H16a.75.75 0 010 1.5H8a.75.75 0 010-1.5h3V18H3.75A2.75 2.75 0 011 15.25V4.75zM20.25 16.5c.69 0 1.25-.56 1.25-1.25V4.75c0-.69-.56-1.25-1.25-1.25H3.75c-.69 0-1.25.56-1.25 1.25v10.5c0 .69.56 1.25 1.25 1.25h16.5z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/mysql.svg":
/*!*******************************!*\
  !*** ./style/icons/mysql.svg ***!
  \*******************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"64\" height=\"64\" viewBox=\"0 0 25.6 25.6\"><path d=\"M179.076 94.886c-3.568-.1-6.336.268-8.656 1.25-.668.27-1.74.27-1.828 1.116.357.355.4.936.713 1.428.535.893 1.473 2.096 2.32 2.72l2.855 2.053c1.74 1.07 3.703 1.695 5.398 2.766.982.625 1.963 1.428 2.945 2.098.5.357.803.938 1.428 1.16v-.135c-.312-.4-.402-.98-.713-1.428l-1.34-1.293c-1.293-1.74-2.9-3.258-4.64-4.506-1.428-.982-4.55-2.32-5.13-3.97l-.088-.1c.98-.1 2.14-.447 3.078-.715 1.518-.4 2.9-.312 4.46-.713l2.143-.625v-.4c-.803-.803-1.383-1.874-2.23-2.632-2.275-1.963-4.775-3.882-7.363-5.488-1.383-.892-3.168-1.473-4.64-2.23-.537-.268-1.428-.402-1.74-.848-.805-.98-1.25-2.275-1.83-3.436l-3.658-7.763c-.803-1.74-1.295-3.48-2.275-5.086-4.596-7.585-9.594-12.18-17.268-16.687-1.65-.937-3.613-1.34-5.7-1.83l-3.346-.18c-.715-.312-1.428-1.16-2.053-1.562-2.543-1.606-9.102-5.086-10.977-.5-1.205 2.9 1.785 5.755 2.8 7.228.76 1.026 1.74 2.186 2.277 3.346.3.758.4 1.562.713 2.365.713 1.963 1.383 4.15 2.32 5.98.5.937 1.025 1.92 1.65 2.767.357.5.982.714 1.115 1.517-.625.893-.668 2.23-1.025 3.347-1.607 5.042-.982 11.288 1.293 15 .715 1.115 2.4 3.57 4.686 2.632 2.008-.803 1.56-3.346 2.14-5.577.135-.535.045-.892.312-1.25v.1l1.83 3.703c1.383 2.186 3.793 4.462 5.8 5.98 1.07.803 1.918 2.187 3.256 2.677v-.135h-.088c-.268-.4-.67-.58-1.027-.892-.803-.803-1.695-1.785-2.32-2.677-1.873-2.498-3.523-5.265-4.996-8.12-.715-1.383-1.34-2.9-1.918-4.283-.27-.536-.27-1.34-.715-1.606-.67.98-1.65 1.83-2.143 3.034-.848 1.918-.936 4.283-1.248 6.737-.18.045-.1 0-.18.1-1.426-.356-1.918-1.83-2.453-3.078-1.338-3.168-1.562-8.254-.402-11.913.312-.937 1.652-3.882 1.117-4.774-.27-.848-1.16-1.338-1.652-2.008-.58-.848-1.203-1.918-1.605-2.855-1.07-2.5-1.605-5.265-2.766-7.764-.537-1.16-1.473-2.365-2.232-3.435-.848-1.205-1.783-2.053-2.453-3.48-.223-.5-.535-1.294-.178-1.83.088-.357.268-.5.623-.58.58-.5 2.232.134 2.812.4 1.65.67 3.033 1.294 4.416 2.23.625.446 1.295 1.294 2.098 1.518h.938c1.428.312 3.033.1 4.37.5 2.365.76 4.506 1.874 6.426 3.08 5.844 3.703 10.664 8.968 13.92 15.26.535 1.026.758 1.963 1.25 3.034.938 2.187 2.098 4.417 3.033 6.56.938 2.097 1.83 4.24 3.168 5.98.67.937 3.346 1.427 4.55 1.918.893.4 2.275.76 3.08 1.25 1.516.937 3.033 2.008 4.46 3.034.713.534 2.945 1.65 3.078 2.54zm-45.5-38.772a7.09 7.09 0 0 0-1.828.223v.1h.088c.357.714.982 1.205 1.428 1.83l1.027 2.142.088-.1c.625-.446.938-1.16.938-2.23-.268-.312-.312-.625-.535-.937-.268-.446-.848-.67-1.206-1.026z\" transform=\"matrix(.390229 0 0 .38781 -46.300037 -16.856717)\" fill-rule=\"evenodd\" fill=\"#00678c\"/></svg>";

/***/ }),

/***/ "./style/icons/network-alt-24.svg":
/*!****************************************!*\
  !*** ./style/icons/network-alt-24.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M23 12a.75.75 0 00-.232-.543l-5.5-5.25a.75.75 0 00-1.036 1.086L21.164 12l-4.932 4.707a.75.75 0 001.036 1.085l5.5-5.25A.75.75 0 0023 12zM1 12a.75.75 0 01.232-.543l5.5-5.25a.75.75 0 111.036 1.086L2.836 12l4.932 4.707a.75.75 0 01-1.036 1.085l-5.5-5.25A.75.75 0 011 12z\"/><path d=\"M8 11a1 1 0 100 2h.01a1 1 0 100-2H8zM11 12a1 1 0 011-1h.01a1 1 0 110 2H12a1 1 0 01-1-1zM16 11a1 1 0 100 2h.01a1 1 0 100-2H16z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/openai.svg":
/*!********************************!*\
  !*** ./style/icons/openai.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"utf-8\"?><!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->\n<svg fill=\"#000000\" width=\"800px\" height=\"800px\" viewBox=\"0 0 24 24\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>OpenAI icon</title><path d=\"M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z\"/></svg>";

/***/ }),

/***/ "./style/icons/oracle.svg":
/*!********************************!*\
  !*** ./style/icons/oracle.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"24\"\n   height=\"24\"\n   version=\"1.1\"\n   id=\"svg1\"\n   viewBox=\"0 0 24 24\"\n   sodipodi:docname=\"oracle.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <defs\n     id=\"defs1\" />\n  <sodipodi:namedview\n     id=\"namedview1\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     labelstyle=\"below\"\n     inkscape:zoom=\"11.8\"\n     inkscape:cx=\"16.016949\"\n     inkscape:cy=\"15.381356\"\n     inkscape:window-width=\"2560\"\n     inkscape:window-height=\"1412\"\n     inkscape:window-x=\"1512\"\n     inkscape:window-y=\"149\"\n     inkscape:window-maximized=\"1\"\n     inkscape:current-layer=\"svg1\" />\n  <path\n     fill=\"none\"\n     stroke=\"#c74634\"\n     stroke-width=\"2.9935\"\n     d=\"m 7.5677778,6.0126423 a 5.9866678,5.9873577 0 1 0 0,11.9747157 h 8.9800012 a 5.9866678,5.9873577 0 1 0 0,-11.9747157 z\"\n     id=\"path1\" />\n</svg>\n";

/***/ }),

/***/ "./style/icons/outline-24.svg":
/*!************************************!*\
  !*** ./style/icons/outline-24.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M6.5 5.75A.75.75 0 017.25 5h.01a.75.75 0 010 1.5h-.01a.75.75 0 01-.75-.75zM7.25 9a.75.75 0 000 1.5h.01a.75.75 0 000-1.5h-.01zM6.5 13.75a.75.75 0 01.75-.75h.01a.75.75 0 010 1.5h-.01a.75.75 0 01-.75-.75zM7.25 17a.75.75 0 000 1.5h.01a.75.75 0 000-1.5h-.01zM9.5 9.75a.75.75 0 01.75-.75h4.5a.75.75 0 010 1.5h-4.5a.75.75 0 01-.75-.75zM10.25 5a.75.75 0 000 1.5h6.5a.75.75 0 000-1.5h-6.5zM9.5 13.75a.75.75 0 01.75-.75h6.5a.75.75 0 010 1.5h-6.5a.75.75 0 01-.75-.75zM10.25 17a.75.75 0 000 1.5h3.5a.75.75 0 000-1.5h-3.5z\"/><path fill-rule=\"evenodd\" d=\"M3 3.75A2.75 2.75 0 015.75 1h12.5A2.75 2.75 0 0121 3.75v16.5A2.75 2.75 0 0118.25 23H5.75A2.75 2.75 0 013 20.25V3.75zM5.75 2.5c-.69 0-1.25.56-1.25 1.25v16.5c0 .69.56 1.25 1.25 1.25h12.5c.69 0 1.25-.56 1.25-1.25V3.75c0-.69-.56-1.25-1.25-1.25H5.75z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/pinecone.svg":
/*!**********************************!*\
  !*** ./style/icons/pinecone.svg ***!
  \**********************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<svg width=\"256px\" height=\"288px\" viewBox=\"0 0 256 288\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"  preserveAspectRatio=\"xMidYMid\">\n    <title>Pinecone</title>\n    <g>\n        <path d=\"M108.633615,254.43629 C117.713862,254.43629 125.074857,261.797284 125.074857,270.877532 C125.074857,279.957779 117.713862,287.318774 108.633615,287.318774 C99.5533677,287.318774 92.1923728,279.957779 92.1923728,270.877532 C92.1923728,261.797284 99.5533677,254.43629 108.633615,254.43629 Z M199.849665,224.438339 L216.09705,229.252379 L203.199913,272.780219 C202.072982,276.58361 198.458049,279.095992 194.500389,278.826397 L190.516677,278.552973 L190.419263,278.633409 L149.02918,275.728903 L150.180842,258.822508 L177.989056,260.709686 L159.783784,234.447622 L173.709616,224.792379 L191.938895,251.08702 L199.849665,224.438339 Z M23.0126771,194.347476 L39.9158866,195.544979 L37.935897,223.348728 L64.1501315,205.120082 L73.8271476,219.030793 L47.578736,237.278394 L74.3707554,245.173037 L69.5818063,261.427835 L25.8485266,248.543243 C22.0304448,247.418369 19.5101155,243.787479 19.7913963,239.817092 L23.0126771,194.347476 Z M132.151306,170.671396 L162.658679,207.503468 L148.909247,218.891886 L130.753266,196.972134 L124.866941,230.673893 L107.280249,227.599613 L113.172232,193.845272 L88.7296311,208.256891 L79.6674587,192.874434 L120.745504,168.674377 C124.522104,166.449492 129.355297,167.295726 132.151306,170.671396 Z M217.504528,145.960198 L232.744017,137.668804 L254.94482,178.473633 C256.889641,182.048192 256.088221,186.494171 253.017682,189.164674 L249.876622,191.878375 L217.826246,219.77131 L206.441034,206.680621 L227.988588,187.934494 L195.893546,182.152609 L198.972402,165.078949 L231.044844,170.857793 L217.504528,145.960198 Z M37.7821805,103.299272 L49.2622123,116.306888 L28.0106317,135.050179 L60.1668233,140.664193 L57.1863573,157.755303 L24.9947229,152.136967 L38.822104,177.134576 L23.6411026,185.532577 L1.08439616,144.756992 C-0.885025494,141.196884 -0.115545265,136.746375 2.93488097,134.054184 L37.7821805,103.299272 Z M146.476311,89.8796828 L176.88045,126.612847 L163.1271,137.996532 L144.975445,116.067101 L139.08912,149.778947 L121.502428,146.704666 L127.374238,113.081452 L103.025237,127.354817 L93.9976317,111.952048 L131.398812,90.0233663 L131.435631,89.880899 L131.600545,89.9023265 L135.085833,87.870141 C138.861877,85.6569913 143.68556,86.5079996 146.476311,89.8796828 Z M185.655786,71.8143168 L192.305535,55.7902703 L235.318239,73.6399229 C239.072486,75.1978811 241.2415,79.1537636 240.536356,83.1568091 L239.820231,87.1385839 L232.47517,128.919545 L215.389188,125.909819 L220.312646,97.9413879 L191.776157,113.7129 L183.390302,98.5251862 L211.981072,82.7408038 L185.655786,71.8143168 Z M103.71696,40.2373824 L104.456513,57.5706533 L76.0432671,58.785006 L97.4730368,83.2749086 L84.4165529,94.6993319 L62.9507932,70.1728358 L57.949673,98.1737132 L40.8716575,95.1191088 L49.0561498,49.3603563 C49.771444,45.3612115 53.1664633,42.3942036 57.2253811,42.2210231 L61.246149,42.0411642 L61.3363168,41.9758 L103.71696,40.2373824 Z M161.838155,3.27194826 L192.104824,40.2369789 L178.291207,51.5474574 L160.327329,29.6043227 L154.268381,63.2715157 L136.697231,60.1096121 L142.766468,26.3665075 L118.24002,40.7062765 L109.232678,25.2916494 L150.427675,1.21987397 C154.218286,-0.995121237 159.056796,-0.124957814 161.838155,3.27194826 Z\" fill=\"#201D1E\"></path>\n    </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/play-circle-16.svg":
/*!****************************************!*\
  !*** ./style/icons/play-circle-16.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><g fill=\"currentColor\" fill-rule=\"evenodd\" clip-rule=\"evenodd\"><path d=\"M7.421 4.356A1.25 1.25 0 005.5 5.411v5.178a1.25 1.25 0 001.921 1.055l4.069-2.59a1.25 1.25 0 000-2.109L7.42 4.356zM10.353 8L7 10.134V5.866L10.353 8z\"/><path d=\"M8 0a8 8 0 100 16A8 8 0 008 0zM1.5 8a6.5 6.5 0 1113 0 6.5 6.5 0 01-13 0z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/plus-circle-24.svg":
/*!****************************************!*\
  !*** ./style/icons/plus-circle-24.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M11.75 6.75a.75.75 0 01.75.75V11H16a.75.75 0 010 1.5h-3.5V16a.75.75 0 01-1.5 0v-3.5H7.5a.75.75 0 010-1.5H11V7.5a.75.75 0 01.75-.75z\"/><path fill-rule=\"evenodd\" d=\"M1 11.75C1 5.813 5.813 1 11.75 1S22.5 5.813 22.5 11.75 17.687 22.5 11.75 22.5 1 17.687 1 11.75zM11.75 2.5a9.25 9.25 0 100 18.5 9.25 9.25 0 000-18.5z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/postgres.svg":
/*!**********************************!*\
  !*** ./style/icons/postgres.svg ***!
  \**********************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\"?>\r\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\"\r\n  \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\r\n\r\n<svg width=\"432.071pt\" height=\"445.383pt\" viewBox=\"0 0 432.071 445.383\" xml:space=\"preserve\" xmlns=\"http://www.w3.org/2000/svg\">\r\n<g id=\"orginal\" style=\"fill-rule:nonzero;clip-rule:nonzero;stroke:#000000;stroke-miterlimit:4;\">\r\n\t</g>\r\n<g id=\"Layer_x0020_3\" style=\"fill-rule:nonzero;clip-rule:nonzero;fill:none;stroke:#FFFFFF;stroke-width:12.4651;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;\">\r\n<path style=\"fill:#000000;stroke:#000000;stroke-width:37.3953;stroke-linecap:butt;stroke-linejoin:miter;\" d=\"M323.205,324.227c2.833-23.601,1.984-27.062,19.563-23.239l4.463,0.392c13.517,0.615,31.199-2.174,41.587-7c22.362-10.376,35.622-27.7,13.572-23.148c-50.297,10.376-53.755-6.655-53.755-6.655c53.111-78.803,75.313-178.836,56.149-203.322    C352.514-5.534,262.036,26.049,260.522,26.869l-0.482,0.089c-9.938-2.062-21.06-3.294-33.554-3.496c-22.761-0.374-40.032,5.967-53.133,15.904c0,0-161.408-66.498-153.899,83.628c1.597,31.936,45.777,241.655,98.47,178.31    c19.259-23.163,37.871-42.748,37.871-42.748c9.242,6.14,20.307,9.272,31.912,8.147l0.897-0.765c-0.281,2.876-0.157,5.689,0.359,9.019c-13.572,15.167-9.584,17.83-36.723,23.416c-27.457,5.659-11.326,15.734-0.797,18.367c12.768,3.193,42.305,7.716,62.268-20.224    l-0.795,3.188c5.325,4.26,4.965,30.619,5.72,49.452c0.756,18.834,2.017,36.409,5.856,46.771c3.839,10.36,8.369,37.05,44.036,29.406c29.809-6.388,52.6-15.582,54.677-101.107\"/>\r\n<path style=\"fill:#336791;stroke:none;\" d=\"M402.395,271.23c-50.302,10.376-53.76-6.655-53.76-6.655c53.111-78.808,75.313-178.843,56.153-203.326c-52.27-66.785-142.752-35.2-144.262-34.38l-0.486,0.087c-9.938-2.063-21.06-3.292-33.56-3.496c-22.761-0.373-40.026,5.967-53.127,15.902    c0,0-161.411-66.495-153.904,83.63c1.597,31.938,45.776,241.657,98.471,178.312c19.26-23.163,37.869-42.748,37.869-42.748c9.243,6.14,20.308,9.272,31.908,8.147l0.901-0.765c-0.28,2.876-0.152,5.689,0.361,9.019c-13.575,15.167-9.586,17.83-36.723,23.416    c-27.459,5.659-11.328,15.734-0.796,18.367c12.768,3.193,42.307,7.716,62.266-20.224l-0.796,3.188c5.319,4.26,9.054,27.711,8.428,48.969c-0.626,21.259-1.044,35.854,3.147,47.254c4.191,11.4,8.368,37.05,44.042,29.406c29.809-6.388,45.256-22.942,47.405-50.555    c1.525-19.631,4.976-16.729,5.194-34.28l2.768-8.309c3.192-26.611,0.507-35.196,18.872-31.203l4.463,0.392c13.517,0.615,31.208-2.174,41.591-7c22.358-10.376,35.618-27.7,13.573-23.148z\"/>\r\n<path d=\"M215.866,286.484c-1.385,49.516,0.348,99.377,5.193,111.495c4.848,12.118,15.223,35.688,50.9,28.045c29.806-6.39,40.651-18.756,45.357-46.051c3.466-20.082,10.148-75.854,11.005-87.281\"/>\r\n<path d=\"M173.104,38.256c0,0-161.521-66.016-154.012,84.109c1.597,31.938,45.779,241.664,98.473,178.316c19.256-23.166,36.671-41.335,36.671-41.335\"/>\r\n<path d=\"M260.349,26.207c-5.591,1.753,89.848-34.889,144.087,34.417c19.159,24.484-3.043,124.519-56.153,203.329\"/>\r\n<path style=\"stroke-linejoin:bevel;\" d=\"M348.282,263.953c0,0,3.461,17.036,53.764,6.653c22.04-4.552,8.776,12.774-13.577,23.155c-18.345,8.514-59.474,10.696-60.146-1.069c-1.729-30.355,21.647-21.133,19.96-28.739c-1.525-6.85-11.979-13.573-18.894-30.338    c-6.037-14.633-82.796-126.849,21.287-110.183c3.813-0.789-27.146-99.002-124.553-100.599c-97.385-1.597-94.19,119.762-94.19,119.762\"/>\r\n<path d=\"M188.604,274.334c-13.577,15.166-9.584,17.829-36.723,23.417c-27.459,5.66-11.326,15.733-0.797,18.365c12.768,3.195,42.307,7.718,62.266-20.229c6.078-8.509-0.036-22.086-8.385-25.547c-4.034-1.671-9.428-3.765-16.361,3.994z\"/>\r\n<path d=\"M187.715,274.069c-1.368-8.917,2.93-19.528,7.536-31.942c6.922-18.626,22.893-37.255,10.117-96.339c-9.523-44.029-73.396-9.163-73.436-3.193c-0.039,5.968,2.889,30.26-1.067,58.548c-5.162,36.913,23.488,68.132,56.479,64.938\"/>\r\n<path style=\"fill:#FFFFFF;stroke-width:4.155;stroke-linecap:butt;stroke-linejoin:miter;\" d=\"M172.517,141.7c-0.288,2.039,3.733,7.48,8.976,8.207c5.234,0.73,9.714-3.522,9.998-5.559c0.284-2.039-3.732-4.285-8.977-5.015c-5.237-0.731-9.719,0.333-9.996,2.367z\"/>\r\n<path style=\"fill:#FFFFFF;stroke-width:2.0775;stroke-linecap:butt;stroke-linejoin:miter;\" d=\"M331.941,137.543c0.284,2.039-3.732,7.48-8.976,8.207c-5.238,0.73-9.718-3.522-10.005-5.559c-0.277-2.039,3.74-4.285,8.979-5.015c5.239-0.73,9.718,0.333,10.002,2.368z\"/>\r\n<path d=\"M350.676,123.432c0.863,15.994-3.445,26.888-3.988,43.914c-0.804,24.748,11.799,53.074-7.191,81.435\"/>\r\n<path style=\"stroke-width:3;\" d=\"M0,60.232\"/>\r\n</g>\r\n</svg>";

/***/ }),

/***/ "./style/icons/random-24.svg":
/*!***********************************!*\
  !*** ./style/icons/random-24.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\" fill-rule=\"evenodd\" clip-rule=\"evenodd\"><path d=\"M12 9.5a2.5 2.5 0 100 5 2.5 2.5 0 000-5zM11 12a1 1 0 112 0 1 1 0 01-2 0zM5 7.5a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0zm2.5-1a1 1 0 100 2 1 1 0 000-2zM16.5 14a2.5 2.5 0 100 5 2.5 2.5 0 000-5zm-1 2.5a1 1 0 112 0 1 1 0 01-2 0z\"/><path d=\"M4.75 2A2.75 2.75 0 002 4.75v14.5A2.75 2.75 0 004.75 22h14.5A2.75 2.75 0 0022 19.25V4.75A2.75 2.75 0 0019.25 2H4.75zM3.5 4.75c0-.69.56-1.25 1.25-1.25h14.5c.69 0 1.25.56 1.25 1.25v14.5c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25V4.75z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/reddit.svg":
/*!********************************!*\
  !*** ./style/icons/reddit.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<svg viewBox=\"0 0 800 800\" xmlns=\"http://www.w3.org/2000/svg\" width=\"2500\" height=\"2500\"><circle cx=\"400\" cy=\"400\" fill=\"#ff4500\" r=\"400\"/><path d=\"M666.8 400c.08 5.48-.6 10.95-2.04 16.24s-3.62 10.36-6.48 15.04c-2.85 4.68-6.35 8.94-10.39 12.65s-8.58 6.83-13.49 9.27c.11 1.46.2 2.93.25 4.4a107.268 107.268 0 0 1 0 8.8c-.05 1.47-.14 2.94-.25 4.4 0 89.6-104.4 162.4-233.2 162.4S168 560.4 168 470.8c-.11-1.46-.2-2.93-.25-4.4a107.268 107.268 0 0 1 0-8.8c.05-1.47.14-2.94.25-4.4a58.438 58.438 0 0 1-31.85-37.28 58.41 58.41 0 0 1 7.8-48.42 58.354 58.354 0 0 1 41.93-25.4 58.4 58.4 0 0 1 46.52 15.5 286.795 286.795 0 0 1 35.89-20.71c12.45-6.02 25.32-11.14 38.51-15.3s26.67-7.35 40.32-9.56 27.45-3.42 41.28-3.63L418 169.6c.33-1.61.98-3.13 1.91-4.49.92-1.35 2.11-2.51 3.48-3.4 1.38-.89 2.92-1.5 4.54-1.8 1.61-.29 3.27-.26 4.87.09l98 19.6c9.89-16.99 30.65-24.27 48.98-17.19s28.81 26.43 24.71 45.65c-4.09 19.22-21.55 32.62-41.17 31.61-19.63-1.01-35.62-16.13-37.72-35.67L440 186l-26 124.8c13.66.29 27.29 1.57 40.77 3.82a284.358 284.358 0 0 1 77.8 24.86A284.412 284.412 0 0 1 568 360a58.345 58.345 0 0 1 29.4-15.21 58.361 58.361 0 0 1 32.95 3.21 58.384 58.384 0 0 1 25.91 20.61A58.384 58.384 0 0 1 666.8 400zm-396.96 55.31c2.02 4.85 4.96 9.26 8.68 12.97 3.71 3.72 8.12 6.66 12.97 8.68A40.049 40.049 0 0 0 306.8 480c16.18 0 30.76-9.75 36.96-24.69 6.19-14.95 2.76-32.15-8.68-43.59s-28.64-14.87-43.59-8.68c-14.94 6.2-24.69 20.78-24.69 36.96 0 5.25 1.03 10.45 3.04 15.31zm229.1 96.02c2.05-2 3.22-4.73 3.26-7.59.04-2.87-1.07-5.63-3.07-7.68s-4.73-3.22-7.59-3.26c-2.87-.04-5.63 1.07-7.94 2.8a131.06 131.06 0 0 1-19.04 11.35 131.53 131.53 0 0 1-20.68 7.99c-7.1 2.07-14.37 3.54-21.72 4.39-7.36.85-14.77 1.07-22.16.67-7.38.33-14.78.03-22.11-.89a129.01 129.01 0 0 1-21.64-4.6c-7.08-2.14-13.95-4.88-20.56-8.18s-12.93-7.16-18.89-11.53c-2.07-1.7-4.7-2.57-7.38-2.44s-5.21 1.26-7.11 3.15c-1.89 1.9-3.02 4.43-3.15 7.11s.74 5.31 2.44 7.38c7.03 5.3 14.5 9.98 22.33 14s16 7.35 24.4 9.97 17.01 4.51 25.74 5.66c8.73 1.14 17.54 1.53 26.33 1.17 8.79.36 17.6-.03 26.33-1.17A153.961 153.961 0 0 0 476.87 564c7.83-4.02 15.3-8.7 22.33-14zm-7.34-68.13c5.42.06 10.8-.99 15.81-3.07 5.01-2.09 9.54-5.17 13.32-9.06s6.72-8.51 8.66-13.58A39.882 39.882 0 0 0 532 441.6c0-16.18-9.75-30.76-24.69-36.96-14.95-6.19-32.15-2.76-43.59 8.68s-14.87 28.64-8.68 43.59c6.2 14.94 20.78 24.69 36.96 24.69z\" fill=\"#fff\"/></svg>";

/***/ }),

/***/ "./style/icons/s3.svg":
/*!****************************!*\
  !*** ./style/icons/s3.svg ***!
  \****************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"396\"\n   height=\"480\"\n   viewBox=\"0 0 396 480\"\n   version=\"1.1\"\n   id=\"svg13\"\n   sodipodi:docname=\"s3.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <sodipodi:namedview\n     id=\"namedview13\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"0.4609375\"\n     inkscape:cx=\"199.59322\"\n     inkscape:cy=\"251.66102\"\n     inkscape:window-width=\"1312\"\n     inkscape:window-height=\"449\"\n     inkscape:window-x=\"0\"\n     inkscape:window-y=\"32\"\n     inkscape:window-maximized=\"0\"\n     inkscape:current-layer=\"svg13\" />\n  <defs\n     id=\"defs1\">\n    <style\n       id=\"style1\">&#10;      .cls-1 {&#10;        fill: #e25444;&#10;      }&#10;&#10;      .cls-1, .cls-2, .cls-3 {&#10;        fill-rule: evenodd;&#10;      }&#10;&#10;      .cls-2 {&#10;        fill: #7b1d13;&#10;      }&#10;&#10;      .cls-3 {&#10;        fill: #58150d;&#10;      }&#10;    </style>\n  </defs>\n  <g\n     id=\"g13\"\n     transform=\"translate(-16,-16)\">\n    <path\n       class=\"cls-1\"\n       d=\"m 378,99 -83,158 83,158 34,-19 V 118 Z\"\n       id=\"path1\" />\n    <path\n       class=\"cls-2\"\n       d=\"M 378,99 212,118 127.5,257 212,396 378,415 Z\"\n       id=\"path2\" />\n    <path\n       class=\"cls-3\"\n       d=\"M 43,99 16,111 V 403 L 43,415 212,257 Z\"\n       id=\"path3\" />\n    <path\n       class=\"cls-1\"\n       d=\"m 42.637,98.667 169.587,47.111 V 372.444 L 42.637,415.111 Z\"\n       id=\"path4\" />\n    <path\n       class=\"cls-3\"\n       d=\"m 212.313,170.667 -72.008,-11.556 72.008,-81.778 71.83,81.778 z\"\n       id=\"path5\" />\n    <path\n       class=\"cls-3\"\n       d=\"m 284.143,159.111 -71.919,11.733 -71.919,-11.733 V 77.333\"\n       id=\"path6\" />\n    <path\n       class=\"cls-3\"\n       d=\"m 212.313,342.222 -72.008,13.334 72.008,70.222 71.83,-70.222 z\"\n       id=\"path7\" />\n    <path\n       class=\"cls-2\"\n       d=\"m 212,16 -72,38 v 105 l 72.224,-20.333 z\"\n       id=\"path8\" />\n    <path\n       class=\"cls-2\"\n       d=\"m 212.224,196.444 -71.919,7.823 v 104.838 l 71.919,8.228 z\"\n       id=\"path9\" />\n    <path\n       class=\"cls-2\"\n       d=\"M 212.224,373.333 140.305,355.3 V 458.363 L 212.224,496 Z\"\n       id=\"path10\" />\n    <path\n       class=\"cls-1\"\n       d=\"m 284.143,355.3 -71.919,18.038 V 496 l 71.919,-37.637 z\"\n       id=\"path11\" />\n    <path\n       class=\"cls-1\"\n       d=\"m 212.224,196.444 71.919,7.823 v 104.838 l -71.919,8.228 z\"\n       id=\"path12\" />\n    <path\n       class=\"cls-1\"\n       d=\"m 212,16 72,38 v 105 l -72,-20 z\"\n       id=\"path13\" />\n  </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/scissors-24.svg":
/*!*************************************!*\
  !*** ./style/icons/scissors-24.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path fill-rule=\"evenodd\" d=\"M5.5 2a3.5 3.5 0 101.99 6.38l3.346 3.12-3.346 3.12a3.5 3.5 0 101.023 1.097l3.93-3.664.009-.008 8.31-7.746A.75.75 0 0019.739 3.2l-7.803 7.274-3.424-3.192A3.5 3.5 0 005.5 2zm-2 3.5a2 2 0 114 0 2 2 0 01-4 0zm0 12a2 2 0 114 0 2 2 0 01-4 0z\" clip-rule=\"evenodd\"/><path d=\"M20.763 18.703a.75.75 0 01-1.026 1.095l-5.5-5.15a.75.75 0 011.026-1.095l5.5 5.15z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/service-16.svg":
/*!************************************!*\
  !*** ./style/icons/service-16.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><g fill=\"currentColor\"><path d=\"M6.834.33a2.25 2.25 0 012.332 0l5.25 3.182A2.25 2.25 0 0115.5 5.436V6A.75.75 0 0114 6v-.564a.75.75 0 00-.361-.642l-5.25-3.181a.75.75 0 00-.778 0l-5.25 3.181A.75.75 0 002 5.436v5.128a.75.75 0 00.361.642l4.028 2.44a.75.75 0 11-.778 1.283l-4.027-2.44A2.25 2.25 0 01.5 10.563V5.436a2.25 2.25 0 011.084-1.924L6.834.33z\"/><path fill-rule=\"evenodd\" d=\"M11.749 7.325l.001-.042v-.286a.75.75 0 00-1.5 0v.286l.001.042a3.73 3.73 0 00-1.318.546.76.76 0 00-.03-.03l-.201-.203a.75.75 0 00-1.06 1.06l.201.203.03.028c-.26.394-.45.84-.547 1.319a.878.878 0 00-.04-.001H7a.75.75 0 000 1.5h.286l.038-.001c.097.48.286.926.547 1.32a.71.71 0 00-.028.027l-.202.202a.75.75 0 001.06 1.06l.203-.202a.695.695 0 00.025-.026c.395.261.842.45 1.322.548l-.001.036v.286a.75.75 0 001.5 0v-.286-.036c.48-.097.926-.287 1.32-.548l.026.026.202.203a.75.75 0 001.06-1.061l-.201-.202a.667.667 0 00-.028-.026c.261-.395.45-.842.547-1.321H15a.75.75 0 000-1.5h-.286l-.04.002a3.734 3.734 0 00-.547-1.319l.03-.028.202-.202a.75.75 0 00-1.06-1.061l-.203.202-.029.03a3.73 3.73 0 00-1.318-.545zM11 8.75A2.247 2.247 0 008.75 11 2.247 2.247 0 0011 13.25 2.247 2.247 0 0013.25 11 2.247 2.247 0 0011 8.75z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/settings-16.svg":
/*!*************************************!*\
  !*** ./style/icons/settings-16.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"16\"\n   height=\"16\"\n   fill=\"none\"\n   viewBox=\"0 0 16 16\"\n   version=\"1.1\"\n   id=\"svg2\"\n   sodipodi:docname=\"settings-16.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <defs\n     id=\"defs2\" />\n  <sodipodi:namedview\n     id=\"namedview2\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"34.875\"\n     inkscape:cx=\"8\"\n     inkscape:cy=\"7.9856631\"\n     inkscape:window-width=\"1392\"\n     inkscape:window-height=\"922\"\n     inkscape:window-x=\"0\"\n     inkscape:window-y=\"75\"\n     inkscape:window-maximized=\"0\"\n     inkscape:current-layer=\"svg2\" />\n  <g\n     fill=\"currentColor\"\n     fill-rule=\"evenodd\"\n     clip-rule=\"evenodd\"\n     id=\"g2\">\n    <path\n       d=\"M8 5a3 3 0 100 6 3 3 0 000-6zM6.5 8a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0z\"\n       id=\"path1\" />\n    <path\n       d=\"M7.5 0a1.75 1.75 0 00-1.75 1.75v.15c-.16.06-.318.125-.472.196l-.106-.106a1.75 1.75 0 00-2.475 0l-.707.707a1.75 1.75 0 000 2.475l.106.106a6.46 6.46 0 00-.196.472h-.15A1.75 1.75 0 000 7.5v1c0 .966.784 1.75 1.75 1.75h.15c.06.16.125.318.196.472l-.106.107a1.75 1.75 0 000 2.474l.707.708a1.75 1.75 0 002.475 0l.106-.107c.154.071.312.137.472.196v.15c0 .966.784 1.75 1.75 1.75h1a1.75 1.75 0 001.75-1.75v-.15c.16-.06.318-.125.472-.196l.106.107a1.75 1.75 0 002.475 0l.707-.707a1.75 1.75 0 000-2.475l-.106-.107c.071-.154.137-.311.196-.472h.15A1.75 1.75 0 0016 8.5v-1a1.75 1.75 0 00-1.75-1.75h-.15a6.455 6.455 0 00-.196-.472l.106-.106a1.75 1.75 0 000-2.475l-.707-.707a1.75 1.75 0 00-2.475 0l-.106.106a6.46 6.46 0 00-.472-.196v-.15A1.75 1.75 0 008.5 0h-1zm-.25 1.75a.25.25 0 01.25-.25h1a.25.25 0 01.25.25v.698c0 .339.227.636.555.724.42.113.817.28 1.186.492a.75.75 0 00.905-.12l.493-.494a.25.25 0 01.354 0l.707.708a.25.25 0 010 .353l-.494.494a.75.75 0 00-.12.904c.213.369.38.767.492 1.186a.75.75 0 00.724.555h.698a.25.25 0 01.25.25v1a.25.25 0 01-.25.25h-.698a.75.75 0 00-.724.555c-.113.42-.28.817-.492 1.186a.75.75 0 00.12.905l.494.493a.25.25 0 010 .354l-.707.707a.25.25 0 01-.354 0l-.494-.494a.75.75 0 00-.904-.12 4.966 4.966 0 01-1.186.492.75.75 0 00-.555.724v.698a.25.25 0 01-.25.25h-1a.25.25 0 01-.25-.25v-.698a.75.75 0 00-.555-.724 4.966 4.966 0 01-1.186-.491.75.75 0 00-.904.12l-.494.493a.25.25 0 01-.354 0l-.707-.707a.25.25 0 010-.354l.494-.493a.75.75 0 00.12-.905 4.966 4.966 0 01-.492-1.186.75.75 0 00-.724-.555H1.75a.25.25 0 01-.25-.25v-1a.25.25 0 01.25-.25h.698a.75.75 0 00.724-.555c.113-.42.28-.817.491-1.186a.75.75 0 00-.12-.904L3.05 4.11a.25.25 0 010-.353l.707-.708a.25.25 0 01.354 0l.493.494c.24.24.611.289.905.12a4.965 4.965 0 011.186-.492.75.75 0 00.555-.724V1.75z\"\n       id=\"path2\" />\n  </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/sidebar-show-24.svg":
/*!*****************************************!*\
  !*** ./style/icons/sidebar-show-24.svg ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M11.735 8.295a.75.75 0 011.03-1.09l4.5 4.25a.75.75 0 010 1.09l-4.5 4.25a.75.75 0 01-1.03-1.09L15.658 12l-3.923-3.705z\"/><path fill-rule=\"evenodd\" d=\"M2 4.75A2.75 2.75 0 014.75 2h14.5A2.75 2.75 0 0122 4.75v14.5A2.75 2.75 0 0119.25 22H4.75A2.75 2.75 0 012 19.25V4.75zM4.75 3.5c-.69 0-1.25.56-1.25 1.25v14.5c0 .69.56 1.25 1.25 1.25H7v-17H4.75zm14.5 17H8.5v-17h10.75c.69 0 1.25.56 1.25 1.25v14.5c0 .69-.56 1.25-1.25 1.25z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/snowflake.svg":
/*!***********************************!*\
  !*** ./style/icons/snowflake.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg id=\"Layer_1\" data-name=\"Layer 1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 146.36 139.16\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n <defs>\n  <style>\n   .cls-1{fill:#29b5e8;fill-rule:evenodd;}\n  </style>\n </defs>\n <path class=\"cls-1\" d=\"M134.81,60.1l-16.47,9.49L134.81,79a8.65,8.65,0,1,1-8.67,15l-29.51-17a8.68,8.68,0,0,1-4.33-7.75,8.48,8.48,0,0,1,.31-2,8.68,8.68,0,0,1,4-5.19l29.51-16.94A8.69,8.69,0,0,1,138,48.31,8.58,8.58,0,0,1,134.81,60.1Zm-15.59,46L89.72,89.13a8.72,8.72,0,0,0-13.06,7.48v33.9a8.69,8.69,0,0,0,17.37,0v-19L110.54,121a8.66,8.66,0,1,0,8.68-15Zm-34-33.16L72.92,85.09a2.44,2.44,0,0,1-1.54.65H67.77a2.51,2.51,0,0,1-1.54-.65L54,72.9a2.45,2.45,0,0,1-.64-1.52v-3.6A2.5,2.5,0,0,1,54,66.25L66.23,54.06a2.5,2.5,0,0,1,1.54-.64h3.61a2.45,2.45,0,0,1,1.54.64L85.18,66.25a2.49,2.49,0,0,1,.63,1.53v3.6A2.44,2.44,0,0,1,85.18,72.9Zm-9.8-3.38A2.59,2.59,0,0,0,74.73,68l-3.55-3.51a2.51,2.51,0,0,0-1.54-.64h-.13a2.46,2.46,0,0,0-1.53.64L64.43,68a2.51,2.51,0,0,0-.63,1.55v.13a2.41,2.41,0,0,0,.63,1.52L68,74.7a2.48,2.48,0,0,0,1.53.64h.13a2.51,2.51,0,0,0,1.54-.64l3.55-3.53a2.49,2.49,0,0,0,.65-1.52ZM19.93,33.08,49.44,50a8.73,8.73,0,0,0,13.07-7.49V8.64a8.69,8.69,0,0,0-17.37,0v19l-16.53-9.5a8.65,8.65,0,1,0-8.68,15ZM84.69,51.16a8.64,8.64,0,0,0,5-1.13l29.5-17a8.65,8.65,0,1,0-8.68-15L94,27.61v-19a8.69,8.69,0,0,0-17.37,0v33.9A8.66,8.66,0,0,0,84.69,51.16ZM54.48,88a8.58,8.58,0,0,0-5,1.13L19.93,106.06a8.66,8.66,0,1,0,8.68,15l16.53-9.49v19a8.69,8.69,0,0,0,17.37,0V96.61A8.65,8.65,0,0,0,54.48,88Zm-8-15.87a8.61,8.61,0,0,0-4-10L13,45.14A8.69,8.69,0,0,0,1.17,48.31,8.59,8.59,0,0,0,4.35,60.1l16.47,9.49L4.35,79A8.65,8.65,0,1,0,13,94l29.48-17A8.59,8.59,0,0,0,46.47,72.13Zm93.15-56.22H138.3v1.63h1.32c.61,0,1-.28,1-.8S140.26,15.91,139.62,15.91Zm-2.94-1.5h3c1.62,0,2.7.89,2.7,2.27a2.16,2.16,0,0,1-1.08,1.9l1.17,1.68v.34h-1.69L139.62,19H138.3V20.6h-1.62Zm8.3,3.22a5.48,5.48,0,0,0-5.58-5.83c-3.31,0-5.51,2.39-5.51,5.83,0,3.28,2.2,5.82,5.51,5.82A5.47,5.47,0,0,0,145,17.63Zm1.38,0c0,3.89-2.6,7.14-7,7.14s-6.89-3.28-6.89-7.14,2.57-7.14,6.89-7.14S146.36,13.73,146.36,17.63Z\">\n </path>\n</svg>";

/***/ }),

/***/ "./style/icons/sort-desc-24.svg":
/*!**************************************!*\
  !*** ./style/icons/sort-desc-24.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><g fill=\"currentColor\"><path d=\"M3 5.75A.75.75 0 013.75 5h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 5.75zM3.75 9a.75.75 0 000 1.5h9.5a.75.75 0 000-1.5h-9.5zM16.963 20.443a.747.747 0 00.817-.163l4-4a.75.75 0 10-1.06-1.06L18 17.94V9.75a.75.75 0 00-1.5 0v8.19l-2.72-2.72a.75.75 0 10-1.06 1.06l4 4a.748.748 0 00.243.163zM3.75 13a.75.75 0 000 1.5h5.5a.75.75 0 000-1.5h-5.5zM3 17.75a.75.75 0 01.75-.75h3.5a.75.75 0 010 1.5h-3.5a.75.75 0 01-.75-.75z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/sql-server.svg":
/*!************************************!*\
  !*** ./style/icons/sql-server.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\"  viewBox=\"0 0 48 48\" width=\"48px\" height=\"48px\"><path fill=\"#cfd8dc\" d=\"M23.084,11.277c-1.633-2.449-1.986-5.722-2.063-7.067c-4.148,0.897-8.269,2.506-8.031,3.691 c0.03,0.149,0.218,0.328,0.53,0.502l-0.488,0.873c-0.596-0.334-0.931-0.719-1.022-1.179c-0.269-1.341,1.25-2.554,4.642-3.709 c2.316-0.789,4.652-1.26,4.751-1.279l0.597-0.12L22,3.6c0,0.042,0.026,4.288,1.916,7.123L23.084,11.277z\"/><path fill=\"#cfd8dc\" d=\"M24.751,43H24.5c-8.192,0-17.309-2.573-18.386-6.879c-0.657-2.63,1.492-5.536,6.214-8.401 l0.52,0.854c-4.249,2.579-6.296,5.172-5.763,7.305c0.935,3.738,9.575,6.068,17.153,6.12c0.901-1.347,5.742-9.26,2.979-19.873 l0.967-0.252c3.149,12.092-3.218,20.837-3.282,20.924L24.751,43z\"/><path fill=\"#cfd8dc\" d=\"M9.931,39.306c-0.539,0-0.806-0.059-0.85-0.07c-0.176-0.043-0.314-0.178-0.362-0.352 c-0.049-0.174,0.001-0.361,0.129-0.488c0.072-0.072,7.197-7.208,8.159-12.978l0.986,0.164c-0.827,4.964-5.715,10.623-7.656,12.707 c1.939-0.111,6.835-1.019,16.234-6.28c-7.335-0.804-8.495-6.676-8.507-6.739l0.983-0.181c0.047,0.246,1.226,6.011,9.244,6.011 c0.003,0,0.005,0,0.008,0l0,0c0.227,0,0.424,0.152,0.482,0.37c0.06,0.218-0.036,0.449-0.231,0.563 C17.315,38.542,11.867,39.305,9.931,39.306z\"/><path fill=\"#cfd8dc\" d=\"M14.524,41.7c-0.207,0-0.395-0.128-0.468-0.325c-0.079-0.211-0.007-0.45,0.177-0.582 c0.034-0.025,1.813-1.338,3.706-4.228c-0.728-0.322-1.465-0.698-2.196-1.137c-0.888-0.533-1.559-1.105-2.06-1.691 c-2.57,0.678-4.942,0.946-7.025,0.769l0.084-0.996c1.876,0.159,4.009-0.063,6.321-0.64c-1.573-2.688-0.129-5.356-0.109-5.392 l0.874,0.487c-0.067,0.122-1.265,2.37,0.249,4.633c2.201-0.632,4.549-1.567,6.979-2.782c0.559-1.835,0.996-3.922,1.225-6.276 c0.016-0.161,0.108-0.304,0.248-0.385s0.311-0.088,0.458-0.021c0.032,0.015,3.264,1.491,5.604,2.454 c0.17,0.07,0.288,0.228,0.307,0.411c0.02,0.183-0.063,0.361-0.216,0.465c-2.289,1.56-4.563,2.913-6.778,4.042 c-0.702,2.225-1.571,4.077-2.459,5.591c3.702,1.383,6.915,1.404,6.956,1.404c0.228,0,0.427,0.154,0.484,0.375 c0.057,0.221-0.042,0.452-0.241,0.563c-4.54,2.522-11.767,3.232-12.072,3.261C14.556,41.699,14.54,41.7,14.524,41.7z M18.909,36.967c-1.04,1.614-2.062,2.773-2.826,3.53c1.998-0.294,5.501-0.938,8.408-2.139 C23.099,38.187,21.084,37.807,18.909,36.967z M14.767,33.431c0.393,0.392,0.883,0.775,1.49,1.14 c0.736,0.442,1.483,0.817,2.22,1.135c0.754-1.264,1.501-2.781,2.142-4.568C18.598,32.1,16.636,32.868,14.767,33.431z M23.202,24.329c-0.205,1.768-0.521,3.381-0.913,4.85c1.66-0.885,3.354-1.896,5.062-3.026 C25.802,25.497,24.099,24.734,23.202,24.329z\"/><path fill=\"#cfd8dc\" d=\"M17.924,10.6c-0.117,0-0.233-0.042-0.325-0.12c-1.61-1.378-3.505-4.182-3.585-4.301 c-0.129-0.191-0.109-0.446,0.046-0.616c0.154-0.171,0.408-0.211,0.608-0.102c0.011,0.003,0.938,0.385,7.217,1.431 c0.181,0.03,0.33,0.156,0.39,0.328c0.061,0.172,0.022,0.364-0.1,0.5c-1.758,1.953-3.979,2.813-4.073,2.848 C18.044,10.589,17.983,10.6,17.924,10.6z M15.647,6.746c0.631,0.849,1.54,1.996,2.372,2.769c0.511-0.233,1.657-0.818,2.744-1.798 C18.18,7.276,16.604,6.962,15.647,6.746z\"/><path fill=\"#b71c1c\" d=\"M21.843,24.4c-0.068,0-0.137-0.014-0.201-0.042c-0.199-0.088-0.319-0.294-0.296-0.51 c0.292-2.749-3.926-3.852-3.969-3.862c-0.174-0.044-0.312-0.179-0.359-0.352s0.002-0.359,0.129-0.486 c0.207-0.207,5.139-5.098,11.327-7.784c0.173-0.075,0.369-0.047,0.515,0.07c0.145,0.118,0.212,0.307,0.174,0.489 c-1.186,5.744-6.71,12.044-6.944,12.309C22.12,24.341,21.982,24.4,21.843,24.4z M18.455,19.285 c1.184,0.445,3.258,1.475,3.783,3.356c1.449-1.808,4.542-5.973,5.697-9.934C23.548,14.817,19.854,17.999,18.455,19.285z\"/><path fill=\"#b71c1c\" d=\"M13.079,28.36l-0.475-0.88c1.883-1.015,4.04-2.883,5.807-5.054c-1.504,1.03-2.365,1.735-2.392,1.758 l-0.639-0.77c0.039-0.032,1.764-1.447,4.631-3.22c0.787-1.266,1.392-2.568,1.703-3.816c0.053-0.212,0.099-0.417,0.136-0.615 c-1.925-0.687-3.701-1.094-4.921-1.269c-0.185-0.026-0.339-0.153-0.401-0.328c-0.062-0.175-0.021-0.371,0.104-0.507 c0.085-0.092,2.116-2.268,4.654-3.463c0.197-0.093,0.433-0.047,0.581,0.114c0.067,0.073,1.44,1.615,1.091,4.805 c1.155,0.45,2.345,0.997,3.491,1.648c2.759-1.24,5.892-2.356,9.229-3.03c0.172-0.034,0.363,0.028,0.481,0.168 c0.117,0.14,0.149,0.333,0.083,0.503c-1.3,3.332-4.786,6.891-4.934,7.041c-0.101,0.102-0.239,0.153-0.383,0.148 c-0.143-0.008-0.275-0.076-0.365-0.188c-1.12-1.408-2.584-2.574-4.163-3.523c-2.175,1.004-4.101,2.078-5.684,3.049 C18.693,24.084,15.644,26.979,13.079,28.36z M27.492,17.396c1.29,0.832,2.491,1.81,3.484,2.948 c0.828-0.898,2.815-3.168,3.942-5.422C32.268,15.532,29.76,16.415,27.492,17.396z M22.799,16.122 c-0.033,0.163-0.071,0.33-0.113,0.5c-0.21,0.839-0.544,1.701-0.972,2.561c1.096-0.626,2.309-1.272,3.618-1.898 C24.494,16.841,23.639,16.455,22.799,16.122z M18.048,13.672c1.111,0.218,2.48,0.574,3.941,1.086 c0.152-1.843-0.346-2.972-0.647-3.472C19.966,12.004,18.761,13.014,18.048,13.672z\"/><path fill=\"#b71c1c\" d=\"M18.05,18.5c0,4.38-3.65,7.86-6.28,10.4c-0.44,0.43-1.93,0.5-1.93,0.5 c0.37-0.38,0.79-0.78,1.24-1.21c2.5-2.42,5.97-5.73,5.97-9.69c0-4.69-1.89-6.54-3.38-8.02c-0.66-0.67-1.22-1.31-1.56-2.09 l0.31-0.13c0.34,0.15,0.73,0.32,1.03,0.45c0.24,0.35,0.56,0.69,0.93,1.06C15.91,11.3,18.05,13.4,18.05,18.5z\"/><path fill=\"#b71c1c\" d=\"M42.935,19.794c0,0-0.605,0.086-0.775,0.106c-8.76,0.97-17.8,3.49-22.97,5.56 c-1.87,0.75-3.81,1.66-5.58,2.68c-0.01,0.01-0.02,0.01-0.04,0.02C12.53,28.76,10,30,7.95,31.09c3-3.19,8.62-5.65,10.86-6.55 c5.07-2.03,13.78-4.48,22.35-5.53c-1.01-1.18-3.48-3.68-8.34-5.54c-2.84-1.1-7.16-1.72-10.97-2.27c-6.06-0.87-9.51-1.45-9.84-3.1 c-0.07-0.33-0.02-0.66,0.13-0.98c0.33,0.54,0.8,0.92,1.11,1.14c0.15,0.1,0.26,0.16,0.3,0.18l0.01,0.01 c1.42,0.75,5.25,1.3,8.44,1.76c3.86,0.56,8.23,1.19,11.18,2.32c6.87,2.65,9.24,6.44,9.34,6.6 C42.61,19.28,42.935,19.794,42.935,19.794z\"/></svg>";

/***/ }),

/***/ "./style/icons/sum.svg":
/*!*****************************!*\
  !*** ./style/icons/sum.svg ***!
  \*****************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-percent\"><line x1=\"19\" y1=\"5\" x2=\"5\" y2=\"19\"></line><circle cx=\"6.5\" cy=\"6.5\" r=\"2.5\"></circle><circle cx=\"17.5\" cy=\"17.5\" r=\"2.5\"></circle></svg>";

/***/ }),

/***/ "./style/icons/trino.svg":
/*!*******************************!*\
  !*** ./style/icons/trino.svg ***!
  \*******************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   viewBox=\"-1 0 63.191998 63.192003\"\n   version=\"1.1\"\n   id=\"svg22\"\n   sodipodi:docname=\"trino.svg\"\n   width=\"63.192001\"\n   height=\"63.192001\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <sodipodi:namedview\n     id=\"namedview22\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"2.5482452\"\n     inkscape:cx=\"66.90879\"\n     inkscape:cy=\"31.590367\"\n     inkscape:window-width=\"2560\"\n     inkscape:window-height=\"1412\"\n     inkscape:window-x=\"1512\"\n     inkscape:window-y=\"149\"\n     inkscape:window-maximized=\"1\"\n     inkscape:current-layer=\"Layer_3\" />\n  <defs\n     id=\"defs1\">\n    <style\n       id=\"style1\">.cls-1{fill:#cdcccc;}.cls-2{fill:#fff;}.cls-3{fill:#dd00a1;}.cls-4{fill:#f9d8d2;}.cls-5{fill:#10110e;}.cls-6{fill:#e5e5e5;}.cls-7{fill:#8accce;opacity:0.2;}.cls-8{fill:#515151;}</style>\n  </defs>\n  <g\n     id=\"Layer_2\"\n     data-name=\"Layer 2\"\n     transform=\"translate(0,0.0015663)\">\n    <g\n       id=\"Layer_3\"\n       data-name=\"Layer 3\">\n      <g\n         id=\"g22\"\n         transform=\"translate(9.150631,2.1751926e-4)\">\n        <path\n           class=\"cls-1\"\n           d=\"m 39.09,30.67 a 3,3 0 0 0 -6,0 2.76,2.76 0 0 0 1.91,2.55 v 4.57 a 15.27,15.27 0 0 0 -6.91,-7.85 c 0.46,-1 0.93,-1.86 1.38,-2.65 a 65.83,65.83 0 0 1 5.67,-7.24 c 1.13,-1.34 2.2,-2.6 3.07,-3.7 2.44,-3.06 5.12,-7.58 4.62,-10.26 A 2.56,2.56 0 0 0 41.58,4.28 c -3.39,-2 -8,4.5 -12.53,10.77 -3,4.14 -4.55,10 -5.26,13.29 a 19.86,19.86 0 0 0 -4.23,-0.46 18.63,18.63 0 0 0 -6.08,1 85.14,85.14 0 0 1 0.33,-11 c 1,-9.51 0.56,-15.09 -1.29,-17 A 2.43,2.43 0 0 0 10.56,0 C 5.1,0.27 5.72,16.58 5.81,18.44 c 0.22,4.46 2,9.88 3.08,12.88 A 15.44,15.44 0 0 0 3.64,39.13 H 3.25 a 3.11,3.11 0 0 0 -3.25,3 v 5.17 a 3.12,3.12 0 0 0 3.25,3 h 0.66 a 13.34,13.34 0 0 0 3.29,4.63 l -1,0.88 a 1.17,1.17 0 0 0 -0.13,1.64 c 3,3.65 7.91,5.74 13.42,5.74 5.51,0 10.44,-2.09 13.42,-5.74 a 1.17,1.17 0 0 0 -0.13,-1.64 l -1,-0.88 a 13.56,13.56 0 0 0 3.29,-4.71 h 0.75 a 3.12,3.12 0 0 0 3.25,-3 v -5.13 a 2.94,2.94 0 0 0 -1.91,-2.68 v -6.19 a 2.75,2.75 0 0 0 1.93,-2.55 z\"\n           id=\"path1\" />\n        <path\n           class=\"cls-2\"\n           d=\"m 14.62,55.74 c 0.92,-0.61 -1.5,-0.38 -1.7,-0.79 A 16.49,16.49 0 0 1 10.06,54.44 C 8.36,53.99 4.28,51.25 3.84,48.62 3.4,45.99 3.84,41 5.68,38 a 17.21,17.21 0 0 1 4.38,-4.7 c 0,0 -3.57,-8.49 -3.87,-14.9 -0.3,-6.41 0.2,-17.82 4.38,-18.02 4.18,-0.2 3.57,10.48 2.86,17.43 a 90.59,90.59 0 0 0 -0.2,13.88 19.73,19.73 0 0 1 5.5,-0.92 21.12,21.12 0 0 1 4.9,0.46 c 0,0 1.33,-9.84 5.71,-16 4.38,-6.16 9,-12.45 12,-10.66 3,1.79 -0.82,8.18 -3.47,11.51 -2.65,3.33 -7.24,8.33 -8.77,11 a 46.59,46.59 0 0 0 -2.65,5.51 14.93,14.93 0 0 1 6.39,6.32 C 35,43.22 35.16,48.52 34,50.77 a 8.08,8.08 0 0 1 -5.61,4 c -1.33,0.06 -6.92,1.45 -6.92,1.45 z\"\n           id=\"path2\" />\n        <path\n           class=\"cls-3\"\n           d=\"m 24.41,31.32 c 0,0 3.34,-8.71 6.33,-13.6 2.99,-4.89 7,-8.59 8.26,-7.84 1.26,0.75 -2.57,5.32 -5.93,9.81 a 113.44,113.44 0 0 0 -7.43,12.38 z\"\n           id=\"path3\" />\n        <path\n           class=\"cls-3\"\n           d=\"m 11,32.81 1,-0.74 c 0,0 -0.14,-8.71 0,-14 0.14,-5.29 0.41,-11.9 -1.36,-11.84 -1.77,0.06 -3,5.17 -2.31,12.38 A 87.47,87.47 0 0 0 11,32.81 Z\"\n           id=\"path4\" />\n        <circle\n           class=\"cls-4\"\n           cx=\"8.0200005\"\n           cy=\"49.540001\"\n           r=\"1.9400001\"\n           id=\"circle4\" />\n        <circle\n           class=\"cls-4\"\n           cx=\"30.950001\"\n           cy=\"49.540001\"\n           r=\"1.9400001\"\n           id=\"circle5\" />\n        <path\n           class=\"cls-5\"\n           d=\"m 22.7,49.38 a 0.18,0.18 0 0 0 -0.25,0.07 c 0,0 -0.58,1 -1.42,1.06 a 2.09,2.09 0 0 1 -1.5,-0.7 v -1.48 c 0.54,-0.3 1.41,-1.2 1.41,-1.51 a 1.41,1.41 0 0 0 -1.49,-1.09 c -1,0 -1.7,0.65 -1.7,1.19 0,0.54 1.1,1.24 1.41,1.44 v 1.46 a 1.82,1.82 0 0 1 -1.31,0.69 c -0.79,0 -1.39,-1.08 -1.4,-1.09 A 0.19,0.19 0 0 0 16.2,49.34 0.2,0.2 0 0 0 16.12,49.6 c 0,0 0.71,1.29 1.73,1.29 a 2.12,2.12 0 0 0 1.51,-0.73 2.37,2.37 0 0 0 1.58,0.73 h 0.12 a 2.49,2.49 0 0 0 1.71,-1.26 0.18,0.18 0 0 0 -0.07,-0.25 z\"\n           id=\"path5\" />\n        <path\n           class=\"cls-6\"\n           d=\"m 10.06,33.32 c 0,0 -2.77,-7 -3.3,-10.66 C 6.23,19 5.76,12.89 6.46,8.82 A 50,50 0 0 1 7.68,3.26 c 0,0 -1.29,9.49 -0.81,13.64 0.48,4.15 3.19,16.42 3.19,16.42 z\"\n           id=\"path6\" />\n        <path\n           class=\"cls-6\"\n           d=\"m 23.63,31.23 c 0,0 2,-10.59 4.91,-14.75 C 31.45,12.32 35.06,7.27 36.89,6 l 1.83,-1.28 c 0,0 -7.34,7.7 -10.18,14 -2.84,6.3 -4.91,12.51 -4.91,12.51 z\"\n           id=\"path7\" />\n        <path\n           class=\"cls-5\"\n           d=\"M 12,43.23 A 1.52,1.52 0 1 0 13.51,44.75 1.52,1.52 0 0 0 12,43.23 Z m 0.43,1.41 a 0.41,0.41 0 0 1 -0.41,-0.41 0.41,0.41 0 0 1 0.82,0 0.41,0.41 0 0 1 -0.43,0.41 z\"\n           id=\"path8\" />\n        <path\n           class=\"cls-5\"\n           d=\"m 26.92,43.23 a 1.52,1.52 0 1 0 1.52,1.52 1.52,1.52 0 0 0 -1.52,-1.52 z m 0.43,1.41 a 0.42,0.42 0 0 1 -0.41,-0.41 0.42,0.42 0 0 1 0.83,0 0.42,0.42 0 0 1 -0.42,0.41 z\"\n           id=\"path9\" />\n        <ellipse\n           class=\"cls-7\"\n           cx=\"19.73\"\n           cy=\"45.32\"\n           rx=\"14.1\"\n           ry=\"10.16\"\n           id=\"ellipse9\" />\n        <path\n           class=\"cls-2\"\n           d=\"M 36.8,39.67 V 33 a 2.45,2.45 0 0 0 1.92,-2.28 2.65,2.65 0 0 0 -5.27,0 2.44,2.44 0 0 0 1.91,2.28 v 6.5 H 35.17 C 33.17,32.56 27.26,28.25 19.55,28.25 11.84,28.25 5.89,32.52 3.92,39.5 H 3.25 a 2.75,2.75 0 0 0 -2.88,2.59 v 5.17 a 2.75,2.75 0 0 0 2.88,2.58 h 0.91 a 13.11,13.11 0 0 0 3.6,5.09 l -1.3,1.16 a 0.79,0.79 0 0 0 -0.09,1.12 c 2.92,3.53 7.71,5.6 13.13,5.6 5.42,0 10.21,-2 13.13,-5.6 a 0.79,0.79 0 0 0 -0.09,-1.12 l -1.3,-1.16 a 13.34,13.34 0 0 0 3.6,-5.09 h 1 a 2.75,2.75 0 0 0 2.88,-2.58 V 42.09 A 2.62,2.62 0 0 0 36.8,39.67 Z M 19.55,35.62 c 7.14,0 12.94,4.7 12.94,10.47 0,6.25 -6.52,9 -12.94,9 -6.42,0 -12.94,-2.8 -12.94,-9 0,-5.77 5.8,-10.47 12.94,-10.47 z\"\n           id=\"path10\" />\n        <path\n           class=\"cls-8\"\n           d=\"m 37.28,45.53 h -1.92 c 0,-0.3 0,-0.6 0,-0.94 a 19.35,19.35 0 0 0 -0.38,-3.8 h 0.81 a 1.35,1.35 0 0 1 1.44,1.3 z\"\n           id=\"path11\" />\n        <path\n           class=\"cls-8\"\n           d=\"m 35.84,48.55 h -1 a 16.69,16.69 0 0 0 0.43,-2.15 h 2 v 0.86 a 1.34,1.34 0 0 1 -1.43,1.29 z\"\n           id=\"path12\" />\n        <path\n           class=\"cls-8\"\n           d=\"m 19.55,61.48 c -4.8,0 -9.06,-1.73 -11.75,-4.79 l 1.35,-1.2 a 17.86,17.86 0 0 0 10.4,3 17.89,17.89 0 0 0 10.4,-3 l 1.34,1.2 c -2.68,3.06 -6.95,4.79 -11.74,4.79 z\"\n           id=\"path13\" />\n        <path\n           class=\"cls-8\"\n           d=\"m 3.25,40.79 h 0.86 a 19.66,19.66 0 0 0 -0.38,3.8 6.18,6.18 0 0 0 0,0.94 H 1.86 v -3.44 a 1.28,1.28 0 0 1 1.39,-1.3 z\"\n           id=\"path14\" />\n        <path\n           d=\"m 19.55,34.76 a 17.4,17.4 0 0 0 -4.8,0.69 v -5.21 a 17.14,17.14 0 0 1 4.8,-0.65 17.12,17.12 0 0 1 4.79,0.65 v 5.25 a 16,16 0 0 0 -4.79,-0.73 z\"\n           id=\"path15\" />\n        <path\n           class=\"cls-8\"\n           d=\"M 13.8,30.54 V 35.8 C 9,37.56 5.65,41.53 5.65,46.09 5.65,52 11.26,56 19.55,56 c 8.29,0 13.9,-4 13.9,-9.91 0,-4.56 -3.36,-8.53 -8.15,-10.29 v -5.26 c 5.61,2 9.11,7.19 9.11,14.09 0,7.76 -5.95,13 -14.86,13 -8.91,0 -14.86,-5.21 -14.86,-13 0,-6.9 3.5,-12.07 9.11,-14.09 z\"\n           id=\"path16\" />\n        <path\n           class=\"cls-8\"\n           d=\"m 1.81,46.4 h 2 a 15.15,15.15 0 0 0 0.43,2.15 h -1 A 1.35,1.35 0 0 1 1.8,47.26 Z\"\n           id=\"path17\" />\n        <ellipse\n           class=\"cls-8\"\n           cx=\"36.080002\"\n           cy=\"30.67\"\n           rx=\"1.2\"\n           ry=\"1.08\"\n           id=\"ellipse17\" />\n      </g>\n    </g>\n  </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/type-24.svg":
/*!*********************************!*\
  !*** ./style/icons/type-24.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"M3 3.75A.75.75 0 013.75 3h16a.75.75 0 01.75.75v2.5a.75.75 0 01-1.5 0V4.5h-6.5v15h2a.75.75 0 010 1.5H9a.75.75 0 010-1.5h2v-15H4.5v1.75a.75.75 0 01-1.5 0v-2.5z\"/></svg>";

/***/ }),

/***/ "./style/icons/unlock-16.svg":
/*!***********************************!*\
  !*** ./style/icons/unlock-16.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M10.239 2.25A2.46 2.46 0 0112 1.5c.657 0 1.29.267 1.761.75.471.483.739 1.142.739 1.833a.75.75 0 001.5 0 4.127 4.127 0 00-1.165-2.88A3.96 3.96 0 0012 0a3.96 3.96 0 00-2.835 1.203A4.127 4.127 0 008 4.083V5H2.25A2.25 2.25 0 000 7.25v5.5A2.25 2.25 0 002.25 15h7.5A2.25 2.25 0 0012 12.75v-5.5A2.25 2.25 0 009.75 5H9.5v-.917c0-.69.268-1.35.739-1.833zm-8.739 5a.75.75 0 01.75-.75h7.5a.75.75 0 01.75.75v5.5a.75.75 0 01-.75.75h-7.5a.75.75 0 01-.75-.75v-5.5z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/x-16.svg":
/*!******************************!*\
  !*** ./style/icons/x-16.svg ***!
  \******************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" d=\"M12.78 4.28a.75.75 0 00-1.06-1.06L8 6.94 4.28 3.22a.75.75 0 00-1.06 1.06L6.94 8l-3.72 3.72a.75.75 0 101.06 1.06L8 9.06l3.72 3.72a.75.75 0 101.06-1.06L9.06 8l3.72-3.72z\"/></svg>";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.b69d58c155f2f0f7caf9.js.map