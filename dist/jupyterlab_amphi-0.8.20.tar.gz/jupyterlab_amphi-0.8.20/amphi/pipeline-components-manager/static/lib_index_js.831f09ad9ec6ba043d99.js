"use strict";
(self["webpackChunk_amphi_pipeline_components_manager"] = self["webpackChunk_amphi_pipeline_components_manager"] || []).push([["lib_index_js"],{

/***/ "./lib/BrowseFileDialog.js":
/*!*********************************!*\
  !*** ./lib/BrowseFileDialog.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   showBrowseFileDialog: () => (/* binding */ showBrowseFileDialog)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);



const BROWSE_FILE_CLASS = 'amphi-browseFileDialog';
const BROWSE_FILE_OPEN_CLASS = 'amphi-browseFileDialog-open';
/**
 * Breadcrumbs widget for browse file dialog body.
 */
class BrowseFileDialogBreadcrumbs extends _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.BreadCrumbs {
    constructor(options) {
        super(options);
        this.model = options.model;
        this.rootPath = options.rootPath;
    }
    onUpdateRequest(msg) {
        super.onUpdateRequest(msg);
        const contents = this.model.manager.services.contents;
        const localPath = contents.localPath(this.model.path);
        // if 'rootPath' is defined prevent navigating to it's parent/grandparent directories
        if (localPath && this.rootPath && localPath.indexOf(this.rootPath) === 0) {
            const breadcrumbs = document.querySelectorAll('.amphi-browseFileDialog .jp-BreadCrumbs > span[title]');
            breadcrumbs.forEach((crumb) => {
                var _a;
                if (crumb.title.indexOf((_a = this.rootPath) !== null && _a !== void 0 ? _a : '') === 0) {
                    crumb.className = crumb.className
                        .replace('amphi-BreadCrumbs-disabled', '')
                        .trim();
                }
                else if (crumb.className.indexOf('amphi-BreadCrumbs-disabled') === -1) {
                    crumb.className += ' amphi-BreadCrumbs-disabled';
                }
            });
        }
    }
}
/**
 * Browse dialog modal
 */
class BrowseFileDialog extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget {
    constructor(props) {
        super(props);
        this.model = new _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.FilterFileBrowserModel({
            manager: props.manager,
            filter: props.filter
        });
        const layout = (this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout());
        this.directoryListing = new _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.DirListing({
            model: this.model
        });
        this.acceptFileOnDblClick = props.acceptFileOnDblClick;
        this.multiselect = props.multiselect;
        this.includeDir = props.includeDir;
        this.dirListingHandleEvent = this.directoryListing.handleEvent;
        this.directoryListing.handleEvent = (event) => {
            this.handleEvent(event);
        };
        this.breadCrumbs = new BrowseFileDialogBreadcrumbs({
            model: this.model,
            rootPath: props.rootPath
        });
        layout.addWidget(this.breadCrumbs);
        layout.addWidget(this.directoryListing);
    }
    static async init(options) {
        const filterFunction = options.extensions && options.extensions.length > 0
            ? (model) => {
                // Always include directories
                if (model.type === 'directory') {
                    return true;
                }
                // Check if the file extension matches any of the specified extensions
                const fileExtension = `.${model.name.split('.').pop().toLowerCase()}`;
                return options.extensions.includes(fileExtension);
            }
            : options.filter || (() => true); // Default filter that includes everything
        const browseFileDialog = new BrowseFileDialog({
            manager: options.manager,
            filter: filterFunction,
            multiselect: options.multiselect,
            includeDir: options.includeDir,
            rootPath: options.rootPath,
            startPath: options.startPath,
            acceptFileOnDblClick: options.acceptFileOnDblClick,
        });
        if (options.startPath) {
            if (!options.rootPath ||
                options.startPath.indexOf(options.rootPath) === 0) {
                await browseFileDialog.model.cd(options.startPath);
            }
        }
        else if (options.rootPath) {
            await browseFileDialog.model.cd(options.rootPath);
        }
        return browseFileDialog;
    }
    getValue() {
        const selected = [];
        let item = null;
        for (const item of this.directoryListing.selectedItems()) {
            if (this.includeDir || item.type !== 'directory') {
                selected.push(item);
            }
        }
        return selected;
    }
    handleEvent(event) {
        let modifierKey = false;
        if (event instanceof MouseEvent) {
            modifierKey =
                event.shiftKey || event.metaKey;
        }
        else if (event instanceof KeyboardEvent) {
            modifierKey =
                event.shiftKey || event.metaKey;
        }
        switch (event.type) {
            case 'keydown':
            case 'keyup':
            case 'mousedown':
            case 'mouseup':
            case 'click':
                if (this.multiselect || !modifierKey) {
                    this.dirListingHandleEvent.call(this.directoryListing, event);
                }
                break;
            case 'dblclick': {
                const clickedItem = this.directoryListing.modelForClick(event);
                if ((clickedItem === null || clickedItem === void 0 ? void 0 : clickedItem.type) === 'directory') {
                    this.dirListingHandleEvent.call(this.directoryListing, event);
                }
                else {
                    event.preventDefault();
                    event.stopPropagation();
                    if (this.acceptFileOnDblClick) {
                        const okButton = document.querySelector(`.${BROWSE_FILE_OPEN_CLASS} .jp-mod-accept`);
                        if (okButton) {
                            okButton.click();
                        }
                    }
                }
                break;
            }
            default:
                this.dirListingHandleEvent.call(this.directoryListing, event);
                break;
        }
    }
}
const showBrowseFileDialog = async (manager, options) => {
    const browseFileDialogBody = await BrowseFileDialog.init({
        manager: manager,
        filter: options.filter,
        multiselect: options.multiselect,
        includeDir: options.includeDir,
        rootPath: options.rootPath,
        startPath: options.startPath,
        acceptFileOnDblClick: Object.prototype.hasOwnProperty.call(options, 'acceptFileOnDblClick')
            ? options.acceptFileOnDblClick
            : true
    });
    const dialog = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog({
        title: 'Select a file',
        body: browseFileDialogBody,
        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.cancelButton(), _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton({ label: 'Select' })]
    });
    dialog.addClass(BROWSE_FILE_CLASS);
    document.body.className += ` ${BROWSE_FILE_OPEN_CLASS}`;
    return dialog.launch().then((result) => {
        document.body.className = document.body.className
            .replace(BROWSE_FILE_OPEN_CLASS, '')
            .trim();
        if (options.rootPath && result.button.accept && result.value.length) {
            const relativeToPath = options.rootPath.endsWith('/')
                ? options.rootPath
                : options.rootPath + '/';
            result.value.forEach((val) => {
                val.path = val.path.replace(relativeToPath, '');
            });
        }
        return result;
    });
};


/***/ }),

/***/ "./lib/CodeGenerator.js":
/*!******************************!*\
  !*** ./lib/CodeGenerator.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeGenerator: () => (/* binding */ CodeGenerator)
/* harmony export */ });
/* harmony import */ var _PipelineService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PipelineService */ "./lib/PipelineService.js");
var _a;

class CodeGenerator {
    static generateCode(pipelineJson, commands, componentService, variablesAutoNaming) {
        try {
            const { codeList, incrementalCodeList, executedNodes } = this.generateCodeForNodes(_PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.filterPipeline(pipelineJson), componentService, 'none', true, variablesAutoNaming);
            const code = codeList.join('\n');
            return code;
        }
        catch (error) {
            throw new Error(`Error in generateCodeForNodes: ${error}`);
        }
    }
    static generateCodeUntil(pipelineJson, commands, componentService, targetNode, incremental, variablesAutoNaming) {
        var _b;
        const flow = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.filterPipeline(pipelineJson);
        // Check if any node is missing the 'name' attribute which means legacy pipeline
        if (flow.nodes.some((node) => !node.data.nameId)) {
            variablesAutoNaming = true;
        }
        // Get nodes to traverse and related data
        const { nodesToTraverse, nodesMap } = this.computeNodesToTraverse(flow, targetNode, componentService);
        // Initialize fromStart to false
        let fromStart = false;
        let maxLastUpdated = 0;
        // For each node in nodesToTraverse except the target node
        for (const nodeId of nodesToTraverse) {
            if (nodeId === targetNode) {
                continue; // Skip target node
            }
            const node = nodesMap.get(nodeId);
            if (!node) {
                console.error(`Node with id ${nodeId} not found.`);
                continue;
            }
            const data = node.data || {};
            const lastUpdated = data.lastUpdated || 0;
            const lastExecuted = data.lastExecuted || 0;
            if (lastUpdated > maxLastUpdated) {
                maxLastUpdated = lastUpdated;
            }
            if (lastUpdated >= lastExecuted) {
                fromStart = true;
                // console.log(`Node ${nodeId} has been updated since last execution.`);
                break; // No need to check further
            }
        }
        // Transition
        if (variablesAutoNaming) {
            fromStart = true;
        }
        // Generate code and collect executed node IDs
        try {
            // Generate code and collect executed node IDs
            const { codeList, incrementalCodeList, executedNodes } = this.generateCodeForNodes(flow, componentService, targetNode, fromStart, variablesAutoNaming);
            if (fromStart) {
                console.log("Generating code from start due to updates in previous nodes. (fromStart: true)");
                const command = 'pipeline-metadata-panel:delete-all';
                commands.execute(command, {}).catch((reason) => {
                    console.error(`An error occurred during the execution of ${command}.\n${reason}`);
                });
            }
            else {
                console.log("No updates in previous nodes. Generating code for target node only.");
            }
            // After execution, update lastExecuted for all executed nodes
            const currentTimestamp = Date.now();
            executedNodes.forEach((nodeId) => {
                const node = nodesMap.get(nodeId);
                if (node && node.data) {
                    node.data.lastExecuted = currentTimestamp;
                }
            });
            // Also update lastExecuted for the target node
            const targetNodeData = (_b = nodesMap.get(targetNode)) === null || _b === void 0 ? void 0 : _b.data;
            if (targetNodeData) {
                targetNodeData.lastExecuted = currentTimestamp;
            }
            if (incremental) {
                return incrementalCodeList;
            }
            else {
                return codeList;
            }
        }
        catch (error) {
            throw new Error(`Error in generateCodeForNodes: ${error}`);
        }
    }
    // External function to compute nodes to traverse and related data
    static computeNodesToTraverse(flow, targetNodeId, componentService) {
        const nodesMap = new Map();
        const nodeDependencies = new Map(); // To keep track of node dependencies
        const sortedNodes = []; // To store the topologically sorted nodes
        // Add all pipeline nodes to nodesMap, except annotations and specific types
        flow.nodes.forEach(node => {
            const type = componentService.getComponent(node.type)._type;
            if (type !== 'annotation' &&
                type !== 'logger' &&
                type !== 'env_variables' &&
                type !== 'env_file' &&
                type !== 'connection') {
                nodesMap.set(node.id, node);
            }
        });
        // Topological sort with path tracking
        const visited = new Set();
        const nodePaths = new Map();
        const topologicalSortWithPathTracking = (nodeId, path) => {
            if (visited.has(nodeId)) {
                // Combine the current path with the existing path for the node
                const existingPath = nodePaths.get(nodeId) || new Set();
                nodePaths.set(nodeId, new Set([...existingPath, ...path]));
                return;
            }
            visited.add(nodeId);
            const dependencies = flow.edges
                .filter(edge => edge.target === nodeId)
                .map(edge => edge.source);
            nodeDependencies.set(nodeId, dependencies);
            // Include the current node in the path for subsequent calls
            const currentPath = new Set([...path, nodeId]);
            nodePaths.set(nodeId, currentPath);
            dependencies.forEach(dependency => {
                topologicalSortWithPathTracking(dependency, currentPath);
            });
            sortedNodes.push(nodeId);
        };
        // Perform topological sort with path tracking
        flow.nodes.forEach(node => {
            if (!visited.has(node.id)) {
                topologicalSortWithPathTracking(node.id, new Set());
            }
        });
        // Determine nodes to traverse based on the targetNodeId
        let nodesToTraverse = [];
        if (targetNodeId !== 'none') {
            const nodesToConsider = new Set([targetNodeId]);
            const pathToTarget = new Set();
            while (nodesToConsider.size > 0) {
                const nextNodesToConsider = new Set();
                nodesToConsider.forEach(nodeId => {
                    pathToTarget.add(nodeId);
                    const dependencies = nodeDependencies.get(nodeId) || [];
                    dependencies.forEach(dep => {
                        if (!pathToTarget.has(dep)) {
                            nextNodesToConsider.add(dep);
                        }
                    });
                });
                nodesToConsider.clear();
                nextNodesToConsider.forEach(nodeId => nodesToConsider.add(nodeId));
            }
            // Filter the sortedNodes to include only those in pathToTarget, preserving the topological order
            nodesToTraverse = sortedNodes.filter(nodeId => pathToTarget.has(nodeId));
        }
        else {
            nodesToTraverse = sortedNodes;
        }
        return { nodesToTraverse, nodesMap, nodeDependencies, sortedNodes };
    }
    static formatVariables(code) {
        const lines = code.split('\n');
        const transformedLines = lines.map(line => {
            if (/r(['"]).*\1/.test(line) || /f(['"])/.test(line) || /f("""|''')/.test(line)) {
                return line; // Return the line as-is if it's an actual raw string or an f-string
            }
            return line
                .replace(/(['"])\{(\w+)\}\1/g, '$2') // Remove quotes for standalone variables
                .replace(/(['"])(.*\{.*\}.*)\1/g, 'f$1$2$1') // Convert to f-string for multiple variables
                .replace(/(f?"""\s*)(.*\{.*\}.*)(\s*""")/g, 'f"""$2"""'); // Convert triple quotes to f-strings, avoid double f
        });
        return transformedLines.join('\n');
    }
    static getEnvironmentVariableCode(pipelineJson, componentService) {
        const flow = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.filterPipeline(pipelineJson);
        const envVariablesMap = new Map();
        const uniqueImports = new Set();
        // Collect environment variable nodes
        flow.nodes.forEach(node => {
            const type = componentService.getComponent(node.type)._type;
            if (type === 'env_variables' || type === 'env_file') {
                envVariablesMap.set(node.id, node);
            }
        });
        let envVariablesCode = '';
        if (envVariablesMap.size > 0) {
            envVariablesMap.forEach((node, nodeId) => {
                const component = componentService.getComponent(node.type);
                let config = node.data;
                // Gather imports
                const imports = component.provideImports({ config });
                imports.forEach(importStatement => uniqueImports.add(importStatement));
                // Generate code for this environment variable component
                envVariablesCode += component.generateComponentCode({ config });
            });
            // Combine imports and environment variables code
            const importsCode = Array.from(uniqueImports).join('\n');
            return `${importsCode}\n\n${envVariablesCode}`;
        }
        else {
            return '# No environment variable components found.';
        }
    }
    static getConnectionCode(pipelineJson, componentService) {
        const flow = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.filterPipeline(pipelineJson);
        const connectionsMap = new Map();
        const uniqueImports = new Set();
        // Collect connection nodes
        flow.nodes.forEach(node => {
            const type = componentService.getComponent(node.type)._type;
            if (type === 'connection') {
                connectionsMap.set(node.id, node);
            }
        });
        let connectionsCode = '';
        if (connectionsMap.size > 0) {
            connectionsMap.forEach((node, nodeId) => {
                const component = componentService.getComponent(node.type);
                let config = node.data;
                // Gather imports
                const imports = component.provideImports({ config });
                imports.forEach(importStatement => uniqueImports.add(importStatement));
                // Generate code for this connection component
                connectionsCode += component.generateComponentCode({ config });
            });
            // Combine imports and connections code
            const importsCode = Array.from(uniqueImports).join('\n');
            return `${importsCode}\n\n${connectionsCode}`;
        }
        else {
            return '# No connection components found.';
        }
    }
    static getComponentAndDataForNode(nodeId, componentService, pipelineJson) {
        const flow = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.filterPipeline(pipelineJson);
        // Find the node by nodeId
        const node = flow.nodes.find((n) => n.id === nodeId);
        if (!node) {
            console.error(`Node with id ${nodeId} not found.`);
            return null;
        }
        // Get the component type and the component instance
        const component = componentService.getComponent(node.type);
        if (!component) {
            console.error(`Component for node type ${node.type} not found.`);
            return null;
        }
        // Return the component and the node's data
        return { component, data: node.data };
    }
}
_a = CodeGenerator;
CodeGenerator.generateCodeForNodes = (flow, componentService, targetNodeId, fromStart, variablesAutoNaming) => {
    // Initialization
    const codeList = [];
    const incrementalCodeList = [];
    const executedNodes = new Set();
    const uniqueImports = new Set();
    const uniqueDependencies = new Set();
    const functions = new Set();
    const envVariablesMap = new Map();
    const connectionsMap = new Map();
    // Get nodes to traverse and related data
    const { nodesToTraverse, nodesMap } = _a.computeNodesToTraverse(flow, targetNodeId, componentService);
    // Categorize special nodes
    flow.nodes.forEach(node => {
        const type = componentService.getComponent(node.type)._type;
        if (type === 'env_variables' || type === 'env_file') {
            envVariablesMap.set(node.id, node);
        }
        else if (type === 'connection') {
            connectionsMap.set(node.id, node);
        }
    });
    // Create node objects
    try {
        const nodeObjects = _a.createNodeObjects(flow, componentService, nodesToTraverse, nodesMap, variablesAutoNaming);
        // Process node objects
        for (const nodeObject of nodeObjects) {
            // Add imports, dependencies, and functions
            nodeObject.imports.forEach(importStatement => uniqueImports.add(importStatement));
            nodeObject.dependencies.forEach(dep => uniqueDependencies.add(dep));
            nodeObject.functions.forEach(func => functions.add(func));
            // Combine the code, imports, dependencies, and functions for the incremental code list
            const nodeCode = [
                ...nodeObject.imports,
                ...nodeObject.functions,
                nodeObject.code
            ].join('\n');
            incrementalCodeList.push({ code: nodeCode, nodeId: nodeObject.id });
            // Add code to codeList
            codeList.push(nodeObject.code);
            executedNodes.add(nodeObject.id);
            // Handle target node
            if (nodeObject.id === targetNodeId) {
                let displayCode = '';
                if (nodeObject.type.includes('processor') || nodeObject.type.includes('input')) {
                    if (nodeObject.type.includes('documents')) {
                        if (!fromStart) {
                            console.log(`Generate code from last component. (fromStart: false)`);
                            codeList.length = 0;
                            codeList.push(nodeObject.code);
                            executedNodes.clear();
                            executedNodes.add(nodeObject.id);
                        }
                        displayCode = `\n_amphi_display_documents_as_html(${nodeObject.outputName})`;
                    }
                    else {
                        if (!fromStart) {
                            console.log(`Generate code from last component. (fromStart: false)`);
                            codeList.length = 0;
                            codeList.push(nodeObject.code);
                            executedNodes.clear();
                            executedNodes.add(nodeObject.id);
                        }
                        displayCode = `\n__amphi_display_dataframe(${nodeObject.outputName}, dfName="${nodeObject.outputName}", nodeId="${targetNodeId}"${nodeObject.runtime !== "local" ? `, runtime="${nodeObject.runtime}"` : ''})`;
                    }
                    // Append display code to both codeList and the last element of incrementalCodeList
                    codeList.push(displayCode);
                    if (incrementalCodeList.length > 0) {
                        incrementalCodeList[incrementalCodeList.length - 1].code += displayCode;
                    }
                }
                else if (nodeObject.type.includes('output')) {
                    // Add try block and indent existing code
                    // Combine all the code from codeList into one string
                    const combinedCode = codeList.join('\n');
                    // Indent the combined code
                    const indentedCode = combinedCode.split('\n').map(line => '    ' + line).join('\n');
                    // Clear the existing codeList to replace with the new structure
                    codeList.length = 0;
                    // Wrap the indented code with try-except block and append it to codeList
                    codeList.push('try:\n' + indentedCode);
                    codeList.push('    print("Execution has been successful")\n');
                    codeList.push('except Exception as e:\n');
                    codeList.push('    print(f"Execution failed with error {e}")\n');
                    codeList.push('    raise\n');
                }
            }
        }
        // Generate code for special nodes
        let envVariablesCode = '';
        envVariablesMap.forEach((node) => {
            const component = componentService.getComponent(node.type);
            const config = node.data;
            envVariablesCode += component.generateComponentCode({ config });
            component.provideImports({ config }).forEach(importStatement => uniqueImports.add(importStatement));
        });
        let connectionsCode = '';
        connectionsMap.forEach((node) => {
            const component = componentService.getComponent(node.type);
            const config = node.data;
            connectionsCode += component.generateComponentCode({ config });
            component.provideImports({ config }).forEach(importStatement => uniqueImports.add(importStatement));
        });
        // Prepare final code list
        const currentDate = new Date();
        const dateString = currentDate.toISOString().replace(/T/, ' ').replace(/\..+/, '');
        const dateComment = `# Source code generated by Amphi\n# Date: ${dateString}`;
        const additionalImports = `# Additional dependencies: ${Array.from(uniqueDependencies).join(', ')}`;
        const generatedCodeList = [
            dateComment,
            additionalImports,
            ...Array.from(uniqueImports),
            envVariablesCode,
            connectionsCode,
            ...Array.from(functions),
            ...codeList
        ].filter(Boolean); // Remove empty strings
        // Format variables in the generated code
        const formattedCodeList = generatedCodeList.map(code => _a.formatVariables(code));
        return { codeList: formattedCodeList, incrementalCodeList, executedNodes };
    }
    catch (error) {
        throw new Error(`Error in createNodeObjects: ${error}`);
    }
};
CodeGenerator.createNodeObjects = (flow, componentService, nodesToTraverse, nodesMap, variablesAutoNaming) => {
    var _b;
    const nodeObjects = [];
    const counters = new Map();
    const nodeOutputs = new Map();
    function incrementCounter(key) {
        const count = counters.get(key) || 0;
        counters.set(key, count + 1);
        return count + 1;
    }
    // Helper function to validate input names
    function getInputName(nodeId, context) {
        const name = nodeOutputs.get(nodeId);
        if (!name) {
            throw new Error(`Input name is undefined for node ${nodeId} in context: ${context}`);
        }
        return name;
    }
    function getOutputName(node, componentId, variablesAutoNaming) {
        let name = '';
        if (variablesAutoNaming) {
            name = `${node.type}${incrementCounter(componentId)}`;
        }
        else {
            name = `${node.data.nameId}`;
        }
        return name;
    }
    for (const nodeId of nodesToTraverse) {
        const node = nodesMap.get(nodeId);
        if (!node) {
            console.error(`Node with id ${nodeId} not found.`);
            continue;
        }
        const config = node.data;
        const component = componentService.getComponent(node.type);
        const componentType = component._type;
        const componentId = component._id;
        const imports = component.provideImports({ config });
        const dependencies = typeof component.provideDependencies === 'function'
            ? component.provideDependencies({ config })
            : [];
        const functions = typeof component.provideFunctions === 'function'
            ? component.provideFunctions({ config })
            : [];
        let inputName = '';
        let outputName = '';
        let code = '';
        if (config.customTitle) {
            const generatedCode = component.generateComponentCode({ config });
            const needsNewLine = !generatedCode.startsWith('\n');
            code += `\n# ${config.customTitle}${needsNewLine ? '\n' : ''}`;
        }
        try {
            switch (componentType) {
                case 'pandas_df_processor':
                case 'pandas_df_to_documents_processor':
                case 'ibis_df_processor':
                case 'documents_processor': {
                    const previousNodeId = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.findPreviousNodeId(flow, nodeId);
                    inputName = getInputName(previousNodeId, componentType);
                    outputName = getOutputName(node, componentId, variablesAutoNaming);
                    nodeOutputs.set(nodeId, outputName);
                    code += component.generateComponentCode({ config, inputName, outputName });
                    break;
                }
                case 'ibis_df_double_processor':
                case 'pandas_df_double_processor': {
                    const [input1Id, input2Id] = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.findMultiplePreviousNodeIds(flow, nodeId);
                    const inputName1 = getInputName(input1Id, componentType);
                    const inputName2 = getInputName(input2Id, componentType);
                    outputName = getOutputName(node, componentId, variablesAutoNaming);
                    nodeOutputs.set(nodeId, outputName);
                    code += component.generateComponentCode({ config, inputName1, inputName2, outputName });
                    break;
                }
                case 'ibis_df_multi_processor':
                case 'pandas_df_multi_processor': {
                    const inputIds = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.findMultiplePreviousNodeIds(flow, nodeId);
                    const inputNames = inputIds.map(id => getInputName(id, componentType));
                    outputName = getOutputName(node, componentId, variablesAutoNaming);
                    nodeOutputs.set(nodeId, outputName);
                    code += component.generateComponentCode({ config, inputNames, outputName });
                    break;
                }
                case 'pandas_df_input':
                case 'documents_input': {
                    outputName = getOutputName(node, componentId, variablesAutoNaming);
                    nodeOutputs.set(nodeId, outputName);
                    code += component.generateComponentCode({ config, outputName });
                    break;
                }
                case 'ibis_df_input': {
                    outputName = getOutputName(node, componentId, variablesAutoNaming);
                    nodeOutputs.set(nodeId, outputName);
                    // Find the nodes that follow this input node
                    const nextNodeIds = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.findNextNodeIds(flow, nodeId);
                    let uniqueEngineName = undefined;
                    for (const nextNodeId of nextNodeIds) {
                        const nextNode = nodesMap.get(nextNodeId);
                        if (nextNode) {
                            const nextComponent = componentService.getComponent(nextNode.type);
                            const nextComponentType = nextComponent._type;
                            if (nextComponentType === 'ibis_df_double_processor') {
                                // Get previous nodes connected to the join node
                                const previousNodeIds = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.findMultiplePreviousNodeIds(flow, nextNodeId);
                                if (previousNodeIds.length > 1) {
                                    // Find the other input node ID (excluding current node)
                                    const otherNodeId = previousNodeIds.find(id => id !== nodeId);
                                    if (otherNodeId && nodeOutputs.has(otherNodeId)) {
                                        const otherOutputName = getInputName(otherNodeId, 'ibis_df_double_processor');
                                        uniqueEngineName = `${otherOutputName}_backend`;
                                        break; // Stop after finding the first matching join node
                                    }
                                }
                            }
                        }
                    }
                    // Generate code with or without uniqueEngineName
                    if (uniqueEngineName) {
                        code += component.generateComponentCode({ config, outputName, uniqueEngineName });
                    }
                    else {
                        code += component.generateComponentCode({ config, outputName });
                    }
                    break;
                }
                case 'ibis_df_output':
                case 'pandas_df_output':
                case 'documents_output': {
                    const previousNodeId = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.findPreviousNodeId(flow, nodeId);
                    inputName = getInputName(previousNodeId, componentType);
                    code += component.generateComponentCode({ config, inputName });
                    break;
                }
                default:
                    throw new Error(`Pipeline Configuration Error: ${componentType} for node ${nodeId}`);
            }
            nodeObjects.push({
                id: nodeId,
                title: config.customTitle || node.type,
                imports,
                dependencies,
                type: componentType,
                code,
                outputName,
                functions,
                lastUpdated: config.lastUpdated || 0,
                lastExecuted: config.lastExecuted || 0,
                runtime: ((_b = config.backend) === null || _b === void 0 ? void 0 : _b.engine) || "local"
            });
        }
        catch (error) {
            console.error(`Error processing node ${nodeId}:`, error);
            throw error; // Stop and throw error...
        }
    }
    return nodeObjects;
};
;


/***/ }),

/***/ "./lib/DndProviderWrapper.js":
/*!***********************************!*\
  !*** ./lib/DndProviderWrapper.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dnd */ "webpack/sharing/consume/default/react-dnd/react-dnd");
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dnd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dnd-html5-backend */ "webpack/sharing/consume/default/react-dnd-html5-backend/react-dnd-html5-backend");
/* harmony import */ var react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_2__);
// DndProviderWrapper.tsx



const DndProviderWrapper = ({ children }) => {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [dndArea, setDnDArea] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(context.current);
    const updateDndArea = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        setDnDArea(context === null || context === void 0 ? void 0 : context.current);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        updateDndArea();
    }, [updateDndArea]);
    const html5Options = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({ rootElement: dndArea }), [dndArea]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: context }, dndArea && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_dnd__WEBPACK_IMPORTED_MODULE_1__.DndProvider, { backend: react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_2__.HTML5Backend, options: html5Options }, children))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DndProviderWrapper);


/***/ }),

/***/ "./lib/PipelineComponent.js":
/*!**********************************!*\
  !*** ./lib/PipelineComponent.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PipelineComponent: () => (/* binding */ PipelineComponent)
/* harmony export */ });
function PipelineComponent() {
    return class {
        constructor() { }
        static getInstance() {
            if (!this.instance) {
                this.instance = new this();
            }
            return this.instance;
        }
        static get Name() {
            const instance = this.getInstance();
            return instance._name;
        }
        static get Type() {
            const instance = this.getInstance();
            return instance._type;
        }
        // Static getter for the icon
        static get Icon() {
            const instance = this.getInstance();
            return instance._icon;
        }
        // Static getter for the default config
        static get Default() {
            const instance = this.getInstance();
            return instance._default;
        }
        // Static getter for the default config
        static get Form() {
            const instance = this.getInstance();
            return instance._form;
        }
        // Static method to update the type
        static updateType(newType) {
            const instance = this.getInstance();
            instance._type = newType;
        }
    };
}


/***/ }),

/***/ "./lib/PipelineService.js":
/*!********************************!*\
  !*** ./lib/PipelineService.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PipelineService: () => (/* binding */ PipelineService)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);

class PipelineService {
    static filterPipeline(pipelineJson) {
        const pipeline = JSON.parse(pipelineJson);
        const pipelineFlow = pipeline.pipelines[0].flow;
        const filteredNodes = pipelineFlow.nodes.map(({ id, type, data }) => ({ id, type, data }));
        const filteredEdges = pipelineFlow.edges.map(({ id, source, target, targetHandle }) => ({ id, source, target, targetHandle }));
        const flow = {
            "nodes": filteredNodes,
            "edges": filteredEdges
        };
        return flow;
    }
    // Function to retrieve the names of packages
    static extractPackageNames(imports) {
        const standardLibraries = new Set(['json', 'pandas']);
        return imports.map((imp) => {
            let packageName = "";
            if (imp.startsWith("import ")) {
                packageName = imp.split(" ")[1].split(" as ")[0]; // For "import packageName" format
            }
            else if (imp.startsWith("from ")) {
                packageName = imp.split(" ")[1]; // For "from packageName import something" format
            }
            else {
                packageName = imp; // Assuming direct package name
            }
            if (!standardLibraries.has(packageName)) {
                return packageName;
            }
            return ""; // Return an empty string for packages in the standardLibraries set
        }).filter((pkgName, index, self) => pkgName && self.indexOf(pkgName) === index); // Removing empty strings, duplicates
    }
    static findNextNodeIds(flow, nodeId) {
        return flow.edges
            .filter(edge => edge.source === nodeId)
            .map(edge => edge.target);
    }
    // Function to generate pip install commands from a list of package names
    static getInstallCommandsFromPackageNames(packageNames) {
        return packageNames
            .filter(pkgName => pkgName.trim() !== '')
            .map(pkgName => {
            if (pkgName.includes('[')) {
                // Direct pip install for packages with extras (e.g., `ibis-framework[snowflake]`)
                return `!pip install ${pkgName} -q -q`;
            }
            else {
                // Standard check for regular packages
                return `
try:
    __import__("${pkgName}")
    print('${pkgName} is already installed')
except ImportError:
    !pip install ${pkgName} -q -q`;
            }
        });
    }
    static extractPythonImportPackages(code) {
        // Regular expression to match Python import statements
        const importRegex = /^(import .+|from .+? import .+)/gm;
        let matches = code.match(importRegex) || [];
        // Process each match to format correctly
        return matches.map((importStatement) => {
            if (importStatement.startsWith('from')) {
                // If the statement starts with 'from', extract the package part before the first dot
                return importStatement.split(' ')[1].split('.')[0];
            }
            else {
                // Otherwise, it's a regular import, extract everything after 'import '
                return importStatement.split(' ')[1];
            }
        });
    }
    /**
     * Check if a given file is allowed to be added to the pipeline
     * @param item
     */
    static getPipelineRelativeNodePath(pipelinePath, nodePath) {
        const relativePath = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PathExt.relative(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PathExt.dirname(pipelinePath), nodePath);
        return relativePath;
    }
    static getComponentIdForFileExtension(fileExtension, componentService, defaultEngineBackend) {
        var _a, _b, _c, _d;
        // Extract file extension from item.name
        if (!fileExtension)
            return { id: null, default: null }; // Return nulls if there is no file extension
        // Retrieve all components
        const components = componentService.getComponents();
        // List to store matching components
        const matchingComponents = [];
        // Iterate through all components
        for (const component of components) {
            // Check if the component has the _fileDrop attribute and it contains the file extension
            if (component._fileDrop && component._fileDrop.includes(fileExtension.toLowerCase())) {
                // Store the component in the list if the file extension matches
                matchingComponents.push(component);
            }
        }
        if (matchingComponents.length === 1) {
            const component = matchingComponents[0];
            return { id: component._id, default: component._default || null };
        }
        // If multiple matching components are found, check for the one with backend.engine matching defaultEngineBackend
        for (const component of matchingComponents) {
            console.log("Component._default?.backend?.engine: %o", (_b = (_a = component._default) === null || _a === void 0 ? void 0 : _a.backend) === null || _b === void 0 ? void 0 : _b.engine);
            if (((_d = (_c = component._default) === null || _c === void 0 ? void 0 : _c.backend) === null || _d === void 0 ? void 0 : _d.engine) === defaultEngineBackend) {
                return { id: component._id, default: component._default || null };
            }
        }
        // If no match is found for defaultEngineBackend, return the first matching component
        if (matchingComponents.length > 0) {
            const component = matchingComponents[0];
            return { id: component._id, default: component._default || null };
        }
        // Return nulls if no matching component is found
        return { id: null, default: null };
    }
    static getLastUpdatedInPath(flow, targetId) {
        const visited = new Set();
        const lastUpdatedList = [];
        const findNodesInPath = (nodeId) => {
            if (visited.has(nodeId)) {
                return;
            }
            visited.add(nodeId);
            const node = flow.nodes.find(n => n.id === nodeId);
            if (node && node.data && node.data.lastUpdated) {
                lastUpdatedList.push(node.data.lastUpdated);
            }
            const dependencies = flow.edges
                .filter(edge => edge.target === nodeId)
                .map(edge => edge.source);
            dependencies.forEach(dependency => {
                findNodesInPath(dependency);
            });
        };
        findNodesInPath(targetId);
        return lastUpdatedList;
    }
    static getRelativePath(pipelinePath, selectedFilePath) {
        const pipelineDir = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PathExt.dirname(pipelinePath);
        const relativePath = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PathExt.relative(pipelineDir, selectedFilePath);
        return relativePath;
    }
    static getEnvironmentVariables(pipelineJson) {
        const flow = PipelineService.filterPipeline(pipelineJson);
        const envNodes = flow.nodes.filter(node => node.type === 'envVariables' || node.type === 'envFile');
        const variablesList = envNodes.reduce((acc, node) => {
            const variables = node.data.variables || [];
            return acc.concat(variables.map(variable => variable.name));
        }, []);
        return variablesList;
    }
    static getConnections(pipelineJson) {
        const flow = PipelineService.filterPipeline(pipelineJson);
        const connectionsNodes = flow.nodes.filter(node => node.type === 'connection');
        const connectionsList = connectionsNodes.reduce((acc, node) => {
            return acc.concat(node.data || []);
        }, []);
        // const envFileNodes = flow.nodes.filter(node => node.type === 'envFile' );
        return connectionsList;
    }
    static extractConnections(componentService) {
        const components = componentService.getComponents();
        const connectionMap = {};
        components.forEach(component => {
            if (component._form && component._form.fields) {
                component._form.fields.forEach(field => {
                    if (field.connection && !field.ignoreConnection) {
                        if (!connectionMap[field.connection]) {
                            connectionMap[field.connection] = [];
                        }
                        const existingField = connectionMap[field.connection].find(f => f.id === field.id);
                        if (!existingField) {
                            connectionMap[field.connection].push({ id: field.id, label: field.label });
                        }
                    }
                });
            }
        });
        return Object.keys(connectionMap).map(connection => ({
            connection,
            fields: connectionMap[connection]
        }));
    }
}
PipelineService.findStartNode = (flow, componentService) => {
    const targetMap = new Set();
    flow.edges.forEach(edge => targetMap.add(edge.target));
    for (const node of flow.nodes) {
        const nodeType = componentService.getComponent(node.type)._type;
        if (!targetMap.has(node.id) && (nodeType === "pandas_df_input" || nodeType === "ibis_df_input")) {
            return node.id;
        }
    }
    return null;
};
PipelineService.getNodeById = (pipelineJson, nodeId) => {
    const pipeline = JSON.parse(pipelineJson);
    const pipelineFlow = pipeline.pipelines[0].flow;
    const node = pipelineFlow.nodes.find((n) => n.id === nodeId);
    if (!node) {
        return null; // Return null if the node is not found
    }
    return node;
};
PipelineService.findStartNodes = (flow, componentService) => {
    const targetMap = new Set();
    flow.edges.forEach(edge => targetMap.add(edge.target));
    const startNodes = [];
    for (const node of flow.nodes) {
        const nodeType = componentService.getComponent(node.type)._type;
        if (!targetMap.has(node.id) && nodeType === "pandas_df_input") {
            startNodes.push(node.id);
            if (startNodes.length === 2) {
                // If we've found two start nodes, assume it's the double processor case
                return startNodes;
            }
        }
    }
    if (startNodes.length === 1) {
        // If there's only one start node, return it as an array
        return startNodes;
    }
    // If no start nodes are found, return an empty array
    return [];
};
PipelineService.findPreviousNodeId = (flow, nodeId) => {
    // Find the ID of the previous node
    let previousNodeId = '';
    flow.edges.forEach(edge => {
        if (edge.target === nodeId) {
            previousNodeId = edge.source;
        }
    });
    return previousNodeId;
};
PipelineService.findMultiplePreviousNodeIds = (flow, nodeId) => {
    const previousNodesMap = new Map();
    // Group incoming edges by targetHandle
    flow.edges.forEach(edge => {
        if (edge.target === nodeId) {
            const handle = edge.targetHandle || 'default'; // Fallback to 'default' if no handle
            if (!previousNodesMap.has(handle)) {
                previousNodesMap.set(handle, []);
            }
            previousNodesMap.get(handle).push(edge.source);
        }
    });
    // Sort the map by targetHandle and flatten the result
    const sortedPreviousNodeIds = Array.from(previousNodesMap.entries())
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([_, nodeIds]) => nodeIds)
        .reduce((acc, val) => acc.concat(val), []);
    return sortedPreviousNodeIds;
};
PipelineService.findTwoPreviousNodeIds = (flow, nodeId) => {
    let previousNodeIds = [];
    flow.edges.forEach(edge => {
        if (edge.target === nodeId) {
            previousNodeIds.push(edge.source);
        }
    });
    if (previousNodeIds.length !== 2) {
        throw new Error("Exactly two previous nodes are not found.");
    }
    return previousNodeIds;
};
PipelineService.formatVarName = (input) => {
    return input.replace(/([a-z])([A-Z])/g, '$1_$2') // Add underscore before capital letters
        .toUpperCase() // Convert to uppercase
        .replace(/\s+/g, '_') // Replace spaces with underscore
        .replace(/\./g, '_'); // Replace dots with underscore
};


/***/ }),

/***/ "./lib/RequestService.js":
/*!*******************************!*\
  !*** ./lib/RequestService.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RequestService: () => (/* binding */ RequestService)
/* harmony export */ });
/* harmony import */ var _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CodeGenerator */ "./lib/CodeGenerator.js");
/* harmony import */ var _PipelineService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PipelineService */ "./lib/PipelineService.js");


class RequestService {
    static retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadings, nodeId, inputNb, previousNodes) {
        setLoadings(true);
        const flow = _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.filterPipeline(context.model.toString());
        let codeList;
        let code = '';
        try {
            // Determine the reference node to use
            let refNodeId = previousNodes ? _PipelineService__WEBPACK_IMPORTED_MODULE_0__.PipelineService.findMultiplePreviousNodeIds(flow, nodeId)[inputNb] : nodeId;
            const nodesMap = new Map(flow.nodes.map(node => [node.id, node]));
            // Check if the previous node has already been executed recently
            const refNode = nodesMap.get(refNodeId);
            if (refNode) {
                const { lastUpdated, lastExecuted, nameId } = refNode.data || {};
                // If the node has been executed after its last update, skip code generation
                // console.log("lastExecuted %o, type: %s", lastExecuted, typeof lastExecuted);
                // console.log("lastUpdated %o, type: %s", lastUpdated, typeof lastUpdated);
                if (lastExecuted >= lastUpdated) {
                    console.log("Skip generation");
                    const dataframeVar = nameId || refNodeId;
                    const codeToFetchContent = `print(_amphi_metadatapanel_getcontentof(${dataframeVar}))`;
                    const future = context.sessionContext.session.kernel.requestExecute({ code: codeToFetchContent });
                    future.onIOPub = msg => {
                        if (msg.header.msg_type === 'stream') {
                            const streamMsg = msg;
                            const output = streamMsg.content.text;
                            const regex = /([^,]+)\s+\(([^,]+(?:\[[^\]]+\])?),\s*(named|unnamed)\)/g;
                            const newItems = [];
                            let match;
                            while ((match = regex.exec(output)) !== null) {
                                const [_, name, type, namedStatus] = match;
                                newItems.push({
                                    value: name.trim(),
                                    label: name.trim(),
                                    type: type.trim(),
                                    named: namedStatus.trim() === 'named'
                                });
                            }
                            setItems(items => {
                                const itemSet = new Set(items.map(item => item.value));
                                const uniqueItems = newItems.filter(newItem => !itemSet.has(newItem.value));
                                return [...items, ...uniqueItems];
                            });
                            setLoadings(false);
                        }
                        else if (msg.header.msg_type === 'error') {
                            setLoadings(false);
                            const errorMsg = msg;
                            console.error(`Received error: ${errorMsg.content.ename}: ${errorMsg.content.evalue}`);
                        }
                    };
                    console.log("return");
                    return; // Skip further processing since data was fetched from cache
                }
            }
            // If not recently executed, generate code
            codeList = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.generateCodeUntil(context.model.toString(), commands, componentService, refNodeId, false, false);
            code = codeList.join('\n');
        }
        catch (error) {
            console.error("Error generating code.", error);
            code = null;
            setLoadings(false);
        }
        const lines = code.split('\n');
        let output_df = lines.pop();
        const match = output_df.match(/__amphi_display_dataframe\(([^,]*)/);
        output_df = match ? match[1] : null;
        if (output_df && output_df.trim() && output_df.trim().split(' ').length === 1) {
            code = lines.join('\n');
            const future = context.sessionContext.session.kernel.requestExecute({ code: code });
            future.onReply = reply => {
                if (reply.content.status == "ok") {
                    const future2 = context.sessionContext.session.kernel.requestExecute({ code: `print(_amphi_metadatapanel_getcontentof(${output_df}))` });
                    future2.onIOPub = msg => {
                        if (msg.header.msg_type === 'stream') {
                            const streamMsg = msg;
                            const output = streamMsg.content.text;
                            const regex = /([^,]+)\s+\(([^,]+),\s*(named|unnamed)\)/g;
                            const newItems = [];
                            let match;
                            while ((match = regex.exec(output)) !== null) {
                                const [_, name, type, namedStatus] = match;
                                newItems.push({
                                    value: name.trim(),
                                    label: name.trim(),
                                    type: type.trim(),
                                    named: namedStatus.trim() === 'named'
                                });
                            }
                            setItems(items => {
                                const itemSet = new Set(items.map(item => item.value));
                                const uniqueItems = newItems.filter(newItem => !itemSet.has(newItem.value));
                                return [...items, ...uniqueItems];
                            });
                            setLoadings(false);
                        }
                        else if (msg.header.msg_type === 'error') {
                            setLoadings(false);
                            const errorMsg = msg;
                            console.error(`Received error: ${errorMsg.content.ename}: ${errorMsg.content.evalue}`);
                        }
                    };
                }
                else {
                    setLoadings(false);
                }
            };
        }
        else {
            setLoadings(false);
        }
    }
    ;
    static executePythonCode(code, context, setItems, setLoading) {
        setLoading(true);
        // Execute the provided Python code
        const future = context.sessionContext.session.kernel.requestExecute({ code: code });
        future.onIOPub = msg => {
            if (msg.header.msg_type === 'stream') {
                // Handle standard output from print statements
                const streamMsg = msg;
                const output = streamMsg.content.text;
                // Assume the output is a comma-separated list
                const itemsArray = output.split(',').map(item => item.trim());
                const newItems = itemsArray.map((item) => ({
                    value: item,
                    label: item,
                    type: 'python',
                    named: false,
                }));
                setItems(newItems);
                setLoading(false);
            }
            else if (msg.header.msg_type === 'execute_result' || msg.header.msg_type === 'display_data') {
                // Handle output from the last expression in the code cell
                const dataMsg = msg;
                const data = dataMsg.content.data['text/plain'];
                // Clean the data string and parse it
                const cleanedData = data.replace(/['"\[\]]/g, '');
                const itemsArray = cleanedData.split(',').map(item => item.trim());
                const newItems = itemsArray.map((item) => ({
                    value: item,
                    label: item,
                    type: 'python',
                    named: false,
                }));
                setItems(newItems);
                setLoading(false);
            }
            else if (msg.header.msg_type === 'error') {
                // Handle execution errors
                setLoading(false);
                const errorMsg = msg;
                const errorOutput = errorMsg.content;
                console.error(`Received error: ${errorOutput.ename}: ${errorOutput.evalue}`);
            }
        };
        future.onReply = reply => {
            if (reply.content.status !== 'ok') {
                setLoading(false);
            }
        };
    }
    static retrieveTableList(event, schemaName, query, context, componentService, setList, setLoadings, nodeId) {
        setLoadings(true);
        // Escape and replace schema in the query
        let escapedQuery = query.replace(/"/g, '\\"');
        escapedQuery = escapedQuery.replace(/{{schema}}/g, schemaName);
        // Get environment and connection code
        const envVariableCode = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.getEnvironmentVariableCode(context.model.toString(), componentService);
        const connectionCode = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.getConnectionCode(context.model.toString(), componentService);
        // Get component and data for the node
        const { component, data } = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.getComponentAndDataForNode(nodeId, componentService, context.model.toString());
        if (!component) {
            console.error("Component or data not found.");
            setLoadings(false);
            return;
        }
        // Get the dependencies and imports from the component
        const dependencies = component.provideDependencies(data);
        const imports = component.provideImports(data);
        // Generate the dependencies string
        const dependencyString = dependencies.join(' ');
        // Generate the import statements string (one per line)
        const importStatements = imports.map((imp) => `${imp}`).join('\n');
        // Build the Python code string
        let code = `
!pip install --quiet ${dependencyString} --disable-pip-version-check
${importStatements}
${envVariableCode}
${connectionCode}

query = """
${escapedQuery}
"""
${component.generateDatabaseConnectionCode({ config: data, connectionName: "engine" })}

tables = pd.read_sql(query, con=engine)
tables.iloc[:, 0] = tables.iloc[:, 0].str.strip()  # Strip leading/trailing spaces
formatted_output = ", ".join(tables.iloc[:, 0].tolist())
print(formatted_output)
`;
        // Format any remaining variables in the code
        code = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.formatVariables(code);
        const future = context.sessionContext.session.kernel.requestExecute({ code: code });
        future.onReply = reply => {
            if (reply.content.status == "ok") {
            }
            else if (reply.content.status == "error") {
                setLoadings(false);
            }
            else if (reply.content.status == "abort") {
                setLoadings(false);
            }
            else {
                setLoadings(false);
            }
        };
        future.onIOPub = msg => {
            if (msg.header.msg_type === 'stream') {
                const streamMsg = msg;
                // Check if the stream message is from 'stdout'
                if (streamMsg.content.name === 'stdout') {
                    const output = streamMsg.content.text;
                    const tables = output.split(', ');
                    const newItems = tables.map(tableName => {
                        const trimmedTableName = tableName.trim(); // Trim leading/trailing spaces
                        return {
                            input: {},
                            value: trimmedTableName,
                            key: trimmedTableName,
                            label: trimmedTableName,
                            type: 'table'
                        };
                    });
                    setList((items) => {
                        const existingKeys = new Set(items.map((item) => item.key));
                        const uniqueItems = newItems.filter(newItem => !existingKeys.has(newItem.key));
                        return [...items, ...uniqueItems];
                    });
                    setLoadings(false);
                }
            }
            else if (msg.header.msg_type === 'error') {
                setLoadings(false);
                const errorMsg = msg;
                const errorOutput = errorMsg.content;
                console.error(`Received error: ${errorOutput.ename}: ${errorOutput.evalue}`);
            }
        };
    }
    ;
    static retrieveTableColumns(event, schemaName, tableName, query, pythonExtraction, context, componentService, setDataSource, setLoadings, nodeId) {
        setLoadings(true);
        // Escape and replace schema and table in the query
        let escapedQuery = query.replace(/"/g, '\\"');
        escapedQuery = escapedQuery
            .replace(/{{schema}}/g, schemaName)
            .replace(/{{table}}/g, tableName);
        // Get environment and connection code
        const envVariableCode = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.getEnvironmentVariableCode(context.model.toString(), componentService);
        const connectionCode = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.getConnectionCode(context.model.toString(), componentService);
        // Get the component and data for the node
        const { component, data } = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.getComponentAndDataForNode(nodeId, componentService, context.model.toString());
        if (!component) {
            console.error('Component or data not found.');
            setLoadings(false);
            return;
        }
        // Get the dependencies and imports from the component
        const dependencies = component.provideDependencies({ config: data });
        const imports = component.provideImports({ config: data });
        // Generate the dependencies string
        const dependencyString = dependencies.join(' ');
        // Generate the import statements string (one per line)
        const importStatements = imports.map((imp) => `${imp}`).join('\n');
        // Build the Python code string
        let code = `
!pip install --quiet ${dependencyString} --disable-pip-version-check
${importStatements}
${envVariableCode}
${connectionCode}
  
query = """
${escapedQuery}
"""
${component.generateDatabaseConnectionCode({ config: data, connectionName: 'engine' })}
schema = pd.read_sql(query, con=engine)

${pythonExtraction}
`;
        // Format any remaining variables in the code
        code = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.formatVariables(code);
        const future = context.sessionContext.session.kernel.requestExecute({ code: code });
        future.onReply = (reply) => {
            if (reply.content.status == 'ok') {
                // Execution was successful
            }
            else {
                setLoadings(false);
            }
        };
        future.onIOPub = (msg) => {
            if (msg.header.msg_type === 'stream') {
                const streamMsg = msg;
                // Check if the stream message is from 'stdout'
                if (streamMsg.content.name === 'stdout') {
                    const output = streamMsg.content.text;
                    const regex = /([^\s,]+)\s+\(((?:[^()]+|\([^)]*\))*)\)/g;
                    const newItems = [];
                    let match;
                    while ((match = regex.exec(output)) !== null) {
                        const [_, name, type] = match;
                        newItems.push({
                            input: {},
                            value: name,
                            key: name,
                            type: type.toUpperCase(),
                        });
                    }
                    setDataSource((items) => {
                        // Create a set of existing item keys
                        const existingKeys = new Set(items.map((item) => item.key));
                        // Filter newItems to ensure unique keys
                        const uniqueItems = newItems.filter((newItem) => !existingKeys.has(newItem.key));
                        return [...items, ...uniqueItems];
                    });
                    setLoadings(false);
                }
            }
            else if (msg.header.msg_type === 'error') {
                setLoadings(false);
                const errorMsg = msg;
                const errorOutput = errorMsg.content;
                console.error(`Received error: ${errorOutput.ename}: ${errorOutput.evalue}`);
            }
        };
    }
    static retrieveSheetNames(event, context, componentService, setList, setLoadings, nodeId) {
        var _a, _b;
        setLoadings(true);
        try {
            // Get environment and connection code
            const envVariableCode = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.getEnvironmentVariableCode(context.model.toString(), componentService);
            // Get component and data for the node
            const { component, data } = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.getComponentAndDataForNode(nodeId, componentService, context.model.toString());
            if (!component) {
                throw new Error("Component or data not found.");
            }
            // Check if filePath exists
            if (!data.filePath) {
                throw new Error("filePath is missing in the node data.");
            }
            // Determine the backend prefix
            const backendPrefix = (_b = (_a = data.backend) === null || _a === void 0 ? void 0 : _a.prefix) !== null && _b !== void 0 ? _b : "pd";
            // Generate Python code using the component
            const generatedCode = component.generateComponentCode({
                config: { ...data },
                outputName: "excel_file",
            });
            // Get the dependencies and imports from the component
            const dependencies = component.provideDependencies({ config: data });
            const imports = component.provideImports({ config: data });
            const excelOptions = { ...data.excelOptions };
            const optionsString = component.generateOptionsCode(excelOptions);
            let filteredOptions = optionsString
                .split(",")
                .filter(option => option.trim().startsWith("engine"))
                .join(",");
            // Build the Python code string
            let code = `
!pip install --quiet ${dependencies.join(" ")} --disable-pip-version-check
${imports.map((imp) => `${imp}`).join("\n")}
${envVariableCode}

excel_obj = pd.ExcelFile("${data.filePath}"${filteredOptions ? `, ${filteredOptions}` : ''})
sheet_names = excel_obj.sheet_names
print(", ".join(sheet_names))
`;
            // Format variables in the code
            code = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.formatVariables(code);
            const future = context.sessionContext.session.kernel.requestExecute({ code });
            // Handle response onReply
            future.onReply = (reply) => {
                if (reply.content.status !== "ok") {
                    setLoadings(false);
                    console.error("Execution failed:", reply.content);
                    return;
                }
            };
            // Handle output messages
            future.onIOPub = (msg) => {
                if (msg.header.msg_type === "stream") {
                    const streamMsg = msg;
                    if (streamMsg.content.name === "stdout") {
                        const output = streamMsg.content.text;
                        const sheets = output.split(", ");
                        const newItems = sheets.map((sheetName) => ({
                            input: {},
                            value: sheetName.trim(),
                            key: sheetName.trim(),
                            label: sheetName.trim(),
                            type: "sheet",
                        }));
                        setList((items) => {
                            const existingKeys = new Set(items.map((item) => item.key));
                            const uniqueItems = newItems.filter((newItem) => !existingKeys.has(newItem.key));
                            return [...items, ...uniqueItems];
                        });
                        setLoadings(false);
                    }
                }
                else if (msg.header.msg_type === "error") {
                    setLoadings(false);
                    const errorMsg = msg.content.evalue;
                    console.error(`Error: ${errorMsg}`);
                }
            };
            // Ensure loading stops in case of any unforeseen issue
            future.onDone = () => {
                setLoadings(false);
            };
        }
        catch (error) {
            console.error("Error in retrieveSheetNames:", error);
            setLoadings(false);
        }
    }
    static retrieveEnvVariables(context, setDataSource, setLoadings, nodeId) {
        setLoadings(true);
        let code = `
!pip install --quiet python-dotenv --disable-pip-version-check
from dotenv import dotenv_values
  
env_vars = dotenv_values(".env")
formatted_output = ", ".join([f"{k} ({v})" for k, v in env_vars.items()])
print(formatted_output)
`;
        // Replace connection string
        code = _CodeGenerator__WEBPACK_IMPORTED_MODULE_1__.CodeGenerator.formatVariables(code);
        const future = context.sessionContext.session.kernel.requestExecute({ code: code });
        future.onReply = reply => {
            if (reply.content.status == "ok") {
            }
            else if (reply.content.status == "error") {
                setLoadings(false);
            }
            else if (reply.content.status == "abort") {
                setLoadings(false);
            }
            else {
                setLoadings(false);
            }
        };
        future.onIOPub = msg => {
            if (msg.header.msg_type === 'stream') {
                const streamMsg = msg;
                const output = streamMsg.content.text;
                const regex = /([^\s,]+)\s+\(((?:[^()]+|\([^)]*\))*)\)/g;
                const newItems = [];
                let match;
                while ((match = regex.exec(output)) !== null) {
                    const [_, name, value] = match;
                    newItems.push({
                        input: {},
                        value: name,
                        key: name,
                        type: value
                    });
                }
                setDataSource((items) => {
                    const existingKeys = new Set(items.map((item) => item.key));
                    const uniqueItems = newItems.filter((newItem) => !existingKeys.has(newItem.key));
                    return [...items, ...uniqueItems];
                });
                setLoadings(false);
            }
            else if (msg.header.msg_type === 'error') {
                setLoadings(false);
                const errorMsg = msg;
                const errorOutput = errorMsg.content;
                console.error(`Received error: ${errorOutput.ename}: ${errorOutput.evalue}`);
            }
        };
    }
    ;
}


/***/ }),

/***/ "./lib/configUtils.js":
/*!****************************!*\
  !*** ./lib/configUtils.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GenerateUIFormComponent: () => (/* binding */ GenerateUIFormComponent),
/* harmony export */   GenerateUIInputs: () => (/* binding */ GenerateUIInputs),
/* harmony export */   "default": () => (/* binding */ ConfigModal),
/* harmony export */   onChange: () => (/* binding */ onChange),
/* harmony export */   setDefaultConfig: () => (/* binding */ setDefaultConfig)
/* harmony export */ });
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/CheckOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/CloseOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _formUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./formUtils */ "./lib/formUtils.js");
/* harmony import */ var _forms_CodeTextarea__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./forms/CodeTextarea */ "./lib/forms/CodeTextarea.js");
/* harmony import */ var _forms_InputFile__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./forms/InputFile */ "./lib/forms/InputFile.js");
/* harmony import */ var _forms_InputFiles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./forms/InputFiles */ "./lib/forms/InputFiles.js");
/* harmony import */ var _forms_InputQuantity__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./forms/InputQuantity */ "./lib/forms/InputQuantity.js");
/* harmony import */ var _forms_InputRegular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./forms/InputRegular */ "./lib/forms/InputRegular.js");
/* harmony import */ var _forms_TextareaRegular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./forms/TextareaRegular */ "./lib/forms/TextareaRegular.js");
/* harmony import */ var _forms_dataMapping__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./forms/dataMapping */ "./lib/forms/dataMapping.js");
/* harmony import */ var _forms_keyValueColumns__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./forms/keyValueColumns */ "./lib/forms/keyValueColumns.js");
/* harmony import */ var _forms_keyValueColumnsSelect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./forms/keyValueColumnsSelect */ "./lib/forms/keyValueColumnsSelect.js");
/* harmony import */ var _forms_keyValueColumnsRadio__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./forms/keyValueColumnsRadio */ "./lib/forms/keyValueColumnsRadio.js");
/* harmony import */ var _forms_keyValueForm__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./forms/keyValueForm */ "./lib/forms/keyValueForm.js");
/* harmony import */ var _forms_selectColumn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./forms/selectColumn */ "./lib/forms/selectColumn.js");
/* harmony import */ var _forms_selectColumns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./forms/selectColumns */ "./lib/forms/selectColumns.js");
/* harmony import */ var _forms_selectFromSQLQuery__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./forms/selectFromSQLQuery */ "./lib/forms/selectFromSQLQuery.js");
/* harmony import */ var _forms_selectCustomizable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./forms/selectCustomizable */ "./lib/forms/selectCustomizable.js");
/* harmony import */ var _forms_selectMultipleCustomizable__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./forms/selectMultipleCustomizable */ "./lib/forms/selectMultipleCustomizable.js");
/* harmony import */ var _forms_selectRegular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./forms/selectRegular */ "./lib/forms/selectRegular.js");
/* harmony import */ var _forms_selectTokenization__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./forms/selectTokenization */ "./lib/forms/selectTokenization.js");
/* harmony import */ var _forms_transferData__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./forms/transferData */ "./lib/forms/transferData.js");
/* harmony import */ var _forms_valuesListForm__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./forms/valuesListForm */ "./lib/forms/valuesListForm.js");
/* harmony import */ var _forms_FormulaColumns__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./forms/FormulaColumns */ "./lib/forms/FormulaColumns.js");
/* harmony import */ var _PipelineService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PipelineService */ "./lib/PipelineService.js");
/* harmony import */ var _forms_selectSheetFromExcel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./forms/selectSheetFromExcel */ "./lib/forms/selectSheetFromExcel.js");



























// Set default options to component if specified
const setDefaultConfig = ({ nodeId, store, setNodes, defaultConfig, }) => {
    const { nodeInternals } = store.getState();
    setNodes(Array.from(nodeInternals.values()).map((node) => {
        if (node.id === nodeId && Object.keys(node.data).length === 1) {
            node.data = {
                ...defaultConfig,
                lastUpdated: null,
                lastExecuted: null,
            };
        }
        return node;
    }));
};
const onChange = ({ evtTargetValue, field, nodeId, store, setNodes }) => {
    const newValue = evtTargetValue;
    const { nodeInternals } = store.getState();
    const currentTimestamp = Date.now(); // Current timestamp in milliseconds since Unix epoch
    setNodes(Array.from(nodeInternals.values()).map((node) => {
        if (node.id === nodeId) {
            let fieldParts = field.split('.');
            // Set or update the main field
            if (fieldParts.length === 1) {
                // Top-level field
                node.data = { ...node.data, [field]: newValue };
            }
            else {
                // Nested field
                const [outerField, innerField] = fieldParts;
                node.data = {
                    ...node.data,
                    [outerField]: {
                        ...node.data[outerField],
                        [innerField]: newValue,
                    },
                };
            }
            // Set or update the lastUpdated field with the current timestamp
            if (field !== 'lastExecuted') {
                node.data = { ...node.data, lastUpdated: currentTimestamp };
            }
            else {
                node.data = { ...node.data };
            }
        }
        return node;
    }));
};
const GenerateUIFormComponent = react__WEBPACK_IMPORTED_MODULE_1___default().memo(({ nodeId, type, name, form, data, context, componentService, manager, commands, handleChange, modalOpen, setModalOpen }) => {
    const stopPropagation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e) => {
        e.stopPropagation();
    }, []);
    const [fieldsForm] = antd__WEBPACK_IMPORTED_MODULE_0__.Form.useForm();
    const [formValues, setFormValues] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(fieldsForm.getFieldsValue());
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        setFormValues(fieldsForm.getFieldsValue());
    }, [fieldsForm]);
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { onDoubleClick: stopPropagation },
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Form, { form: fieldsForm, layout: "vertical", size: "small", onValuesChange: (_, values) => {
                setFormValues(values);
            } },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(GenerateUIInputs, { name: name, nodeId: nodeId, form: form, data: data, context: context, componentService: componentService, manager: manager, commands: commands, handleChange: handleChange, advanced: false, formValues: formValues }),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(ConfigModal, { modalOpen: modalOpen, setModalOpen: setModalOpen, name: name, nodeId: nodeId, form: form, data: data, context: context, componentService: componentService, manager: manager, commands: commands, handleChange: handleChange, advanced: true }))));
});
const GenerateUIInputs = react__WEBPACK_IMPORTED_MODULE_1___default().memo(({ name, nodeId, form, data, context, componentService, manager, commands, handleChange, advanced, formValues }) => {
    const [connections, setConnections] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [optionsConnections, setOptionsConnections] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const fetchConnections = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
        const allConnections = _PipelineService__WEBPACK_IMPORTED_MODULE_2__.PipelineService.getConnections(context.model.toString());
        setConnections(allConnections);
        const connectionsByType = allConnections.reduce((acc, connection) => {
            const connectionType = connection.connectionType;
            if (!acc[connectionType]) {
                acc[connectionType] = [];
            }
            acc[connectionType].push(renderItem(connection.connectionName));
            return acc;
        }, {});
        setOptionsConnections(connectionsByType);
    }, [context]);
    // Function to check if a field should be displayed based on its condition
    const shouldDisplayField = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((field, values) => {
        if (!field.condition) {
            return true;
        }
        const checkCondition = (condition, obj) => {
            return Object.keys(condition).every(key => {
                const conditionValue = condition[key];
                const fieldValue = obj[key];
                if (typeof conditionValue === "object" && !Array.isArray(conditionValue) && fieldValue !== undefined) {
                    return checkCondition(conditionValue, fieldValue);
                }
                const result = Array.isArray(conditionValue)
                    ? conditionValue.includes(fieldValue)
                    : fieldValue === conditionValue;
                return result;
            });
        };
        const finalResult = checkCondition(field.condition, values);
        return finalResult;
    }, [data]);
    const renderItem = (title) => ({
        value: title,
        label: (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: {
                display: 'flex',
                justifyContent: 'space-between',
            } }, title)),
    });
    const handleSelectConnection = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((connectionName, attributeId) => {
        const selectedConnection = connections.find(conn => conn.connectionName === connectionName);
        if (selectedConnection) {
            selectedConnection.variables.forEach(variable => {
                const { key, name } = variable;
                const VarName = name;
                const fieldId = `${key}`;
                handleChange('{' + `${VarName}` + '}', fieldId);
            });
            handleChange(connectionName, attributeId);
        }
    }, [connections, handleChange]);
    const handleRemoveConnection = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((attributeId) => {
        const connectionName = data[attributeId];
        const selectedConnection = connections.find(conn => conn.connectionName === connectionName);
        if (selectedConnection) {
            selectedConnection.variables.forEach(variable => {
                const { key } = variable;
                const fieldId = `${key}`;
                handleChange('', fieldId);
            });
            handleChange('', attributeId);
        }
    }, [connections, data, handleChange]);
    const groupedFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => form.fields.reduce((acc, field) => {
        const connection = field.connection || 'default';
        if (!acc[connection]) {
            acc[connection] = [];
        }
        acc[connection].push(field);
        return acc;
    }, {}), [form.fields]);
    const renderField = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((field, index) => {
        if (!advanced && field.advanced) {
            return null;
        }
        // Directly check if the field should be displayed
        if (!shouldDisplayField(field, data)) {
            return null;
        }
        let value;
        let values = [];
        const fieldParts = field.id.split('.');
        if (Array.isArray(data[field.id])) {
            values = data[field.id];
        }
        else if (fieldParts.length === 1) {
            if (data[field.id] !== undefined) {
                value = data[field.id];
            }
        }
        else {
            const [outerField, innerField] = fieldParts;
            if (data[outerField] && data[outerField][innerField] !== undefined) {
                value = data[outerField][innerField];
            }
        }
        /*
        const validateInput = (value: any) => {
          if (field.validation) {
            const pattern = new RegExp(field.validation, "i");
            setIsInvalid(!pattern.test(value));
          } else {
            setIsInvalid(false);
          }
        };
    
        const [isInvalid, setIsInvalid] = useState(false);
        useEffect(() => {
          validateInput(value);
        }, [value]);
        */
        const commonProps = { field, handleChange, context, advanced };
        switch (field.type) {
            case "input":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_InputRegular__WEBPACK_IMPORTED_MODULE_4__["default"], { ...commonProps, value: value }));
            case "radio":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Flex, { vertical: true, gap: "middle" },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Radio.Group, { defaultValue: value, onChange: (e) => handleChange(e.target.value, field.id), buttonStyle: "solid" }, field.options.map((option) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Radio.Button, { value: option.value }, option.label)))))));
            case "file":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_InputFile__WEBPACK_IMPORTED_MODULE_5__["default"], { ...commonProps, value: value, manager: manager }));
            case "files":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_InputFiles__WEBPACK_IMPORTED_MODULE_6__["default"], { ...commonProps, values: values, manager: manager }));
            case "columns":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_selectColumns__WEBPACK_IMPORTED_MODULE_7__["default"], { ...commonProps, defaultValues: values, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "column":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_selectColumn__WEBPACK_IMPORTED_MODULE_8__["default"], { ...commonProps, defaultValue: value, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "table":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_selectFromSQLQuery__WEBPACK_IMPORTED_MODULE_9__["default"], { ...commonProps, data: data, defaultValue: value, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "sheets":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_selectSheetFromExcel__WEBPACK_IMPORTED_MODULE_10__["default"], { ...commonProps, data: data, defaultValue: value, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "selectCustomizable":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_selectCustomizable__WEBPACK_IMPORTED_MODULE_11__["default"], { ...commonProps, defaultValue: value }));
            case "selectMultipleCustomizable":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_selectMultipleCustomizable__WEBPACK_IMPORTED_MODULE_12__["default"], { ...commonProps, defaultValues: values }));
            case "selectTokenization":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_selectTokenization__WEBPACK_IMPORTED_MODULE_13__["default"], { ...commonProps, defaultValue: value }));
            case "select":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_selectRegular__WEBPACK_IMPORTED_MODULE_14__["default"], { ...commonProps, defaultValue: value }));
            case "textarea":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_TextareaRegular__WEBPACK_IMPORTED_MODULE_15__["default"], { ...commonProps, value: value, rows: field.rows }));
            case "codeTextarea":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_CodeTextarea__WEBPACK_IMPORTED_MODULE_16__["default"], { ...commonProps, value: value }));
            case "boolean":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Switch, { onChange: (checked) => handleChange(checked, field.id), checkedChildren: react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_17__["default"], null), unCheckedChildren: react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_18__["default"], null), defaultChecked: value === true })));
            case "cascader":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Cascader, { value: values, placeholder: field.placeholder, options: field.options, ...(field.onlyLastValue ? { displayRender: (labels) => labels[labels.length - 1] } : {}), onChange: (value) => handleChange(value, field.id) })));
            case "keyvalue":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_keyValueForm__WEBPACK_IMPORTED_MODULE_19__["default"], { ...commonProps, initialValues: values }));
            case "keyvalueColumns":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_keyValueColumns__WEBPACK_IMPORTED_MODULE_20__["default"], { ...commonProps, initialValues: values, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "keyvalueColumnsSelect":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_keyValueColumnsSelect__WEBPACK_IMPORTED_MODULE_21__["default"], { ...commonProps, initialValues: values, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "keyvalueColumnsRadio":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_keyValueColumnsRadio__WEBPACK_IMPORTED_MODULE_22__["default"], { ...commonProps, initialValues: values, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "valuesList":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_valuesListForm__WEBPACK_IMPORTED_MODULE_23__["default"], { ...commonProps, initialValues: values }));
            case "inputNumber":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_InputQuantity__WEBPACK_IMPORTED_MODULE_24__["default"], { ...commonProps, value: value }));
            case "transferData":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_transferData__WEBPACK_IMPORTED_MODULE_25__["default"], { ...commonProps, defaultValue: value, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "dataMapping":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_dataMapping__WEBPACK_IMPORTED_MODULE_26__["default"], { data: data, ...commonProps, defaultValue: values, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "formulaColumns":
                return (0,_formUtils__WEBPACK_IMPORTED_MODULE_3__.renderFormItem)(field, react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_forms_FormulaColumns__WEBPACK_IMPORTED_MODULE_27__["default"], { ...commonProps, defaultValue: value, componentService: componentService, commands: commands, nodeId: nodeId }));
            case "info":
                return react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Typography.Paragraph, { style: { padding: '5px' } }, field.text);
            default:
                return null;
        }
    }, [data, handleChange, componentService, commands, manager, advanced]);
    // Helper function to check if any field in a connection should be displayed
    const shouldDisplayConnection = (fields) => {
        return fields.some(field => shouldDisplayField(field, data));
    };
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
        Object.entries(groupedFields).map(([connection, fields], groupIndex) => {
            if (connection === 'default' || (!advanced && fields.some(field => field.advanced)))
                return null;
            const connectionFields = fields;
            // Check if the connection card should be displayed
            if (!shouldDisplayConnection(connectionFields)) {
                return null;
            }
            const connectionDataId = `${connection}-${groupIndex}`;
            const selectedConnectionName = data[connectionDataId] || '';
            const selectConnection = (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Select, { placeholder: "Select Connection", style: { minWidth: 200 }, onClick: fetchConnections, options: optionsConnections[connection] || [], value: selectedConnectionName || undefined, onChange: (value) => handleSelectConnection(value, connectionDataId), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                    menu,
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Divider, { style: { margin: '8px 0' } }),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Space, { style: { padding: '0 4px 4px' } },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_18__["default"], null), onClick: () => handleRemoveConnection(connectionDataId) }, "Remove Connection")))) }));
            return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Card, { size: "small", title: `${connection} Connection`, key: `${connection}-${groupIndex}`, style: { marginTop: '10px', marginBottom: '10px' }, extra: selectConnection, type: "inner" }, connectionFields.map(renderField)));
        }),
        groupedFields.default && groupedFields.default.map(renderField)));
});
function ConfigModal({ name, nodeId, form, data, context, componentService, manager, commands, handleChange, advanced, modalOpen, setModalOpen }) {
    const componentName = (data === null || data === void 0 ? void 0 : data.customTitle) || name;
    const stopPropagation = (e) => {
        e.stopPropagation();
    };
    const [fieldsForm] = antd__WEBPACK_IMPORTED_MODULE_0__.Form.useForm();
    const [formValues, setFormValues] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(fieldsForm.getFieldsValue());
    const width = form["fields"].some(field => field.type === 'codeTextarea') ? '80%' : 800;
    const height = form["fields"].some(field => field.type === 'codeTextarea') ? '80%' : '1200px';
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Modal, { title: componentName, centered: true, open: modalOpen, onOk: () => setModalOpen(false), onCancel: () => setModalOpen(false), width: width, style: { height }, footer: (_, { OkBtn }) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(OkBtn, null))) },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { onDoubleClick: stopPropagation },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Form, { form: fieldsForm, layout: "vertical", onValuesChange: (_, values) => {
                        setFormValues(values);
                    } },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(GenerateUIInputs, { name: name, nodeId: nodeId, form: form, data: data, context: context, componentService: componentService, manager: manager, commands: commands, handleChange: handleChange, advanced: true, formValues: formValues }))))));
}


/***/ }),

/***/ "./lib/formUtils.js":
/*!**************************!*\
  !*** ./lib/formUtils.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   renderFormItem: () => (/* binding */ renderFormItem)
/* harmony export */ });
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const renderFormItem = (field, content) => {
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Form.Item, { style: { marginTop: "5px", padding: "0 0 2px" }, label: field.label, className: "nodrag", ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}) }, content));
};


/***/ }),

/***/ "./lib/forms/AddNewColumn.js":
/*!***********************************!*\
  !*** ./lib/forms/AddNewColumn.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddNewColumn: () => (/* binding */ AddNewColumn),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/QuestionCircleOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);



const AddNewColumn = ({ items, setItems, setSelectedOption }) => {
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [type, setType] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('string');
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: name, label: name, type: type, named: true }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    const onNameChange = (event) => {
        setName(event.target.value);
    };
    const onTypeChange = (value) => {
        setType(value);
    };
    const optionRenderItems = (option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, option.label),
        option.tooltip && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: option.tooltip },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__["default"], null)))));
    const typesOptions = [
        {
            value: "numeric",
            label: "Numeric",
            children: [
                {
                    value: "int",
                    label: "Integer",
                    children: [
                        { value: "int64", label: "int64", tooltip: "Standard integer type." },
                        { value: "int32", label: "int32", tooltip: "For optimized memory usage." },
                        { value: "int16", label: "int16", tooltip: "For more optimized memory usage." },
                        { value: "int8", label: "int8", tooltip: "For more optimized memory usage." },
                        { value: "uint64", label: "uint64", tooltip: "Unsigned integer (can only hold non-negative values)" },
                        { value: "uint32", label: "uint32", tooltip: "For more optimized memory usage." },
                        { value: "uint16", label: "uint16", tooltip: "For more optimized memory usage." },
                        { value: "uint8", label: "uint8", tooltip: "For more optimized memory usage." }
                    ]
                },
                {
                    value: "float",
                    label: "Float",
                    children: [
                        { value: "float64", label: "float64", tooltip: "Standard floating-point type." },
                        { value: "float32", label: "float32", tooltip: "For optimized memory usage." },
                        { value: "float16", label: "float16", tooltip: "For more optimized memory usage." }
                    ]
                }
            ]
        },
        {
            value: "text",
            label: "Text",
            children: [
                { value: "string", label: "string", tooltip: "For string data. (recommended)" },
                { value: "object", label: "object", tooltip: "For generic objects (strings, timestamps, mixed types)." },
                { value: "category", label: "category", tooltip: "For categorical variables." }
            ]
        },
        {
            value: "datetime",
            label: "Date & Time",
            children: [
                { value: "datetime64[ns]", label: "datetime64[ns]", tooltip: "For datetime values." },
                { value: "datetime64[ms]", label: "datetime64[ms]", tooltip: "For datetime values in milliseconds." },
                { value: "datetime64[s]", label: "datetime64[s]", tooltip: "For datetime values in seconds." },
                { value: "datetime32[ns]", label: "datetime32[ns]", tooltip: "For compact datetime storage in nanoseconds." },
                { value: "datetime32[ms]", label: "datetime32[ms]", tooltip: "For compact datetime storage in milliseconds." },
                { value: "timedelta[ns]", label: "timedelta[ns]", tooltip: "For differences between two datetimes." }
            ]
        },
        {
            value: "boolean",
            label: "Boolean",
            children: [
                { value: "bool", label: "bool", tooltip: "For boolean values (True or False)." }
            ]
        }
    ];
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 4px 4px' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Row, { gutter: 8 },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Col, { span: 12 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { placeholder: "New column", ref: inputRef, value: name, onChange: onNameChange, onKeyDown: (e) => e.stopPropagation() })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Col, { span: 10 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Cascader, { autoFocus: true, style: { width: '100%' }, allowClear: false, options: typesOptions, defaultValue: ['text', 'string'], placement: 'topLeft', displayRender: (labels) => labels[labels.length - 1], onChange: onTypeChange, optionRender: optionRenderItems, getPopupContainer: triggerNode => {
                        // Find the closest parent dropdown element
                        let parentElement = triggerNode.parentElement;
                        while (parentElement && !parentElement.classList.contains('ant-dropdown')) {
                            parentElement = parentElement.parentElement;
                        }
                        // Return the first dropdown's parent container or default to the current triggerNode's parent
                        return parentElement || triggerNode.parentNode;
                    } })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Col, { span: 2 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null), onClick: addItem }, "Add")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddNewColumn);


/***/ }),

/***/ "./lib/forms/CodeTextarea.js":
/*!***********************************!*\
  !*** ./lib/forms/CodeTextarea.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeTextarea: () => (/* binding */ CodeTextarea),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_ace__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-ace */ "webpack/sharing/consume/default/react-ace/react-ace");
/* harmony import */ var react_ace__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_ace__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ace_builds_src_noconflict_mode_python__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ace-builds/src-noconflict/mode-python */ "../../node_modules/ace-builds/src-noconflict/mode-python.js");
/* harmony import */ var ace_builds_src_noconflict_mode_python__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ace_builds_src_noconflict_mode_python__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var ace_builds_src_noconflict_mode_sql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ace-builds/src-noconflict/mode-sql */ "../../node_modules/ace-builds/src-noconflict/mode-sql.js");
/* harmony import */ var ace_builds_src_noconflict_mode_sql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(ace_builds_src_noconflict_mode_sql__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var ace_builds_src_noconflict_theme_xcode__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ace-builds/src-noconflict/theme-xcode */ "../../node_modules/ace-builds/src-noconflict/theme-xcode.js");
/* harmony import */ var ace_builds_src_noconflict_theme_xcode__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(ace_builds_src_noconflict_theme_xcode__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var ace_builds_src_noconflict_ext_language_tools__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ace-builds/src-noconflict/ext-language_tools */ "../../node_modules/ace-builds/src-noconflict/ext-language_tools.js");
/* harmony import */ var ace_builds_src_noconflict_ext_language_tools__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(ace_builds_src_noconflict_ext_language_tools__WEBPACK_IMPORTED_MODULE_5__);





 // Import for language tools
const CodeTextarea = ({ field, value, handleChange, advanced }) => {
    const [inputValue, setInputValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setInputValue(value); // Update inputValue when value prop changes
    }, [value]);
    const handleInputChange = (val) => {
        const newValue = val;
        setInputValue(newValue);
        handleChange(newValue, field.id);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_ace__WEBPACK_IMPORTED_MODULE_1___default()), { width: '100%', height: field.height, placeholder: field.placeholder, mode: field.mode, theme: "xcode", name: field.id, onChange: handleInputChange, fontSize: 14, lineHeight: 19, showPrintMargin: true, showGutter: true, highlightActiveLine: true, value: inputValue, setOptions: {
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: true,
            enableSnippets: true,
            showLineNumbers: true,
            tabSize: 2,
        } }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CodeTextarea);


/***/ }),

/***/ "./lib/forms/CodeTextareaMirror.js":
/*!*****************************************!*\
  !*** ./lib/forms/CodeTextareaMirror.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeTextareaMirror: () => (/* binding */ CodeTextareaMirror),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/codeeditor */ "webpack/sharing/consume/default/@jupyterlab/codeeditor");
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyter_ydoc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyter/ydoc */ "webpack/sharing/consume/default/@jupyter/ydoc");
/* harmony import */ var _jupyter_ydoc__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyter_ydoc__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _codemirror_lang_python__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @codemirror/lang-python */ "webpack/sharing/consume/default/@codemirror/lang-python/@codemirror/lang-python");
/* harmony import */ var _codemirror_lang_python__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_codemirror_lang_python__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _codemirror_view__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @codemirror/view */ "webpack/sharing/consume/default/@codemirror/view");
/* harmony import */ var _codemirror_view__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_codemirror_view__WEBPACK_IMPORTED_MODULE_5__);






const INPUT_AREA_EDITOR_CLASS = 'jp-InputArea-editor';
const CodeTextareaMirror = ({ field, value, handleChange, advanced, }) => {
    const editorRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const editorWrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const sharedModelRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (editorRef.current && !editorWrapperRef.current) {
            // Initialize shared model and editor
            const sharedModel = new _jupyter_ydoc__WEBPACK_IMPORTED_MODULE_3__.YFile();
            sharedModelRef.current = sharedModel;
            const model = new _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__.CodeEditor.Model({ sharedModel, mimeType: 'text/x-python' });
            const factory = (options) => {
                var _a;
                const mergedOptions = {
                    ...options,
                    extensions: [
                        ...((_a = options.extensions) !== null && _a !== void 0 ? _a : []),
                        (0,_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__.ybinding)({ ytext: sharedModel.ysource }),
                        (0,_codemirror_lang_python__WEBPACK_IMPORTED_MODULE_4__.python)(),
                        (0,_codemirror_view__WEBPACK_IMPORTED_MODULE_5__.lineNumbers)() // Add line numbers
                    ]
                };
                return new _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__.CodeMirrorEditor(mergedOptions);
            };
            // Create the editor wrapper instance
            editorWrapperRef.current = new _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_1__.CodeEditorWrapper({
                factory,
                model,
                editorOptions: {
                    config: { readOnly: true }
                }
            });
            editorWrapperRef.current.addClass(INPUT_AREA_EDITOR_CLASS);
            // Attach the editor wrapper to the DOM
            editorRef.current.appendChild(editorWrapperRef.current.node);
            // Insert initial value only if `value` is not empty
            if (sharedModel.ysource && value) {
                sharedModel.ysource.insert(0, value);
            }
            else {
            }
            // Set initial value in the editor
            if (sharedModel.ysource && value) {
                sharedModel.ysource.insert(0, value);
            }
            // Sync editor changes to parent component
            sharedModel.ysource.observe(() => {
                const newValue = sharedModel.ysource.toString();
                if (newValue !== value) {
                    handleChange(newValue, field.id);
                }
            });
        }
    }, [field.id, value, handleChange]);
    // Update `ysource` only if `value` is non-empty and different from the current value
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (sharedModelRef.current && sharedModelRef.current.ysource) {
            const currentValue = sharedModelRef.current.ysource.toString();
            if (value && value !== currentValue) {
                sharedModelRef.current.ysource.delete(0, currentValue.length);
                sharedModelRef.current.ysource.insert(0, value);
            }
        }
        else {
            console.error("ysource is not initialized correctly during update.");
        }
    }, [value]);
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: editorRef, style: { height: '100%', width: '100%' } });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CodeTextareaMirror);


/***/ }),

/***/ "./lib/forms/FormulaColumns.js":
/*!*************************************!*\
  !*** ./lib/forms/FormulaColumns.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormulaColumns: () => (/* binding */ FormulaColumns),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/CloseOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _selectColumns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./selectColumns */ "./lib/forms/selectColumns.js");
/* harmony import */ var _CodeTextarea__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CodeTextarea */ "./lib/forms/CodeTextarea.js");





const FormulaColumns = ({ field, handleChange, defaultValue, context, componentService, commands, nodeId, advanced }) => {
    const [form] = antd__WEBPACK_IMPORTED_MODULE_1__.Form.useForm();
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValue || {});
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        form.setFieldsValue(value);
    }, [value]);
    const onValuesChange = (changedValues, allValues) => {
        setValue(allValues);
        handleChange(allValues, field.id);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.List, { name: "items" }, (fields, { add, remove }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', rowGap: 16, flexDirection: 'column' } },
        fields.map((field) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Card, { size: "small", title: `Item ${field.name + 1}`, key: field.key, extra: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__["default"], { onClick: () => {
                    remove(field.name);
                } }) },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { label: "Name", name: [field.name, 'name'] },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_selectColumns__WEBPACK_IMPORTED_MODULE_3__.SelectColumns, { field: {
                        type: 'columns',
                        id: "columns",
                        label: "Columns",
                        placeholder: "Select columns or add new",
                    }, handleChange: null, defaultValues: [], context: context, commands: commands, componentService: componentService, nodeId: nodeId, advanced: true })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { label: "Formula", name: [field.name, 'formula'] },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_CodeTextarea__WEBPACK_IMPORTED_MODULE_4__.CodeTextarea, { field: {
                        type: "codeTextarea",
                        id: "formula",
                        label: "Python Formula",
                        placeholder: "row['column1'] + row['column2']",
                    }, handleChange: null, advanced: true, value: "" }))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "dashed", onClick: () => add(), block: true }, "+ Add Formula")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(FormulaColumns));


/***/ }),

/***/ "./lib/forms/InputFile.js":
/*!********************************!*\
  !*** ./lib/forms/InputFile.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InputFile: () => (/* binding */ InputFile),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/SearchOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _PipelineService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../PipelineService */ "./lib/PipelineService.js");
/* harmony import */ var _BrowseFileDialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../BrowseFileDialog */ "./lib/BrowseFileDialog.js");
/* harmony import */ var _variablesUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../variablesUtils */ "./lib/variablesUtils.js");






const InputFile = ({ field, value, handleChange, context, advanced, manager }) => {
    const { inputValue, inputRef, openValue, setOpenValue, optionsVariables, handleInputChange, handleSelect, filterOptions, suffix, } = (0,_variablesUtils__WEBPACK_IMPORTED_MODULE_2__.useVariableAutoComplete)({ field, value, handleChange, context, advanced });
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space.Compact, { style: { width: '100%' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.AutoComplete, { ref: inputRef, id: field.id, options: optionsVariables, filterOption: filterOptions, size: advanced ? "middle" : "small", open: openValue, onBlur: () => setOpenValue(false), defaultOpen: false, value: inputValue, onChange: handleInputChange, onSelect: handleSelect },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input
            // {...(field.connection && field.advanced && { addonBefore: selectBefore })}
            , { 
                // {...(field.connection && field.advanced && { addonBefore: selectBefore })}
                placeholder: field.placeholder, ref: inputRef, id: field.id, size: advanced ? "middle" : "small", name: field.id, autoComplete: "off", suffix: suffix })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", size: advanced ? "middle" : "small", onClick: async () => {
                // TODO, there is something wrong here
                const res = await (0,_BrowseFileDialog__WEBPACK_IMPORTED_MODULE_3__.showBrowseFileDialog)(manager, {
                    multiselect: false,
                    includeDir: true,
                    filter: (model) => {
                        return model.path !== context.path;
                    }
                });
                // Get relative path
                handleInputChange(_PipelineService__WEBPACK_IMPORTED_MODULE_4__.PipelineService.getRelativePath(context.path, res.value[0].path));
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["default"], null))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(InputFile));


/***/ }),

/***/ "./lib/forms/InputFiles.js":
/*!*********************************!*\
  !*** ./lib/forms/InputFiles.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InputFiles: () => (/* binding */ InputFiles),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/SearchOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _PipelineService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../PipelineService */ "./lib/PipelineService.js");
/* harmony import */ var _BrowseFileDialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../BrowseFileDialog */ "./lib/BrowseFileDialog.js");





const InputFiles = ({ field, values, handleChange, context, advanced, manager }) => {
    // Initialize selectedFiles as array of { label, value } objects
    const [selectedFiles, setSelectedFiles] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((values || []).map(value => ({ label: value, value })));
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const inputSelectRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (values) {
            setSelectedFiles(values.map(value => ({ label: value, value })));
        }
    }, [values]);
    const addItem = (e) => {
        e.preventDefault();
        if (name && !selectedFiles.find(file => file.value === name)) {
            const newItem = { label: name, value: name };
            const updatedSelectedFiles = [...selectedFiles, newItem];
            setSelectedFiles(updatedSelectedFiles);
            handleChange(updatedSelectedFiles.map(f => f.value), field.id);
            setName('');
            setTimeout(() => {
                var _a;
                (_a = inputSelectRef.current) === null || _a === void 0 ? void 0 : _a.focus();
            }, 0);
        }
    };
    const handleSelectChange = (selectedItems) => {
        setSelectedFiles(selectedItems);
        handleChange(selectedItems.map(item => item.value), field.id);
    };
    const onNameChange = (event) => {
        setName(event.target.value);
    };
    const handleBrowseFiles = async () => {
        try {
            const res = await (0,_BrowseFileDialog__WEBPACK_IMPORTED_MODULE_2__.showBrowseFileDialog)(manager, {
                multiselect: true,
                includeDir: true,
                filter: (model) => model.path !== context.path,
            });
            if (res.value && res.value.length > 0) {
                const relativePaths = res.value.map(file => _PipelineService__WEBPACK_IMPORTED_MODULE_3__.PipelineService.getRelativePath(context.path, file.path));
                const newSelectedFiles = relativePaths.map(path => ({ label: path, value: path }));
                const updatedSelectedFiles = [...selectedFiles, ...newSelectedFiles].filter((file, index, self) => index === self.findIndex(f => f.value === file.value));
                setSelectedFiles(updatedSelectedFiles);
                handleChange(updatedSelectedFiles.map(f => f.value), field.id);
            }
        }
        catch (error) {
            console.error("Error selecting files:", error);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space.Compact, { style: { width: '100%' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { mode: "multiple", labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%' }, className: "nodrag", onChange: handleSelectChange, value: selectedFiles, placeholder: field.placeholder || 'Select files', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                menu,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { placeholder: "Add file", ref: inputSelectRef, value: name, onChange: onNameChange, onKeyDown: (e) => {
                            if (e.key === 'Enter') {
                                addItem(e);
                            }
                        } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__["default"], null), onClick: addItem }, "Add")))), options: selectedFiles }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", size: advanced ? "middle" : "small", onClick: handleBrowseFiles },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["default"], null))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(InputFiles));


/***/ }),

/***/ "./lib/forms/InputQuantity.js":
/*!************************************!*\
  !*** ./lib/forms/InputQuantity.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InputQuantity: () => (/* binding */ InputQuantity),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);


const InputQuantity = ({ field, value, handleChange, context, advanced }) => {
    const [isChecked, setIsChecked] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const onChange = (e) => {
        setIsChecked(e.target.checked);
        if (e.target.checked) {
            handleChange('None', field.id); // Update field value to None
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.InputNumber, { ...(field.min ? { min: field.min } : {}), ...(field.max ? { max: field.max } : {}), id: field.id, name: field.id, value: isChecked ? undefined : value, onChange: value => handleChange(value, field.id), disabled: isChecked, changeOnWheel: true }),
        field.noneOption && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Checkbox, { checked: isChecked, onChange: onChange }, "None"))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(InputQuantity));


/***/ }),

/***/ "./lib/forms/InputRegular.js":
/*!***********************************!*\
  !*** ./lib/forms/InputRegular.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InputRegular: () => (/* binding */ InputRegular),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _variablesUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../variablesUtils */ "./lib/variablesUtils.js");



const InputRegular = ({ field, value, handleChange, context, advanced }) => {
    const { inputValue, inputRef, openValue, setOpenValue, optionsVariables, handleInputChange, handleSelect, filterOptions, suffix, } = (0,_variablesUtils__WEBPACK_IMPORTED_MODULE_2__.useVariableAutoComplete)({ field, value, handleChange, context, advanced });
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.AutoComplete, { ref: inputRef, id: field.id, 
        // popupClassName="certain-category-search-dropdown"
        options: optionsVariables, filterOption: filterOptions, size: advanced ? "middle" : "small", open: openValue, onBlur: () => setOpenValue(false), defaultOpen: false, value: inputValue, onChange: handleInputChange, onSelect: handleSelect }, field.inputType === 'password' ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Input.Password
    // {...(field.connection && field.advanced && { addonBefore: selectBefore })}
    , { 
        // {...(field.connection && field.advanced && { addonBefore: selectBefore })}
        placeholder: field.placeholder, ref: inputRef, id: field.id, size: advanced ? "middle" : "small", name: field.id, autoComplete: "off", 
        // iconRender={(visible) => (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />)}
        value: inputValue, suffix: suffix })) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(antd__WEBPACK_IMPORTED_MODULE_0__.Input
    // {...(field.connection && field.advanced && { addonBefore: selectBefore })}
    , { 
        // {...(field.connection && field.advanced && { addonBefore: selectBefore })}
        placeholder: field.placeholder, ref: inputRef, id: field.id, size: advanced ? "middle" : "small", name: field.id, autoComplete: "off", suffix: suffix }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_1___default().memo(InputRegular));


/***/ }),

/***/ "./lib/forms/TextareaRegular.js":
/*!**************************************!*\
  !*** ./lib/forms/TextareaRegular.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TextareaRegular: () => (/* binding */ TextareaRegular),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);


const { TextArea } = antd__WEBPACK_IMPORTED_MODULE_1__.Input;
const TextareaRegular = ({ field, value, handleChange, advanced, rows }) => {
    const [inputValue, setInputValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setInputValue(value); // Update inputValue when value prop changes
    }, [value]);
    const handleInputChange = (e) => {
        const newValue = e.target.value;
        const cursorPosition = e.target.selectionStart; // Save the cursor position
        setInputValue(newValue);
        handleChange(newValue, field.id);
        // Reset cursor position after the state updates
        setTimeout(() => {
            if (inputRef.current) {
                inputRef.current.selectionStart = cursorPosition;
                inputRef.current.selectionEnd = cursorPosition;
            }
        }, 0);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(TextArea, { ref: inputRef, id: field.id, size: advanced ? "middle" : "small", name: field.id, placeholder: field.placeholder, onChange: handleInputChange, value: inputValue, autoComplete: "off", rows: rows }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(TextareaRegular));


/***/ }),

/***/ "./lib/forms/dataMapping.js":
/*!**********************************!*\
  !*** ./lib/forms/dataMapping.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DataMapping: () => (/* binding */ DataMapping),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/DeleteOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");




const DataMapping = ({ data, field, handleChange, defaultValue, context, componentService, commands, nodeId, advanced }) => {
    const EditableContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(null);
    const [loadingsInput, setLoadingsInput] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [loadingsOutput, setLoadingsOutput] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const EditableRow = ({ index, ...props }) => {
        const [form] = antd__WEBPACK_IMPORTED_MODULE_1__.Form.useForm();
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form, { form: form, component: false },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(EditableContext.Provider, { value: form },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { ...props }))));
    };
    const EditableCell = ({ title, editable, children, dataIndex, record, handleSave, ...restProps }) => {
        var _a, _b;
        const form = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(EditableContext);
        const [editing, setEditing] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
        const handleSelectChange = (selection, record) => {
            const value = selection.value;
            const input = items.find(item => item.value === value); // Finds the item where value matches
            record.input = input; // Assigns the found item to record.input
            handleSave(record); // Save the updated record
        };
        let childNode = children;
        if (editable) {
            childNode =
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { style: { margin: 0 }, name: dataIndex, rules: [
                        {
                            required: true,
                            message: `${title} is required.`,
                        },
                    ] },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { showSearch: true, labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%' }, className: "nodrag", onChange: (value) => { handleSelectChange(value, record); }, value: (_b = (_a = record.input) === null || _a === void 0 ? void 0 : _a.value) !== null && _b !== void 0 ? _b : "", placeholder: 'Select column ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                                menu,
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '0 2px 2px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", onClick: (event) => {
                                            _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadingsInput, nodeId, 0, true);
                                        }, loading: loadingsInput }, "Retrieve columns")))), options: items.map((item) => ({ label: item.label, value: item.value, type: item.type, named: item.named })), optionRender: (option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, null,
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                                    " ",
                                    option.data.label),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Tag, null, option.data.type))) })));
        }
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...restProps }, childNode);
    };
    const [dataSource, setDataSource] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValue || []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        handleChange(dataSource, field.id);
    }, [dataSource]);
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { textAlign: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, { image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE })));
    const defaultColumns = [
        {
            title: 'Input Columns',
            dataIndex: 'input',
            width: '50%',
            editable: true,
        },
        {
            title: 'Output Schema',
            dataIndex: 'value',
            width: '50%',
            editable: false,
            render: (_, record) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, record.value),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Tag, null, record.type))))
        },
        {
            title: '',
            dataIndex: 'operation',
            render: (_, record) => dataSource.length >= 1 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Popconfirm, { title: "Sure to delete?", onConfirm: () => handleDelete(record.key) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null))) : null,
        }
    ];
    const [form] = antd__WEBPACK_IMPORTED_MODULE_1__.Form.useForm(); // Step 1: Create form instance
    const handleAdd = () => {
        const values = form.getFieldsValue(); // Step 2: Get values from the form
        console.log(values); // Do something with the form data
        console.log('Received values from form: ', values);
        const newData = {
            input: {},
            key: values.field.name,
            value: values.field.name,
            type: values.field.type
        };
        setDataSource([...dataSource, newData]);
    };
    const handleSave = (row) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, {
            ...item,
            ...row,
        });
        setDataSource(newData);
    };
    const handleDelete = (key) => {
        const newData = dataSource.filter((item) => item.key !== key);
        setDataSource(newData);
    };
    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };
    const columns = defaultColumns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                handleSave,
            }),
        };
    });
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            field.outputType === 'relationalDatabase' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", size: "small", style: { marginBottom: 16 }, onClick: (event) => {
                    var _a;
                    setDataSource([]);
                    _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveTableColumns(event, `${(_a = data.schema) !== null && _a !== void 0 ? _a : 'public'}`, `${data.tableName.value}`, `${field.query}`, `${field.pythonExtraction}`, context, componentService, setDataSource, setLoadingsOutput, nodeId);
                }, loading: loadingsOutput }, "Retrieve schema")) : null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Table, { components: components, rowClassName: () => 'editable-row', bordered: true, dataSource: dataSource, columns: columns }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form, { style: { marginTop: 16 }, name: "Add field row", layout: "inline", form: form },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, { name: "field" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FieldValueInput, { field: field })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleAdd }, "Add a field"))))));
};
const FieldValueInput = ({ field, value = {}, onChange }) => {
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [type, setType] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [nameType, setNameType] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(field.typeOptions);
    const triggerChange = (changedValue) => {
        onChange === null || onChange === void 0 ? void 0 : onChange({ name, type, ...value, ...changedValue });
    };
    const onNameChange = (e) => {
        const newName = e.target.value || '';
        setName(newName);
        triggerChange({ name: newName });
    };
    const onTypeChange = (newType) => {
        setType(newType);
        triggerChange({ type: newType });
    };
    const onNameTypeChange = (event) => {
        setNameType(event.target.value);
    };
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: nameType, label: nameType }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { type: "text", value: name, placeholder: 'Field name', onChange: onNameChange, style: { width: 150 } }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { value: type, style: { width: 220, margin: '0 8px' }, className: "nodrag", onChange: onTypeChange, dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                menu,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { placeholder: "Custom", ref: inputRef, value: nameType, onChange: onNameTypeChange, onKeyDown: (e) => e.stopPropagation() }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__["default"], null), onClick: addItem }, "Add type")))), options: items.map((item) => ({ label: item.value, value: item.value })) })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataMapping);


/***/ }),

/***/ "./lib/forms/keyValueColumns.js":
/*!**************************************!*\
  !*** ./lib/forms/keyValueColumns.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   KeyValueColumns: () => (/* binding */ KeyValueColumns),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/MinusCircleOutlined.js");
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");




const KeyValueColumns = ({ field, handleChange, initialValues, context, componentService, commands, nodeId, advanced }) => {
    const [keyValuePairs, setKeyValuePairs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValues || [{ key: { value: '', type: '', named: true }, value: '' }]);
    const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const handleAddPair = () => {
        setKeyValuePairs([...keyValuePairs, { key: '', value: '' }]);
        handleChange(keyValuePairs, field.id);
    };
    const handleRemovePair = (index) => {
        const pairs = [...keyValuePairs];
        pairs.splice(index, 1);
        setKeyValuePairs(pairs);
        handleChange(pairs, field.id);
    };
    const handleChangeKV = (e, index, property) => {
        const updatedKeyValuePairs = [...keyValuePairs];
        updatedKeyValuePairs[index] = {
            ...updatedKeyValuePairs[index],
            [property]: e.target.value
        };
        setKeyValuePairs(updatedKeyValuePairs);
        handleChange(updatedKeyValuePairs, field.id);
    };
    const getAvailableItems = (index) => {
        const selectedKeys = keyValuePairs.map(pair => pair.key).filter((_, idx) => idx !== index);
        return items ? items.filter(item => !selectedKeys.includes(item.value)) : [];
    };
    const getTypeNamedByValue = (items, value) => {
        const item = items.find(item => item.value === value);
        if (item) {
            return { type: item.type, named: item.named };
        }
        return undefined;
    };
    const onNameChange = (event) => {
        setName(event.target.value);
    };
    const handleSelectChange = (selection, index) => {
        const value = selection.value;
        const { type, named } = getTypeNamedByValue(items, value);
        const updatedKeyValuePairs = [...keyValuePairs];
        updatedKeyValuePairs[index] = {
            ...updatedKeyValuePairs[index],
            key: { value: value, type: type, named: named }
        };
        setKeyValuePairs(updatedKeyValuePairs);
        handleChange(updatedKeyValuePairs, field.id);
    };
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { textAlign: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, { image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", onClick: (event) => _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadings, nodeId, 0, true), loading: loadings }, "Retrieve columns")));
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: name, label: name }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.List, { name: "keyValue" }, (fields, { add, remove }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null, keyValuePairs.map((pair, index) => {
            var _a;
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { display: 'flex', width: '100%', marginBottom: 8 }, align: "baseline" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%', minWidth: '250px' }, className: "nodrag", onChange: (value) => { handleSelectChange(value, index); }, value: pair.key, options: getAvailableItems(index).map(item => ({ label: item.label, value: item.value })), placeholder: field.placeholder || 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                            menu,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { size: advanced ? "middle" : "small", placeholder: "Custom", ref: inputRef, value: name, onChange: onNameChange, onKeyDown: (e) => e.stopPropagation() }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null), onClick: addItem }, "Add item")))) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { size: advanced ? "middle" : "small", name: `${field.id}_value_${index}`, placeholder: ((_a = field.placeholder) === null || _a === void 0 ? void 0 : _a.value) || 'value', id: `${field.id}_value_${index}`, value: pair.value, onChange: (e) => handleChangeKV(e, index, 'value'), autoComplete: "off" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__["default"], { onClick: () => handleRemovePair(index) })));
        })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "dashed", onClick: handleAddPair, block: true, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null) },
                "Add ",
                field.elementName ? field.elementName : 'item'))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(KeyValueColumns));


/***/ }),

/***/ "./lib/forms/keyValueColumnsRadio.js":
/*!*******************************************!*\
  !*** ./lib/forms/keyValueColumnsRadio.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   KeyValueColumnsRadio: () => (/* binding */ KeyValueColumnsRadio),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/MinusCircleOutlined.js");
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");




const KeyValueColumnsRadio = ({ field, handleChange, initialValues, context, componentService, commands, nodeId, advanced }) => {
    const [keyValuePairs, setKeyValuePairs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValues || [{ key: { value: '', type: '', named: true }, value: '' }]);
    const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(field.options);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const findOptionByValue = (value) => {
        return field.options.find(option => option.value === value) || { value: value, label: value };
    };
    const handleAddPair = () => {
        setKeyValuePairs([...keyValuePairs, { key: '', value: '' }]);
        handleChange(keyValuePairs, field.id);
    };
    const handleRemovePair = (index) => {
        const pairs = [...keyValuePairs];
        pairs.splice(index, 1);
        setKeyValuePairs(pairs);
        handleChange(pairs, field.id);
    };
    const handleChangeKV = (newValue, index, property) => {
        const updatedKeyValuePairs = [...keyValuePairs];
        updatedKeyValuePairs[index] = {
            ...updatedKeyValuePairs[index],
            [property]: newValue
        };
        setKeyValuePairs(updatedKeyValuePairs);
        handleChange(updatedKeyValuePairs, field.id);
    };
    const getAvailableItems = (index) => {
        const selectedKeys = keyValuePairs.map(pair => pair.key).filter((_, idx) => idx !== index);
        return items ? items.filter(item => !selectedKeys.includes(item.value)) : [];
    };
    const getTypeNamedByValue = (items, value) => {
        const item = items.find(item => item.value === value);
        if (item) {
            return { type: item.type, named: item.named };
        }
        return undefined;
    };
    const onNameChange = (event) => {
        setName(event.target.value);
    };
    const handleSelectColumnChange = (selection, index) => {
        const value = selection.value;
        const { type, named } = getTypeNamedByValue(items, value);
        const updatedKeyValuePairs = [...keyValuePairs];
        updatedKeyValuePairs[index] = {
            ...updatedKeyValuePairs[index],
            key: { value: value, type: type, named: named }
        };
        setKeyValuePairs(updatedKeyValuePairs);
        handleChange(updatedKeyValuePairs, field.id);
    };
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { textAlign: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, { image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", onClick: (event) => _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadings, nodeId, 0, true), loading: loadings }, "Retrieve columns")));
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: name, label: name }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.List, { name: "keyValue" }, (fields, { add, remove }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null, keyValuePairs.map((pair, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { direction: "vertical", style: { display: 'flex', width: '100%', marginBottom: 8 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { labelInValue: true, size: advanced ? "middle" : "small", className: "nodrag", onChange: (value) => { handleSelectColumnChange(value, index); }, value: pair.key, options: getAvailableItems(index).map(item => ({ label: item.label, value: item.value })), placeholder: 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        menu,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { size: advanced ? "middle" : "small", placeholder: "Custom", ref: inputRef, value: name, onChange: onNameChange, onKeyDown: (e) => e.stopPropagation() }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null), onClick: addItem }, "Add item")))) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Flex, { vertical: true, gap: "middle" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Radio.Group, { value: pair.value, onChange: (e) => handleChangeKV(e.target.value, index, 'value'), buttonStyle: "solid" }, options.map((option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Radio.Button, { value: option.value }, option.label))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__["default"], { onClick: () => handleRemovePair(index) }))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "dashed", onClick: handleAddPair, block: true, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null) },
                "Add ",
                field.elementName ? field.elementName : 'item'))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(KeyValueColumnsRadio));


/***/ }),

/***/ "./lib/forms/keyValueColumnsSelect.js":
/*!********************************************!*\
  !*** ./lib/forms/keyValueColumnsSelect.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   KeyValueColumnsSelect: () => (/* binding */ KeyValueColumnsSelect),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/MinusCircleOutlined.js");
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");




const KeyValueColumnsSelect = ({ field, handleChange, initialValues, context, componentService, commands, nodeId, advanced }) => {
    const [keyValuePairs, setKeyValuePairs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValues || [{ key: { value: '', type: '', named: true }, value: '' }]);
    const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(field.options);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const findOptionByValue = (value) => {
        return field.options.find(option => option.value === value) || { value: value, label: value };
    };
    const handleAddPair = () => {
        setKeyValuePairs([...keyValuePairs, { key: '', value: '' }]);
        handleChange(keyValuePairs, field.id);
    };
    const handleRemovePair = (index) => {
        const pairs = [...keyValuePairs];
        pairs.splice(index, 1);
        setKeyValuePairs(pairs);
        handleChange(pairs, field.id);
    };
    const handleChangeKV = (newValue, index, property) => {
        const updatedKeyValuePairs = [...keyValuePairs];
        updatedKeyValuePairs[index] = {
            ...updatedKeyValuePairs[index],
            [property]: newValue
        };
        setKeyValuePairs(updatedKeyValuePairs);
        handleChange(updatedKeyValuePairs, field.id);
    };
    const getAvailableItems = (index) => {
        const selectedKeys = keyValuePairs.map(pair => pair.key).filter((_, idx) => idx !== index);
        return items ? items.filter(item => !selectedKeys.includes(item.value)) : [];
    };
    const getTypeNamedByValue = (items, value) => {
        const item = items.find(item => item.value === value);
        if (item) {
            return { type: item.type, named: item.named };
        }
        return undefined;
    };
    const onNameChange = (event) => {
        setName(event.target.value);
    };
    const handleSelectColumnChange = (selection, index) => {
        const value = selection.value;
        const { type, named } = getTypeNamedByValue(items, value);
        const updatedKeyValuePairs = [...keyValuePairs];
        updatedKeyValuePairs[index] = {
            ...updatedKeyValuePairs[index],
            key: { value: value, type: type, named: named }
        };
        setKeyValuePairs(updatedKeyValuePairs);
        handleChange(updatedKeyValuePairs, field.id);
    };
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { textAlign: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, { image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", onClick: (event) => _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadings, nodeId, 0, true), loading: loadings }, "Retrieve columns")));
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: name, label: name }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.List, { name: "keyValue" }, (fields, { add, remove }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null, keyValuePairs.map((pair, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { direction: "vertical", style: { display: 'flex', width: '100%', marginBottom: 8 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { labelInValue: true, size: advanced ? "middle" : "small", className: "nodrag", onChange: (value) => { handleSelectColumnChange(value, index); }, value: pair.key, options: getAvailableItems(index).map(item => ({ label: item.label, value: item.value })), placeholder: 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        menu,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { size: advanced ? "middle" : "small", placeholder: "Custom", ref: inputRef, value: name, onChange: onNameChange, onKeyDown: (e) => e.stopPropagation() }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null), onClick: addItem }, "Add item")))) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { labelInValue: true, size: advanced ? "middle" : "small", id: `${field.id}_value_${index}`, className: "nodrag", onChange: (value) => handleChangeKV(value, index, 'value'), value: pair.value, placeholder: "Select ...", ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), options: options.map(option => ({
                    label: option.label,
                    value: option.value
                })) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__["default"], { onClick: () => handleRemovePair(index) }))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "dashed", onClick: handleAddPair, block: true, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null) },
                "Add ",
                field.elementName ? field.elementName : 'item'))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(KeyValueColumnsSelect));


/***/ }),

/***/ "./lib/forms/keyValueForm.js":
/*!***********************************!*\
  !*** ./lib/forms/keyValueForm.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   KeyValueForm: () => (/* binding */ KeyValueForm),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/MinusCircleOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");



const KeyValueForm = ({ field, handleChange, initialValues }) => {
    const [keyValuePairs, setKeyValuePairs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValues || [{ key: '', value: '' }]);
    const handleAddPair = () => {
        setKeyValuePairs([...keyValuePairs, { key: '', value: '' }]);
        handleChange(keyValuePairs, field.id);
    };
    const handleRemovePair = (index) => {
        const pairs = [...keyValuePairs];
        pairs.splice(index, 1);
        setKeyValuePairs(pairs);
        handleChange(pairs, field.id);
    };
    const handleChangeKV = (e, index, property) => {
        const updatedKeyValuePairs = [...keyValuePairs];
        updatedKeyValuePairs[index] = {
            ...updatedKeyValuePairs[index],
            [property]: e.target.value
        };
        setKeyValuePairs(updatedKeyValuePairs);
        handleChange(updatedKeyValuePairs, field.id);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.List, { name: "keyValue" }, (fields, { add, remove }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null, keyValuePairs.map((pair, index) => {
            var _a, _b;
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { display: 'flex', marginBottom: 8 }, align: "baseline" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { name: `${field.id}_key_${index}`, placeholder: ((_a = field.placeholder) === null || _a === void 0 ? void 0 : _a.key) || 'key', id: `${field.id}_key_${index}`, value: pair.key, onChange: (e) => handleChangeKV(e, index, 'key'), autoComplete: "off" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { name: `${field.id}_value_${index}`, placeholder: ((_b = field.placeholder) === null || _b === void 0 ? void 0 : _b.value) || 'value', id: `${field.id}_value_${index}`, value: pair.value, onChange: (e) => handleChangeKV(e, index, 'value'), autoComplete: "off" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__["default"], { onClick: () => handleRemovePair(index) })));
        })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "dashed", onClick: handleAddPair, block: true, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null) },
                "Add ",
                field.elementName ? field.elementName : 'item'))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(KeyValueForm));


/***/ }),

/***/ "./lib/forms/selectColumn.js":
/*!***********************************!*\
  !*** ./lib/forms/selectColumn.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectColumn: () => (/* binding */ SelectColumn),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _AddNewColumn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./AddNewColumn */ "./lib/forms/AddNewColumn.js");
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");




const SelectColumn = ({ field, handleChange, defaultValue, context, componentService, commands, nodeId, advanced }) => {
    const findOptionByValue = (value) => {
        if (value === undefined) {
            return {};
        }
        else {
            return items.find(option => option.value === value.value) || { value: value.value, label: value.value };
        }
    };
    const getTypeNamedByValue = (items, value) => {
        const item = items.find(item => item.value === value);
        if (item) {
            return { type: item.type, named: item.named };
        }
        return undefined;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setSelectedOption(findOptionByValue(defaultValue));
    }, [defaultValue, field.options]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [selectedOption, setSelectedOption] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(findOptionByValue(defaultValue));
    const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const inputNb = field.inputNb ? field.inputNb - 1 : 0;
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: name, label: name, type: 'object', named: true }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    const handleSelectChange = (selection, option) => {
        const value = selection.value;
        const selectedOption = findOptionByValue(value);
        setSelectedOption(selectedOption);
        const { type, named } = getTypeNamedByValue(items, value);
        handleChange({ value, type, named }, field.id);
    };
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { textAlign: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, { image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE })));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { showSearch: true, labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%' }, className: "nodrag", onChange: (value, option) => handleSelectChange(value, option), value: selectedOption, placeholder: field.placeholder || 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                menu,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '0 2px 4px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", onClick: (event) => _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadings, nodeId, inputNb, true), loading: loadings }, "Retrieve columns")),
                advanced && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_AddNewColumn__WEBPACK_IMPORTED_MODULE_3__.AddNewColumn, { items: items, setItems: setItems, setSelectedOption: setSelectedOption })))))), options: items.map((item) => ({ label: item.label, value: item.value, type: item.type, named: item.named })), optionRender: (option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    " ",
                    option.data.label),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Tag, null, option.data.type))) })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(SelectColumn));


/***/ }),

/***/ "./lib/forms/selectColumns.js":
/*!************************************!*\
  !*** ./lib/forms/selectColumns.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectColumns: () => (/* binding */ SelectColumns),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");
/* harmony import */ var _AddNewColumn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./AddNewColumn */ "./lib/forms/AddNewColumn.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);




const SelectColumns = ({ field, handleChange, defaultValues, context, componentService, commands, nodeId, advanced }) => {
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(field.options || []);
    const [selectedOptions, setSelectedOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValues);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const inputNb = field.inputNb ? field.inputNb - 1 : 0;
    const getTypeNamedByValue = (items, value) => {
        const item = items.find(item => item.value === value);
        if (item) {
            return { type: item.type, named: item.named };
        }
        return undefined;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setSelectedOptions(defaultValues);
    }, [defaultValues]);
    const handleSelectChange = (selectedItems) => {
        setSelectedOptions(selectedItems);
        const options = selectedItems.map(item => ({
            ...getTypeNamedByValue(items, item.value),
            value: item.value
        }));
        handleChange(options, field.id);
    };
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { textAlign: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, { image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE })));
    const retrieveColumns = (event) => {
        _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadings, nodeId, inputNb, true);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { showSearch: true, mode: "multiple", labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%' }, className: "nodrag", onChange: handleSelectChange, value: selectedOptions, placeholder: field.placeholder || 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                menu,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '0 2px 2px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", onClick: (event) => _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadings, nodeId, inputNb, true), loading: loadings }, "Retrieve columns")),
                advanced && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_AddNewColumn__WEBPACK_IMPORTED_MODULE_3__.AddNewColumn, { items: items, setItems: setItems, setSelectedOption: setSelectedOptions })))))), options: items.map((item) => ({ label: item.label, value: item.value, type: item.type })), optionRender: (option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    " ",
                    option.data.label),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Tag, null, option.data.type))) })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(SelectColumns));


/***/ }),

/***/ "./lib/forms/selectCustomizable.js":
/*!*****************************************!*\
  !*** ./lib/forms/selectCustomizable.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectCustomizable: () => (/* binding */ SelectCustomizable),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);



const SelectCustomizable = ({ field, handleChange, defaultValue, advanced }) => {
    const findOptionByValue = (value) => {
        return field.options.find(option => option.value === value) || { value: value, label: value };
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setSelectedOption(findOptionByValue(defaultValue));
    }, [defaultValue, field.options]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(field.options);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [selectedOption, setSelectedOption] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(findOptionByValue(defaultValue));
    let index = 0;
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: name, label: name }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    const handleSelectChange = (option) => {
        setSelectedOption(option);
        handleChange(option === null || option === void 0 ? void 0 : option.value, field.id);
    };
    const onNameChange = (event) => {
        setName(event.target.value);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%' }, className: "nodrag", onChange: handleSelectChange, value: selectedOption || undefined, placeholder: field.placeholder || 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            menu,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { placeholder: "Custom", ref: inputRef, value: name, onChange: onNameChange, onKeyDown: (e) => e.stopPropagation() }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__["default"], null), onClick: addItem }, "Add item")))), options: items.map((item) => ({ label: item.label, value: item.value })) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(SelectCustomizable));


/***/ }),

/***/ "./lib/forms/selectFromSQLQuery.js":
/*!*****************************************!*\
  !*** ./lib/forms/selectFromSQLQuery.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectFromSQLQuery: () => (/* binding */ SelectFromSQLQuery),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");




const SelectFromSQLQuery = ({ data, field, handleChange, defaultValue, context, componentService, commands, nodeId, advanced, }) => {
    const findOptionByValue = (value) => {
        if (value === undefined) {
            return {};
        }
        else {
            return items.find((option) => option.value === value.value) || { value: value.value, label: value.value };
        }
    };
    const getTypeNamedByValue = (items, value) => {
        const item = items.find((item) => item.value === value);
        if (item) {
            return { type: item.type, named: item.named };
        }
        return undefined;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setSelectedOption(findOptionByValue(defaultValue));
    }, [defaultValue, field.options]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [selectedOption, setSelectedOption] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(findOptionByValue(defaultValue));
    const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const inputNb = field.inputNb ? field.inputNb - 1 : 0;
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: name, label: name, type: 'table', named: true }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    const handleSelectChange = (selection, option) => {
        const value = selection.value;
        const selectedOption = findOptionByValue(value);
        setSelectedOption(selectedOption);
        const { type, named } = getTypeNamedByValue(items, value) || { type: '', named: false };
        handleChange({ value, type, named }, field.id);
    };
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { textAlign: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, { image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE })));
    const onNameChange = (event) => {
        setName(event.target.value);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { showSearch: true, labelInValue: true, size: advanced ? 'middle' : 'small', style: { width: '100%' }, className: "nodrag", onChange: (value, option) => handleSelectChange(value, option), value: selectedOption, placeholder: field.placeholder || 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                menu,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '0 2px 4px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", onClick: (event) => {
                            var _a;
                            return _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveTableList(event, `${(_a = data.schema) !== null && _a !== void 0 ? _a : 'public'}`, field.query, context, componentService, setItems, setLoadings, nodeId);
                        }, loading: loadings }, "Retrieve")),
                advanced && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { placeholder: "Custom", ref: inputRef, value: name, onChange: onNameChange, onKeyDown: (e) => e.stopPropagation() }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null), onClick: addItem }, "Add")))))), options: items.map((item) => ({
                label: item.label,
                value: item.value,
                type: item.type,
                named: item.named,
            })), optionRender: (option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    " ",
                    option.data.label),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Tag, null, option.data.type))) })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(SelectFromSQLQuery));


/***/ }),

/***/ "./lib/forms/selectMultipleCustomizable.js":
/*!*************************************************!*\
  !*** ./lib/forms/selectMultipleCustomizable.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectMultipleCustomizable: () => (/* binding */ SelectMultipleCustomizable),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);



const SelectMultipleCustomizable = ({ field, handleChange, defaultValues, advanced }) => {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setSelectedOptions(defaultValues);
    }, [defaultValues]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(field.options);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [selectedOptions, setSelectedOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValues);
    let index = 0;
    const addItem = (e) => {
        e.preventDefault();
        setItems([...items, { value: name, label: name }]);
        setName('');
        setTimeout(() => {
            var _a;
            (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 0);
    };
    const handleSelectChange = (selectedItems) => {
        setSelectedOptions(selectedItems);
        handleChange(selectedItems.map(item => item.value), field.id);
    };
    const onNameChange = (event) => {
        setName(event.target.value);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { mode: "multiple", labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%' }, className: "nodrag", onChange: handleSelectChange, value: selectedOptions, placeholder: field.placeholder || 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            menu,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { placeholder: "Custom", ref: inputRef, value: name, onChange: onNameChange, onKeyDown: (e) => e.stopPropagation() }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__["default"], null), onClick: addItem }, "Add")))), options: items.map((item) => ({ label: item.label, value: item.value })) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(SelectMultipleCustomizable));


/***/ }),

/***/ "./lib/forms/selectRegular.js":
/*!************************************!*\
  !*** ./lib/forms/selectRegular.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectRegular: () => (/* binding */ SelectRegular),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/QuestionCircleOutlined.js");



const SelectRegular = ({ field, handleChange, defaultValue, advanced }) => {
    const findOptionByValue = (value) => {
        return field.options.find(option => option.value === value) || { value: value, label: value };
    };
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(field.options);
    const [selectedOption, setSelectedOption] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValue ? findOptionByValue(defaultValue) : undefined);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setSelectedOption(findOptionByValue(defaultValue));
    }, [defaultValue, field.options]);
    const handleSelectChange = (option) => {
        setSelectedOption(option);
        handleChange(option === null || option === void 0 ? void 0 : option.value, field.id);
    };
    const optionRenderItems = (option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, option.data.label),
        option.data.tooltip && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: option.data.tooltip },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__["default"], null)))));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%' }, className: "nodrag", onChange: handleSelectChange, value: selectedOption || null, placeholder: field.placeholder || 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), options: items.map(item => ({
            label: item.label,
            value: item.value,
            tooltip: item.tooltip
        })), optionRender: optionRenderItems }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(SelectRegular));


/***/ }),

/***/ "./lib/forms/selectSheetFromExcel.js":
/*!*******************************************!*\
  !*** ./lib/forms/selectSheetFromExcel.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectSheetFromExcel: () => (/* binding */ SelectSheetFromExcel),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");




const SelectSheetFromExcel = ({ data, field, handleChange, defaultValue, context, componentService, commands, nodeId, advanced, }) => {
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [selectedOptions, setSelectedOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValue);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [customName, setCustomName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const findOptionByValue = (value) => items.find((option) => option.value === value) || { label: value, value };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (defaultValue) {
            setSelectedOptions(defaultValue);
        }
    }, [defaultValue]);
    const retrieveSheets = (event) => {
        _RequestService__WEBPACK_IMPORTED_MODULE_2__.RequestService.retrieveSheetNames(event, context, componentService, setItems, setLoading, nodeId);
    };
    const handleSelectChange = (selectedItems) => {
        setSelectedOptions(selectedItems);
        handleChange(selectedItems.map((item) => item.value), field.id);
    };
    const addItem = () => {
        const newItem = { value: customName, label: customName };
        setItems([...items, newItem]);
        setSelectedOptions([...selectedOptions, newItem]);
        handleChange([...selectedOptions.map((item) => item.value), customName], field.id);
        setCustomName('');
        setTimeout(() => { var _a; return (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus(); }, 0);
    };
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { textAlign: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, { image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE, description: "No sheets available" })));
    const onNameChange = (event) => {
        setCustomName(event.target.value);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { mode: "multiple", labelInValue: true, size: advanced ? 'middle' : 'small', style: { width: '100%' }, value: selectedOptions, onChange: handleSelectChange, placeholder: field.placeholder || 'Select sheets', dropdownRender: (menu) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                menu,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { display: 'flex', justifyContent: 'center', padding: '0 8px 4px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "primary", onClick: retrieveSheets, loading: loading }, "Retrieve Sheets")),
                advanced && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Divider, { style: { margin: '8px 0' } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { style: { padding: '0 8px 4px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { placeholder: "Custom Sheet", ref: inputRef, value: customName, onChange: onNameChange, onKeyDown: (e) => e.stopPropagation() }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "text", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null), onClick: addItem }, "Add")))))), options: items.map((item) => ({
                label: item.label,
                value: item.value,
            })) })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(SelectSheetFromExcel));


/***/ }),

/***/ "./lib/forms/selectTokenization.js":
/*!*****************************************!*\
  !*** ./lib/forms/selectTokenization.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectTokenization: () => (/* binding */ SelectTokenization),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);


const SelectTokenization = ({ field, handleChange, defaultValue, advanced }) => {
    // Assuming defaultValues are already in the correct format
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setSelectedOptions(defaultValue);
    }, [defaultValue]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(field.options);
    const [selectedOptions, setSelectedOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValue);
    const handleSelectChange = (selectedItems) => {
        setSelectedOptions(selectedItems);
        handleChange(selectedItems.map(item => item.value), field.id);
    };
    const customizeRenderEmpty = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { display: 'none' } }));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.ConfigProvider, { renderEmpty: customizeRenderEmpty },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Select, { mode: "tags", labelInValue: true, size: advanced ? "middle" : "small", style: { width: '100%' }, className: "nodrag", onChange: handleSelectChange, value: selectedOptions, tokenSeparators: [','], placeholder: field.placeholder || 'Select ...', ...(field.required ? { required: field.required } : {}), ...(field.tooltip ? { tooltip: field.tooltip } : {}), options: items.map(item => ({
                label: item.label,
                value: item.value
            })) })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(SelectTokenization));


/***/ }),

/***/ "./lib/forms/transferData.js":
/*!***********************************!*\
  !*** ./lib/forms/transferData.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransferData: () => (/* binding */ TransferData),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dnd */ "webpack/sharing/consume/default/react-dnd/react-dnd");
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dnd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../RequestService */ "./lib/RequestService.js");
/* harmony import */ var _DndProviderWrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../DndProviderWrapper */ "./lib/DndProviderWrapper.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);





const TransferData = ({ field, handleChange, defaultValue, context, componentService, commands, nodeId, advanced }) => {
    const DragableBodyRow = ({ index, rowDrop, className, style, ...restProps }) => {
        const ref = react__WEBPACK_IMPORTED_MODULE_0___default().useRef();
        const [{ isOver, dropClassName }, drop] = (0,react_dnd__WEBPACK_IMPORTED_MODULE_1__.useDrop)({
            accept: 'DragableBodyRow',
            collect: (monitor) => {
                const item = monitor.getItem(); // Cast to DragItem
                if (item && item.index === index) {
                    return {};
                }
                return {
                    isOver: monitor.isOver(),
                    dropClassName: item && item.index < index ? ' drop-over-downward' : ' drop-over-upward',
                };
            },
            drop: (item) => {
                rowDrop(item.index, index);
            },
        });
        const [, drag] = (0,react_dnd__WEBPACK_IMPORTED_MODULE_1__.useDrag)({
            type: 'DragableBodyRow',
            item: { type: 'DragableBodyRow', index },
            collect: (monitor) => ({
                isDragging: monitor.isDragging(),
            }),
        });
        drag(drop(ref));
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { ref: ref, className: `${className}${isOver ? dropClassName : ''} draggable`, style: { cursor: 'move', opacity: isOver ? 0.5 : 1, ...style }, ...restProps }));
    };
    // Customize Table Transfer
    const TableTransfer = ({ leftColumns, rightColumns, ...restProps }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Transfer, { ...restProps }, ({ direction, filteredItems, onItemSelect, onItemSelectAll, selectedKeys: listSelectedKeys, disabled: listDisabled, }) => {
        const columns = direction === 'left' ? leftColumns : rightColumns;
        const displayType = direction === 'right' ? 'target' : 'source';
        const rowSelection = {
            getCheckboxProps: () => ({ disabled: listDisabled }),
            onChange(selectedRowKeys) {
                onItemSelectAll(selectedRowKeys, 'replace');
            },
            selectedRowKeys: listSelectedKeys,
            selections: [antd__WEBPACK_IMPORTED_MODULE_2__.Table.SELECTION_ALL, antd__WEBPACK_IMPORTED_MODULE_2__.Table.SELECTION_INVERT, antd__WEBPACK_IMPORTED_MODULE_2__.Table.SELECTION_NONE],
        };
        if (displayType === 'source') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Table, { rowSelection: rowSelection, columns: columns, dataSource: filteredItems, size: "small", style: { pointerEvents: listDisabled ? 'none' : undefined }, onRow: ({ key, disabled: itemDisabled }) => ({
                    onClick: () => {
                        if (itemDisabled || listDisabled) {
                            return;
                        }
                        onItemSelect(key, !listSelectedKeys.includes(key));
                    },
                }) }));
        }
        else {
            const rowDrop = (dragIndex, hoverIndex) => {
                // Ensure the indices are valid
                if (dragIndex === undefined || hoverIndex === undefined) {
                    console.error("Invalid drag or hover index");
                    return;
                }
                // Create a copy of the target keys with all properties intact
                let newKeys = [...targetKeys];
                // Extract the dragged item and re-insert at the hover index
                const dragRow = newKeys.splice(dragIndex, 1)[0]; // Ensure correct extraction
                newKeys.splice(hoverIndex, 0, dragRow); // Insert at the correct position
                setTargetKeys(newKeys);
                const savedSchema = { sourceData: sourceData, targetKeys: newKeys };
                handleChange(savedSchema, field.id);
            };
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_DndProviderWrapper__WEBPACK_IMPORTED_MODULE_3__["default"], null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Table, { rowSelection: rowSelection, columns: columns, dataSource: filteredItems, components: {
                        body: {
                            row: DragableBodyRow,
                        },
                    }, size: "small", style: { pointerEvents: listDisabled ? 'none' : undefined }, onRow: (record, idx) => ({
                        index: idx,
                        rowDrop,
                        onClick: () => {
                            if (record.disabled) {
                                return;
                            }
                            onItemSelect(record.key, !listSelectedKeys.includes(record.key)); // Toggle selection
                        },
                    }) })));
        }
    }));
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [sourceData, setSourceData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [targetKeys, setTargetKeys] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const newSourceData = items.map(item => ({
            ...item,
            key: item.value,
            title: item.value
        }));
        setSourceData(newSourceData);
        // Update targetKeys to only include keys that exist in the new source data
        setTargetKeys(prevTargetKeys => prevTargetKeys.filter(key => newSourceData.some(item => item.key === key)));
    }, [items]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (defaultValue && defaultValue.sourceData && defaultValue.targetKeys) {
            setSourceData(defaultValue.sourceData);
            setTargetKeys(defaultValue.targetKeys);
        }
        else {
            // Provide default initialization for sourceData and targetKeys if defaultValue doesn't exist
            setSourceData([]);
            setTargetKeys([]);
        }
    }, [defaultValue]);
    const columns = [
        {
            dataIndex: 'value',
            title: 'Column',
        },
        {
            dataIndex: 'type',
            title: 'Type',
            render: (type) => react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Tag, null, type),
        }
    ];
    const onChange = (nextTargetKeys) => {
        setTargetKeys(nextTargetKeys);
        const savedSchema = { sourceData: sourceData, targetKeys: nextTargetKeys };
        handleChange(savedSchema, field.id);
    };
    const renderFooter = (_, info) => {
        if ((info === null || info === void 0 ? void 0 : info.direction) === 'left') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Button, { type: "primary", size: "small", style: { float: 'left', margin: 5 }, onClick: (event) => {
                    setItems([]);
                    _RequestService__WEBPACK_IMPORTED_MODULE_4__.RequestService.retrieveDataframeColumns(event, context, commands, componentService, setItems, setLoadings, nodeId, 0, true);
                }, loading: loadings }, "Retrieve columns"));
        }
        return;
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(TableTransfer, { dataSource: sourceData, targetKeys: targetKeys, showSearch: true, onChange: onChange, operations: ['include', 'exclude'], filterOption: (inputValue, item) => item.key.indexOf(inputValue) !== -1 || item.type.indexOf(inputValue) !== -1, leftColumns: columns, rightColumns: columns, footer: renderFooter }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Space, { style: { marginTop: 16 } })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(TransferData));


/***/ }),

/***/ "./lib/forms/valuesListForm.js":
/*!*************************************!*\
  !*** ./lib/forms/valuesListForm.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ValuesListForm: () => (/* binding */ ValuesListForm),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/MinusCircleOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/PlusOutlined.js");



const ValuesListForm = ({ field, handleChange, initialValues }) => {
    const [values, setValues] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialValues || ['']);
    const handleAddValue = () => {
        setValues([...values, '']);
        handleChange(values, field.id);
    };
    const handleRemoveValue = (index) => {
        const updatedValues = [...values];
        updatedValues.splice(index, 1);
        setValues(updatedValues);
        handleChange(updatedValues, field.id);
    };
    const handleChangeValue = (e, index) => {
        const updatedValues = [...values];
        updatedValues[index] = e.target.value;
        setValues(updatedValues);
        handleChange(updatedValues, field.id);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.List, { name: "values" }, (fields, { add, remove }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null, values.map((value, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Space, { key: index, style: { display: 'flex', marginBottom: 8 }, align: "baseline" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Input, { name: `${field.id}_value_${index}`, placeholder: "Value", id: `${field.id}_value_${index}`, value: value, onChange: (e) => handleChangeValue(e, index), autoComplete: "off" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__["default"], { onClick: () => handleRemoveValue(index) }))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_1__.Button, { type: "dashed", onClick: handleAddValue, block: true, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], null) }, "Add Value"))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (react__WEBPACK_IMPORTED_MODULE_0___default().memo(ValuesListForm));


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bracesIcon: () => (/* binding */ bracesIcon),
/* harmony export */   crosshairIcon: () => (/* binding */ crosshairIcon),
/* harmony export */   minusIcon: () => (/* binding */ minusIcon),
/* harmony export */   playCircleIcon: () => (/* binding */ playCircleIcon),
/* harmony export */   playIcon: () => (/* binding */ playIcon),
/* harmony export */   plusIcon: () => (/* binding */ plusIcon),
/* harmony export */   searchIcon: () => (/* binding */ searchIcon),
/* harmony export */   settingsIcon: () => (/* binding */ settingsIcon),
/* harmony export */   trashIcon: () => (/* binding */ trashIcon),
/* harmony export */   warningIcon: () => (/* binding */ warningIcon),
/* harmony export */   xIcon: () => (/* binding */ xIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_trash_16_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../style/icons/trash-16.svg */ "./style/icons/trash-16.svg");
/* harmony import */ var _style_icons_x_16_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../style/icons/x-16.svg */ "./style/icons/x-16.svg");
/* harmony import */ var _style_icons_search_16_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/icons/search-16.svg */ "./style/icons/search-16.svg");
/* harmony import */ var _style_icons_crosshair_16_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../style/icons/crosshair-16.svg */ "./style/icons/crosshair-16.svg");
/* harmony import */ var _style_icons_minus_16_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../style/icons/minus-16.svg */ "./style/icons/minus-16.svg");
/* harmony import */ var _style_icons_plus_16_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../style/icons/plus-16.svg */ "./style/icons/plus-16.svg");
/* harmony import */ var _style_icons_play_16_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../style/icons/play-16.svg */ "./style/icons/play-16.svg");
/* harmony import */ var _style_icons_play_circle_16_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../style/icons/play-circle-16.svg */ "./style/icons/play-circle-16.svg");
/* harmony import */ var _style_icons_settings_16_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/icons/settings-16.svg */ "./style/icons/settings-16.svg");
/* harmony import */ var _style_icons_braces_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../style/icons/braces.svg */ "./style/icons/braces.svg");
/* harmony import */ var _style_icons_alert_triangle_fill_16_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../style/icons/alert-triangle-fill-16.svg */ "./style/icons/alert-triangle-fill-16.svg");












const trashIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:trash-icon',
    svgstr: _style_icons_trash_16_svg__WEBPACK_IMPORTED_MODULE_1__
});
const xIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:cog-icon',
    svgstr: _style_icons_x_16_svg__WEBPACK_IMPORTED_MODULE_2__
});
const settingsIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:settings-icon',
    svgstr: _style_icons_settings_16_svg__WEBPACK_IMPORTED_MODULE_3__
});
const searchIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:search-icon',
    svgstr: _style_icons_search_16_svg__WEBPACK_IMPORTED_MODULE_4__
});
const minusIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:minus-icon',
    svgstr: _style_icons_minus_16_svg__WEBPACK_IMPORTED_MODULE_5__
});
const plusIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:plus-icon',
    svgstr: _style_icons_plus_16_svg__WEBPACK_IMPORTED_MODULE_6__
});
const playIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:play-icon',
    svgstr: _style_icons_play_16_svg__WEBPACK_IMPORTED_MODULE_7__
});
const playCircleIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:play-circle-icon',
    svgstr: _style_icons_play_circle_16_svg__WEBPACK_IMPORTED_MODULE_8__
});
const crosshairIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:crosshair-icon',
    svgstr: _style_icons_crosshair_16_svg__WEBPACK_IMPORTED_MODULE_9__
});
const warningIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:warning-icon',
    svgstr: _style_icons_alert_triangle_fill_16_svg__WEBPACK_IMPORTED_MODULE_10__
});
const bracesIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'amphi:braces-icon',
    svgstr: _style_icons_braces_svg__WEBPACK_IMPORTED_MODULE_11__
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeGenerator: () => (/* reexport safe */ _CodeGenerator__WEBPACK_IMPORTED_MODULE_4__.CodeGenerator),
/* harmony export */   CodeTextarea: () => (/* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_11__.CodeTextarea),
/* harmony export */   CodeTextareaMirror: () => (/* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_12__.CodeTextareaMirror),
/* harmony export */   ComponentManager: () => (/* binding */ ComponentManager),
/* harmony export */   GenerateUIFormComponent: () => (/* reexport safe */ _configUtils__WEBPACK_IMPORTED_MODULE_1__.GenerateUIFormComponent),
/* harmony export */   InputFile: () => (/* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_7__.InputFile),
/* harmony export */   InputRegular: () => (/* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_8__.InputRegular),
/* harmony export */   PipelineComponent: () => (/* reexport safe */ _PipelineComponent__WEBPACK_IMPORTED_MODULE_3__.PipelineComponent),
/* harmony export */   PipelineService: () => (/* reexport safe */ _PipelineService__WEBPACK_IMPORTED_MODULE_5__.PipelineService),
/* harmony export */   RequestService: () => (/* reexport safe */ _RequestService__WEBPACK_IMPORTED_MODULE_6__.RequestService),
/* harmony export */   SelectColumns: () => (/* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_10__.SelectColumns),
/* harmony export */   SelectRegular: () => (/* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_9__.SelectRegular),
/* harmony export */   createZoomSelector: () => (/* reexport safe */ _rendererUtils__WEBPACK_IMPORTED_MODULE_2__.createZoomSelector),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   onChange: () => (/* reexport safe */ _configUtils__WEBPACK_IMPORTED_MODULE_1__.onChange),
/* harmony export */   renderComponentUI: () => (/* reexport safe */ _rendererUtils__WEBPACK_IMPORTED_MODULE_2__.renderComponentUI),
/* harmony export */   renderHandle: () => (/* reexport safe */ _rendererUtils__WEBPACK_IMPORTED_MODULE_2__.renderHandle),
/* harmony export */   setDefaultConfig: () => (/* reexport safe */ _configUtils__WEBPACK_IMPORTED_MODULE_1__.setDefaultConfig)
/* harmony export */ });
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _configUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./configUtils */ "./lib/configUtils.js");
/* harmony import */ var _rendererUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./rendererUtils */ "./lib/rendererUtils.js");
/* harmony import */ var _PipelineComponent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./PipelineComponent */ "./lib/PipelineComponent.js");
/* harmony import */ var _CodeGenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CodeGenerator */ "./lib/CodeGenerator.js");
/* harmony import */ var _PipelineService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./PipelineService */ "./lib/PipelineService.js");
/* harmony import */ var _RequestService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./RequestService */ "./lib/RequestService.js");
/* harmony import */ var _forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./forms */ "./lib/forms/InputFile.js");
/* harmony import */ var _forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./forms */ "./lib/forms/InputRegular.js");
/* harmony import */ var _forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./forms */ "./lib/forms/selectRegular.js");
/* harmony import */ var _forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./forms */ "./lib/forms/selectColumns.js");
/* harmony import */ var _forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./forms */ "./lib/forms/CodeTextarea.js");
/* harmony import */ var _forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./forms */ "./lib/forms/CodeTextareaMirror.js");








const ComponentManager = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.Token('@amphi/pipeline-components-manager:provider');
class ComponentService {
    constructor() {
        this._components = [];
        this._components = [];
    }
    getComponents() {
        return this._components;
    }
    ;
    getComponent(id) {
        return this._components.find(component => component._id === id);
    }
    ;
    addComponent(newComponent) {
        this._components.push(newComponent);
    }
    ;
    // Method to get the number of components
    getComponentCount() {
        return this._components.length;
    }
    removeComponent(id) {
        this._components = this._components.filter(component => component._id !== id);
    }
}
const plugin = {
    id: '@amphi/pipeline-components-manager:plugin',
    description: 'Provider plugin for the pipeline editor\'s "component" service object.',
    autoStart: true,
    provides: ComponentManager,
    activate: () => {
        console.log('JupyterLab extension (@amphi/pipeline-components-manager/provider plugin) is activated!');
        const componentService = new ComponentService();
        return componentService;
    }
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/rendererUtils.js":
/*!******************************!*\
  !*** ./lib/rendererUtils.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createZoomSelector: () => (/* binding */ createZoomSelector),
/* harmony export */   renderComponentUI: () => (/* binding */ renderComponentUI),
/* harmony export */   renderHandle: () => (/* binding */ renderHandle)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/EditOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/icons/QuestionCircleOutlined.js");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactflow */ "webpack/sharing/consume/default/reactflow/reactflow");
/* harmony import */ var reactflow__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(reactflow__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "webpack/sharing/consume/default/antd/antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
// ConfigForm.tsx






const renderHandle = ({ type, Handle, Position, internals }) => {
    const LimitedInputHandle = (props) => {
        const { nodeInternals, edges, nodeId, componentService } = internals;
        const isHandleConnectable = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
            if (typeof props.isConnectable === 'function') {
                const node = nodeInternals.get(nodeId);
                const connectedEdges = (0,reactflow__WEBPACK_IMPORTED_MODULE_1__.getConnectedEdges)([node], edges).filter(edge => edge.target === nodeId && props.id === edge.targetHandle); // only count input edges
                return props.isConnectable({ node, connectedEdges });
            }
            if (typeof props.isConnectable === 'number') {
                const node = nodeInternals.get(nodeId);
                const connectedEdges = (0,reactflow__WEBPACK_IMPORTED_MODULE_1__.getConnectedEdges)([node], edges).filter(edge => edge.target === nodeId && props.id === edge.targetHandle); // only count input edges
                return connectedEdges.length < props.isConnectable;
            }
            return props.isConnectable;
        }, [nodeInternals, edges, nodeId, props.isConnectable, props.id]);
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Handle, { ...props, isConnectable: isHandleConnectable });
    };
    switch (type) {
        case "ibis_df_input":
        case "pandas_df_input":
        case "documents_input":
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Handle, { className: "handle-right", type: "source", position: Position.Right, id: "out" }));
        case "ibis_df_output":
        case "pandas_df_output":
        case "documents_output":
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(LimitedInputHandle, { type: "target", position: Position.Left, isConnectable: 1, className: "handle-left", id: "in" }));
        case "ibis_df_processor":
        case "pandas_df_processor":
        case 'pandas_df_to_documents_processor':
        case 'documents_processor':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(LimitedInputHandle, { type: "target", position: Position.Left, isConnectable: 1, className: "handle-left", id: "in" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Handle, { className: "handle-right", type: "source", position: Position.Right, id: "out" })));
        case 'ibis_df_multi_processor':
        case 'pandas_df_multi_processor':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(LimitedInputHandle, { type: "target", position: Position.Left, isConnectable: true, className: "handle-left", id: "in" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Handle, { className: "handle-right", type: "source", position: Position.Right, id: "out" })));
        case "ibis_df_double_processor":
        case "pandas_df_double_processor":
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(LimitedInputHandle, { type: "target", position: Position.Left, isConnectable: 1, className: "handle-left", id: "in1" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(LimitedInputHandle, { type: "target", position: Position.Left, isConnectable: 1, className: "second-handle-left", id: "in2" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Handle, { className: "handle-right", type: "source", position: Position.Right, id: "out" })));
        default:
            return null;
    }
};
const MemoizedComponentUI = react__WEBPACK_IMPORTED_MODULE_0___default().memo(({ id, data, context, manager, commands, name, ConfigForm, configFormProps, Icon, showContent, handle, deleteNode, setViewport, handleChange, isSelected }) => {
    var _a;
    // Track form values and updates
    const [formState, setFormState] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data);
    // Update formState when data changes
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setFormState(data);
    }, [data]);
    const modifier = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        var _a, _b;
        const engine = ((_b = (_a = data.backend) === null || _a === void 0 ? void 0 : _a.engine) === null || _b === void 0 ? void 0 : _b.toLowerCase()) || '';
        if (engine.includes("snowflake"))
            return "--snowflake";
        if (engine.includes("duckdb"))
            return "--duckdb";
        if (engine.includes("postgres"))
            return "--postgres";
        return "--default";
    }, [(_a = data.backend) === null || _a === void 0 ? void 0 : _a.engine]);
    const colorPrimary = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        switch (modifier) {
            case "--snowflake": return "#00ADEF";
            case "--duckdb": return "#45421D";
            case "--postgres": return "#336691";
            default: return "#5F9B97";
        }
    }, [modifier]);
    const isIbis = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        return ["--snowflake", "--duckdb", "--postgres"].includes(modifier);
    }, [modifier]);
    const handleDoubleClick = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        setViewport({ zoom: 1.1, duration: 500 });
    }, [setViewport]);
    const stopPropagation = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((event) => {
        event.stopPropagation();
    }, []);
    const disableDrag = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((event) => {
        event.preventDefault();
    }, []);
    const [titleName, setTitleName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((data === null || data === void 0 ? void 0 : data.customTitle) || name);
    const onTitleChange = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((newTitle) => {
        setTitleName(newTitle);
        handleChange(newTitle, 'customTitle');
    }, [handleChange]);
    // Modified ConfigForm props to include formState and update handler
    const enhancedConfigFormProps = {
        ...configFormProps,
        data: formState,
        onValueChange: (newValue, fieldId) => {
            setFormState(prev => {
                const newState = {
                    ...prev,
                    [fieldId]: newValue
                };
                handleChange(newValue, fieldId);
                return newState;
            });
        }
    };
    const theme = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
        token: {
            colorPrimary: colorPrimary,
        },
    }), [colorPrimary]);
    const componentClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        return `component component${modifier} ${isIbis ? "ibis" : ""}`;
    }, [modifier, isIbis]);
    const { Text } = antd__WEBPACK_IMPORTED_MODULE_2__.Typography;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.ConfigProvider, { theme: theme },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: componentClassName, onDoubleClick: handleDoubleClick },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "component__header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Text, { onDoubleClick: stopPropagation, onDragStart: disableDrag, editable: isSelected
                        ? {
                            onChange: onTitleChange,
                            tooltip: false,
                            icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__["default"], { style: { color: '#5F9B97' } })
                        }
                        : undefined, className: "ant-select-sm" }, titleName),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__.Popconfirm, { title: "Sure to delete?", placement: "right", onConfirm: deleteNode, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__["default"], { style: { color: 'red' } }) },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "deletebutton" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons__WEBPACK_IMPORTED_MODULE_5__.xIcon.react, { className: "group-hover:text-primary" })))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "component__body" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: showContent ? 'block' : 'none' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ConfigForm, { ...enhancedConfigFormProps })),
                    !showContent && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "placeholder" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Icon.react, { height: "42px", width: "42px", color: colorPrimary, verticalAlign: "middle" }))))),
            handle)));
}, (prevProps, nextProps) => {
    // Enhanced comparison function that includes form data changes
    return (prevProps.id === nextProps.id &&
        prevProps.showContent === nextProps.showContent &&
        prevProps.isSelected === nextProps.isSelected &&
        JSON.stringify(prevProps.data) === JSON.stringify(nextProps.data) &&
        prevProps.name === nextProps.name &&
        prevProps.configFormProps.modalOpen === nextProps.configFormProps.modalOpen);
});
// Export the function that creates the memoized component
const renderComponentUI = (props) => {
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(MemoizedComponentUI, { ...props });
};
const createZoomSelector = () => {
    return (s) => s.transform[2] >= 0.75;
};


/***/ }),

/***/ "./lib/variablesUtils.js":
/*!*******************************!*\
  !*** ./lib/variablesUtils.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BracesIcon: () => (/* binding */ BracesIcon),
/* harmony export */   BracesSvg: () => (/* binding */ BracesSvg),
/* harmony export */   useVariableAutoComplete: () => (/* binding */ useVariableAutoComplete)
/* harmony export */ });
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ant-design/icons */ "../../node_modules/@ant-design/icons/es/components/Icon.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _PipelineService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PipelineService */ "./lib/PipelineService.js");



const BracesSvg = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "1em", height: "1em", viewBox: "0 0 24 24", fill: "currentColor" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M4 18V14.3C4 13.4716 3.32843 12.8 2.5 12.8H2V11.2H2.5C3.32843 11.2 4 10.5284 4 9.7V6C4 4.34315 5.34315 3 7 3H8V5H7C6.44772 5 6 5.44772 6 6V10.1C6 10.9858 5.42408 11.7372 4.62623 12C5.42408 12.2628 6 13.0142 6 13.9V18C6 18.5523 6.44772 19 7 19H8V21H7C5.34315 21 4 19.6569 4 18ZM20 14.3V18C20 19.6569 18.6569 21 17 21H16V19H17C17.5523 19 18 18.5523 18 18V13.9C18 13.0142 18.5759 12.2628 19.3738 12C18.5759 11.7372 18 10.9858 18 10.1V6C18 5.44772 17.5523 5 17 5H16V3H17C18.6569 3 20 4.34315 20 6V9.7C20 10.5284 20.6716 11.2 21.5 11.2H22V12.8H21.5C20.6716 12.8 20 13.4716 20 14.3Z" })));
const BracesIcon = (props) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ant_design_icons__WEBPACK_IMPORTED_MODULE_1__["default"], { component: BracesSvg, ...props }));
const useVariableAutoComplete = ({ field, value, handleChange, context, advanced }) => {
    const [inputValue, setInputValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [openValue, setOpenValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [optionsVariables, setOptionsVariables] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [isHidden, setIsHidden] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (inputValue) {
            setIsHidden(true);
        }
        else {
            setIsHidden(false);
        }
    }, [inputValue]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setInputValue(value); // Update inputValue when value prop changes
    }, [value]);
    const handleInputChange = (value) => {
        setInputValue(value);
        handleChange(value, field.id);
    };
    const handleSelect = (value, option) => {
        const newValue = `{os.getenv('${value}')}`;
        handleInputChange(newValue);
    };
    const filterOptions = (inputValue, option) => {
        if (!option || option.value === undefined) {
            return false;
        }
    };
    const renderTitle = (title) => react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, title);
    const renderItem = (title) => ({
        value: title,
        label: (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', justifyContent: 'space-between' } }, title)),
    });
    const suffix = (inputValue ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BracesIcon, { style: {
            color: 'grey',
            transition: 'color 0.3s'
        }, onMouseEnter: (e) => (e.currentTarget.style.color = '#43786E'), onMouseLeave: (e) => (e.currentTarget.style.color = 'grey'), onClick: () => {
            if (!openValue) {
                setOptionsVariables([
                    {
                        label: renderTitle('Environment Variables'),
                        options: _PipelineService__WEBPACK_IMPORTED_MODULE_2__.PipelineService.getEnvironmentVariables(context.model.toString()).map(variableName => renderItem(variableName)),
                    }
                ]);
            }
            setOpenValue((prev) => !prev);
        } })));
    return {
        inputValue,
        inputRef,
        openValue,
        setOpenValue,
        optionsVariables,
        handleInputChange,
        handleSelect,
        filterOptions,
        suffix,
    };
};


/***/ }),

/***/ "./style/icons/alert-triangle-fill-16.svg":
/*!************************************************!*\
  !*** ./style/icons/alert-triangle-fill-16.svg ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M8 1a2.143 2.143 0 00-1.827 1.024l-5.88 9.768a2.125 2.125 0 00.762 2.915c.322.188.687.289 1.06.293h11.77a2.143 2.143 0 001.834-1.074 2.126 2.126 0 00-.006-2.124L9.829 2.028A2.149 2.149 0 008 1zM7 11a1 1 0 011-1h.007a1 1 0 110 2H8a1 1 0 01-1-1zm1.75-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/braces.svg":
/*!********************************!*\
  !*** ./style/icons/braces.svg ***!
  \********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M4 18V14.3C4 13.4716 3.32843 12.8 2.5 12.8H2V11.2H2.5C3.32843 11.2 4 10.5284 4 9.7V6C4 4.34315 5.34315 3 7 3H8V5H7C6.44772 5 6 5.44772 6 6V10.1C6 10.9858 5.42408 11.7372 4.62623 12C5.42408 12.2628 6 13.0142 6 13.9V18C6 18.5523 6.44772 19 7 19H8V21H7C5.34315 21 4 19.6569 4 18ZM20 14.3V18C20 19.6569 18.6569 21 17 21H16V19H17C17.5523 19 18 18.5523 18 18V13.9C18 13.0142 18.5759 12.2628 19.3738 12C18.5759 11.7372 18 10.9858 18 10.1V6C18 5.44772 17.5523 5 17 5H16V3H17C18.6569 3 20 4.34315 20 6V9.7C20 10.5284 20.6716 11.2 21.5 11.2H22V12.8H21.5C20.6716 12.8 20 13.4716 20 14.3Z\"></path></svg>";

/***/ }),

/***/ "./style/icons/crosshair-16.svg":
/*!**************************************!*\
  !*** ./style/icons/crosshair-16.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M0 8a8 8 0 1116 0A8 8 0 010 8zm8.75 6.457V12.75a.75.75 0 00-1.5 0v1.707A6.503 6.503 0 011.543 8.75H3.25a.75.75 0 000-1.5H1.543A6.503 6.503 0 017.25 1.543V3.25a.75.75 0 001.5 0V1.543a6.503 6.503 0 015.707 5.707H12.75a.75.75 0 000 1.5h1.707a6.503 6.503 0 01-5.707 5.707z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/minus-16.svg":
/*!**********************************!*\
  !*** ./style/icons/minus-16.svg ***!
  \**********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M3.5 7.75A.75.75 0 014.25 7h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/play-16.svg":
/*!*********************************!*\
  !*** ./style/icons/play-16.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M3 3.814C3 2.436 4.52 1.6 5.684 2.334l6.628 4.186a1.75 1.75 0 010 2.96l-6.628 4.185C4.52 14.401 3 13.564 3 12.185v-8.37zm1.883-.211a.25.25 0 00-.383.211v8.372a.25.25 0 00.383.211l6.628-4.186a.25.25 0 000-.422L4.884 3.603z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/play-circle-16.svg":
/*!****************************************!*\
  !*** ./style/icons/play-circle-16.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><g fill=\"currentColor\" fill-rule=\"evenodd\" clip-rule=\"evenodd\"><path d=\"M7.421 4.356A1.25 1.25 0 005.5 5.411v5.178a1.25 1.25 0 001.921 1.055l4.069-2.59a1.25 1.25 0 000-2.109L7.42 4.356zM10.353 8L7 10.134V5.866L10.353 8z\"/><path d=\"M8 0a8 8 0 100 16A8 8 0 008 0zM1.5 8a6.5 6.5 0 1113 0 6.5 6.5 0 01-13 0z\"/></g></svg>";

/***/ }),

/***/ "./style/icons/plus-16.svg":
/*!*********************************!*\
  !*** ./style/icons/plus-16.svg ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" d=\"M9 3.5a.75.75 0 00-1.5 0V7H4a.75.75 0 000 1.5h3.5V12A.75.75 0 009 12V8.5h3.5a.75.75 0 000-1.5H9V3.5z\"/></svg>";

/***/ }),

/***/ "./style/icons/search-16.svg":
/*!***********************************!*\
  !*** ./style/icons/search-16.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M7.25 2a5.25 5.25 0 103.144 9.455l2.326 2.325a.75.75 0 101.06-1.06l-2.325-2.326A5.25 5.25 0 007.25 2zM3.5 7.25a3.75 3.75 0 117.5 0 3.75 3.75 0 01-7.5 0z\" clip-rule=\"evenodd\"/></svg>";

/***/ }),

/***/ "./style/icons/settings-16.svg":
/*!*************************************!*\
  !*** ./style/icons/settings-16.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg\n   width=\"16\"\n   height=\"16\"\n   fill=\"none\"\n   viewBox=\"0 0 16 16\"\n   version=\"1.1\"\n   id=\"svg2\"\n   sodipodi:docname=\"settings-16.svg\"\n   inkscape:version=\"1.3 (0e150ed, 2023-07-21)\"\n   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n   xmlns=\"http://www.w3.org/2000/svg\"\n   xmlns:svg=\"http://www.w3.org/2000/svg\">\n  <defs\n     id=\"defs2\" />\n  <sodipodi:namedview\n     id=\"namedview2\"\n     pagecolor=\"#505050\"\n     bordercolor=\"#eeeeee\"\n     borderopacity=\"1\"\n     inkscape:showpageshadow=\"0\"\n     inkscape:pageopacity=\"0\"\n     inkscape:pagecheckerboard=\"0\"\n     inkscape:deskcolor=\"#505050\"\n     inkscape:zoom=\"34.875\"\n     inkscape:cx=\"8\"\n     inkscape:cy=\"7.9856631\"\n     inkscape:window-width=\"1392\"\n     inkscape:window-height=\"922\"\n     inkscape:window-x=\"0\"\n     inkscape:window-y=\"75\"\n     inkscape:window-maximized=\"0\"\n     inkscape:current-layer=\"svg2\" />\n  <g\n     fill=\"currentColor\"\n     fill-rule=\"evenodd\"\n     clip-rule=\"evenodd\"\n     id=\"g2\">\n    <path\n       d=\"M8 5a3 3 0 100 6 3 3 0 000-6zM6.5 8a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0z\"\n       id=\"path1\" />\n    <path\n       d=\"M7.5 0a1.75 1.75 0 00-1.75 1.75v.15c-.16.06-.318.125-.472.196l-.106-.106a1.75 1.75 0 00-2.475 0l-.707.707a1.75 1.75 0 000 2.475l.106.106a6.46 6.46 0 00-.196.472h-.15A1.75 1.75 0 000 7.5v1c0 .966.784 1.75 1.75 1.75h.15c.06.16.125.318.196.472l-.106.107a1.75 1.75 0 000 2.474l.707.708a1.75 1.75 0 002.475 0l.106-.107c.154.071.312.137.472.196v.15c0 .966.784 1.75 1.75 1.75h1a1.75 1.75 0 001.75-1.75v-.15c.16-.06.318-.125.472-.196l.106.107a1.75 1.75 0 002.475 0l.707-.707a1.75 1.75 0 000-2.475l-.106-.107c.071-.154.137-.311.196-.472h.15A1.75 1.75 0 0016 8.5v-1a1.75 1.75 0 00-1.75-1.75h-.15a6.455 6.455 0 00-.196-.472l.106-.106a1.75 1.75 0 000-2.475l-.707-.707a1.75 1.75 0 00-2.475 0l-.106.106a6.46 6.46 0 00-.472-.196v-.15A1.75 1.75 0 008.5 0h-1zm-.25 1.75a.25.25 0 01.25-.25h1a.25.25 0 01.25.25v.698c0 .339.227.636.555.724.42.113.817.28 1.186.492a.75.75 0 00.905-.12l.493-.494a.25.25 0 01.354 0l.707.708a.25.25 0 010 .353l-.494.494a.75.75 0 00-.12.904c.213.369.38.767.492 1.186a.75.75 0 00.724.555h.698a.25.25 0 01.25.25v1a.25.25 0 01-.25.25h-.698a.75.75 0 00-.724.555c-.113.42-.28.817-.492 1.186a.75.75 0 00.12.905l.494.493a.25.25 0 010 .354l-.707.707a.25.25 0 01-.354 0l-.494-.494a.75.75 0 00-.904-.12 4.966 4.966 0 01-1.186.492.75.75 0 00-.555.724v.698a.25.25 0 01-.25.25h-1a.25.25 0 01-.25-.25v-.698a.75.75 0 00-.555-.724 4.966 4.966 0 01-1.186-.491.75.75 0 00-.904.12l-.494.493a.25.25 0 01-.354 0l-.707-.707a.25.25 0 010-.354l.494-.493a.75.75 0 00.12-.905 4.966 4.966 0 01-.492-1.186.75.75 0 00-.724-.555H1.75a.25.25 0 01-.25-.25v-1a.25.25 0 01.25-.25h.698a.75.75 0 00.724-.555c.113-.42.28-.817.491-1.186a.75.75 0 00-.12-.904L3.05 4.11a.25.25 0 010-.353l.707-.708a.25.25 0 01.354 0l.493.494c.24.24.611.289.905.12a4.965 4.965 0 011.186-.492.75.75 0 00.555-.724V1.75z\"\n       id=\"path2\" />\n  </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/trash-16.svg":
/*!**********************************!*\
  !*** ./style/icons/trash-16.svg ***!
  \**********************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><g fill=\"currentColor\"><path d=\"M6.25 6a.75.75 0 01.75.75v5.5a.75.75 0 01-1.5 0v-5.5A.75.75 0 016.25 6zM10.5 6.75a.75.75 0 00-1.5 0v5.5a.75.75 0 001.5 0v-5.5z\"/><path fill-rule=\"evenodd\" d=\"M4 3v-.75A2.25 2.25 0 016.25 0h3.5A2.25 2.25 0 0112 2.25V3h2.25a.75.75 0 010 1.5H14v9.25A2.25 2.25 0 0111.75 16h-7.5A2.25 2.25 0 012 13.75V4.5h-.25a.75.75 0 010-1.5H4zm1.5-.75a.75.75 0 01.75-.75h3.5a.75.75 0 01.75.75V3h-5v-.75zm-2 2.25v9.25c0 .414.336.75.75.75h7.5a.75.75 0 00.75-.75V4.5h-9z\" clip-rule=\"evenodd\"/></g></svg>";

/***/ }),

/***/ "./style/icons/x-16.svg":
/*!******************************!*\
  !*** ./style/icons/x-16.svg ***!
  \******************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\"><path fill=\"currentColor\" d=\"M12.78 4.28a.75.75 0 00-1.06-1.06L8 6.94 4.28 3.22a.75.75 0 00-1.06 1.06L6.94 8l-3.72 3.72a.75.75 0 101.06 1.06L8 9.06l3.72 3.72a.75.75 0 101.06-1.06L9.06 8l3.72-3.72z\"/></svg>";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.831f09ad9ec6ba043d99.js.map